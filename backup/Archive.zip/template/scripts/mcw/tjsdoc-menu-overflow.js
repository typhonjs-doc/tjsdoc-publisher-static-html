/**
 * Provides special handling for the TJSDoc overflow menu. The menu items added should have `data-href` defined and
 * optionally `data-target`.
 */
(function()
{
   var menuEl = document.querySelector('#tjsdoc-toolbar-menu-overflow');
   var menu = new mdc.menu.MDCSimpleMenu(menuEl);
   var toggle = document.querySelector('.tjsdoc-toolbar-button-overflow');

   toggle.addEventListener('click', function()
   {
      // Set menu position based on the left position of `toggle` button.
      menu.foundation_.adapter_.setPosition({ left: toggle.offsetLeft + 'px' });

      menu.open = !menu.open;
   });

   // When the browser window is resized close the menu.
   $(window).resize(function() { menu.open = false; });

   // Navigate to a new location or try to open a new window if `data-target` is defined.
   menuEl.addEventListener('MDCSimpleMenu:selected', function(evt)
   {
      var detail = evt.detail;

      var href = detail.item.getAttribute('data-href');
      var target = detail.item.getAttribute('data-target');

      if (typeof href === 'string')
      {
         try
         {
            if (typeof target === 'string' && target !== '')
            {
               window.open(href, target);
            }
            else
            {
               window.location.assign(href)
            }
         }
         catch (err)
         {
            window.location.assign(href)
         }
      }
   });
})();
