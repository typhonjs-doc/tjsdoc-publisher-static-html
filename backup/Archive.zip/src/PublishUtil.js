import escape  from 'escape-html';
import fs      from 'fs';
import path    from 'path';

/**
 * Defines several event bindings which aid in the publishing process.
 *
 * 'tjsdoc:system:publisher:doc:file:name:get' -
 * 'tjsdoc:system:publisher:doc:html:decorator:get' -
 * 'tjsdoc:system:publisher:doc:html:deprecated:get' -
 * 'tjsdoc:system:publisher:doc:html:experimental:get' -
 * 'tjsdoc:system:publisher:doc:html:file:link:get' -
 * 'tjsdoc:system:publisher:doc:html:link:get' -
 * 'tjsdoc:system:publisher:doc:html:link:type:get' -
 * 'tjsdoc:system:publisher:doc:html:signature:get' -
 * 'tjsdoc:system:publisher:doc:override:method:get' -
 * 'tjsdoc:system:publisher:doc:override:method:description:get' -
 * 'tjsdoc:system:publisher:doc:url:get' -
 * 'tjsdoc:system:publisher:docs:html:link:get' -
 * 'tjsdoc:system:publisher:file:url:base:get' -
 * 'tjsdoc:system:publisher:ice:cap:template:get' - Loads a template file into an ice-cap instance.
 * 'tjsdoc:system:publisher:reset' -
 * 'tjsdoc:system:publisher:template:get' - Loads a template file.
 * 'tjsdoc:system:publisher:title:get' -
 */
export default class PublisherUtil
{
   /**
    * Registers all event bindings.
    *
    * @param {PluginEvent} ev - The plugin event.
    */
   static onPluginLoad(ev)
   {
      this._eventbus = ev.eventbus;

      // Register all events on the eventbus.
      this._eventbus.on('tjsdoc:data:publisher:docdb:get', this.getActiveDocDB, this);

      this._eventbus.on('tjsdoc:system:publisher:doc:file:name:get', this.getDocFileName, this);
      this._eventbus.on('tjsdoc:system:publisher:doc:html:decorator:get', this.getDocHTMLDecorator, this);
      this._eventbus.on('tjsdoc:system:publisher:doc:html:deprecated:get', this.getDocHTMLDeprecated, this);
      this._eventbus.on('tjsdoc:system:publisher:doc:html:experimental:get', this.getDocHTMLExperimental, this);
      this._eventbus.on('tjsdoc:system:publisher:doc:html:file:link:get', this.getDocHTMLFileLink, this);
      this._eventbus.on('tjsdoc:system:publisher:doc:html:link:get', this.getDocHTMLLink, this);
      this._eventbus.on('tjsdoc:system:publisher:doc:html:link:type:get', this.getDocHTMLLinkType, this);
      this._eventbus.on('tjsdoc:system:publisher:doc:html:signature:get', this.getDocHTMLSignature, this);
      this._eventbus.on('tjsdoc:system:publisher:doc:override:method:get', this.getDocOverrideMethod, this);
      this._eventbus.on('tjsdoc:system:publisher:doc:override:method:description:get',
       this.getDocOverrideMethodDescription, this);
      this._eventbus.on('tjsdoc:system:publisher:doc:short:description:get', this.getDocShortDescription, this);
      this._eventbus.on('tjsdoc:system:publisher:doc:url:get', this.getDocURL, this);
      this._eventbus.on('tjsdoc:system:publisher:docs:bare:link:get', this.getDocsBareLinks, this);
      this._eventbus.on('tjsdoc:system:publisher:docs:html:link:get', this.getDocsHTMLLink, this);
      this._eventbus.on('tjsdoc:system:publisher:file:url:base:get', this.getFileURLBase, this);
      this._eventbus.on('tjsdoc:system:publisher:ice:cap:template:get', this.getIceCapTemplate, this);
      this._eventbus.on('tjsdoc:system:publisher:reset', this.reset, this);
      this._eventbus.on('tjsdoc:system:publisher:template:get', this.getTemplate, this);
      this._eventbus.on('tjsdoc:system:publisher:title:get', this.getTitle, this);
   }

   /**
    * Stores the main TJSDoc config, main DocDB, and package data.
    *
    * @param {PluginEvent} ev - The plugin event.
    */
   static onRuntimePreGenerateAsync(ev)
   {
      /**
       * The main DocDB.
       * @type {DocDB}
       * @private
       */
      this._mainDocDB = this._docDB = ev.data.docDB;

      /**
       * The TJSDoc config.
       * @type {TJSDocConfig}
       * @private
       */
      this._mainConfig = ev.data.mainConfig;

      /**
       * The formatted target project `package.json` object.
       */
      this._packageInfo = ev.data.packageInfo;

      /**
       * The target project `package.json` object.
       */
      this._packageObj = ev.data.packageObj;

      /**
       * The publisher config.
       */
      this._pubConfig = ev.data.pubConfig;
   }

   /**
    * Returns the actively associated DocDB being published. By default this should always be the main DocDB.
    *
    * @returns {DocDB}
    */
   static getActiveDocDB()
   {
      return this._docDB;
   }

   /**
    * Get file name for output HTML page from a doc object.
    *
    * @param {DocObject} doc - Target doc object.
    *
    * @returns {string} file name.
    */
   static getDocFileName(doc)
   {
      let longname = doc.longname;

      // Replace any leading relative path `.` with `,` so that the generated doc files are not placed outside of
      // the `config.destination` path, but retain a general indication of where the source files are located.
      if (longname)
      {
         // TODO: Verify on Windows
         longname = longname.replace(/^(?:\.\.\/)+/, (match) => match.replace(/(\.\.)+/g, ',,'));
      }

      switch (doc.kind)
      {
         case 'ModuleAssignment':
         case 'ModuleVariable':
            return 'variable/index.html';

         case 'ModuleFunction':
            return 'function/index.html';

         case 'ClassMember':
         case 'ClassMethod':
         case 'ClassProperty':
         {
            const parentDoc = this._docDB.find({ longname: doc.memberof })[0];

            return this.getDocFileName(parentDoc);
         }

         case 'VirtualExternal':
            return 'external/index.html';

         case 'VirtualTypedef':
            return 'typedef/index.html';

         case 'ModuleClass':
            return `class/${longname}.html`;

         case 'ModuleFile':
            return `file/${longname}.html`;

         case 'ModuleTestFile':
            return `test-file/${longname}.html`;

         case 'Test':
            return 'test.html';

         default:
            throw new Error('DocBuilder: can not resolve file name.');
      }
   }

   /**
    * Builds decorator description.
    *
    * @param {DocObject} doc - Target doc object.
    *
    * @returns {string} description. if doc does not override ancestor method, returns empty.
    */
   static getDocHTMLDecorator(doc)
   {
      if (!doc.decorators) { return ''; }

      const links = [];

      for (const decorator of doc.decorators)
      {
         const link = this.getDocHTMLLink(decorator.name, decorator.name);

         links.push(decorator.arguments ? `<li>${link}${decorator.arguments}</li>` : `<li>${link}</li>`);
      }

      if (!links.length) { return ''; }

      return `<ul>${links.join('\n')}</ul>`;
   }

   /**
    * Builds deprecated HTML.
    *
    * @param {DocObject} doc - Target doc object.
    *
    * @returns {string} If doc is not deprecated, returns empty.
    */
   static getDocHTMLDeprecated(doc)
   {
      if (doc.deprecated)
      {
         let deprecated = 'Deprecated';

         if (typeof doc.deprecated === 'string') { deprecated += `: ${doc.deprecated}`; }

         return deprecated;
      }
      else
      {
         return '';
      }
   }

   /**
    * Builds experimental HTML.
    *
    * @param {DocObject} doc - Target doc object.
    *
    * @returns {string} If doc object is not experimental, returns empty.
    */
   static getDocHTMLExperimental(doc)
   {
      if (doc.experimental)
      {
         let experimental = 'Experimental';

         if (typeof doc.experimental === 'string') { experimental += `: ${doc.experimental}`; }

         return experimental;
      }
      else
      {
         return '';
      }
   }

   /**
    * Builds HTML link to file page.
    *
    * @param {DocObject}   doc - target doc object.
    *
    * @param {string|null} [text] - link text.
    *
    * @returns {string} HTML of link.
    */
   static getDocHTMLFileLink(doc, text)
   {
      if (!doc) { return ''; }

      let fileDoc;

      if (doc.kind === 'ModuleFile' || doc.kind === 'ModuleTestFile')
      {
         fileDoc = doc;
      }
      else
      {
         const filePath = doc.longname.split('~')[0];

         fileDoc = this._docDB.find({ kind: ['ModuleFile', 'ModuleTestFile'], longname: filePath })[0];
      }

      if (!fileDoc) { return ''; }

      if (!text) { text = fileDoc.name; }

      if (doc.kind === 'ModuleFile' || doc.kind === 'ModuleTestFile')
      {
         return `<span><a href="${this.getDocURL(fileDoc)}">${text}</a></span>`;
      }
      else
      {
         return `<span><a href="${this.getDocURL(fileDoc)}#lineNumber${doc.lineNumber}">${text}</a></span>`;
      }
   }

   /**
    * build HTML link to identifier.
    *
    * @param {string}   longname - link to
    *
    * @param {string}   [text] - link text. default is name property of doc object.
    *
    * @param {boolean}  [inner=false] - if true, use inner link.
    *
    * @param {string}   [kind] - specify target kind property.
    *
    * @param {string}   [qualifier] - specify target qualifier property.
    *
    * @returns {string} HTML of link.
    */
   static getDocHTMLLink(longname, text = void 0, inner = false, kind = void 0, qualifier = void 0)
   {
      if (!longname) { return ''; }

      if (typeof longname !== 'string') { throw new Error(JSON.stringify(longname)); }

      const doc = this._docDB.findByName(longname, kind, qualifier)[0];

      if (!doc)
      {
         // If longname is HTML tag do not escape.
         return longname.startsWith('<') ? `<span>${longname}</span>` : `<span>${escape(text || longname)}</span>`;
      }

      if (doc.kind === 'VirtualExternal')
      {
         text = doc.name;

         return `<span><a href="${doc.externalLink}">${text}</a></span>`;
      }
      else
      {
         text = escape(text || doc.name);

         const url = this.getDocURL(doc, inner);

         return url ? `<span><a href="${url}">${text}</a></span>` : `<span>${text}</span>`;
      }
   }

   /**
    * Get HTML link of type.
    *
    * @param {string} typeName - type name(e.g. ``number[]``, ``Map<number, string>``)
    *
    * @returns {string} HTML of link.
    * @todo re-implement with parser combinator.
    */
   static getDocHTMLLinkType(typeName)
   {
      // e.g. number[]
      let matched = typeName.match(/^(.*?)\[\]$/);

      if (matched)
      {
         typeName = matched[1];

         return `<span>${this.getDocHTMLLink(typeName, typeName)}<span>[]</span></span>`;
      }

      // e.g. function(a: number, b: string): boolean
      matched = typeName.match(/function *\((.*?)\)(.*)/);

      if (matched)
      {
         const functionLink = this.getDocHTMLLink('function');

         if (!matched[1] && !matched[2]) { return `<span>${functionLink}<span>()</span></span>`; }

         let innerTypes = [];

         if (matched[1])
         {
            // bad hack: Map.<string, boolean> => Map.<string\Z boolean>
            // bad hack: {a: string, b: boolean} => {a\Y string\Z b\Y boolean}
            const inner = matched[1]
             .replace(/<.*?>/g, (a) => a.replace(/,/g, '\\Z'))
              .replace(/{.*?}/g, (a) => a.replace(/,/g, '\\Z').replace(/:/g, '\\Y'));

            innerTypes = inner.split(',').map((v) =>
            {
               const tmp = v.split(':').map((v) => v.trim());

               if (tmp.length !== 2)
               {
                  throw new SyntaxError(`Invalid function type annotation: \`${matched[0]}\``);
               }

               const paramName = tmp[0];
               const typeName = tmp[1].replace(/\\Z/g, ',').replace(/\\Y/g, ':');

               return `${paramName}: ${this.getDocHTMLLinkType(typeName)}`;
            });
         }

         let returnType = '';

         if (matched[2])
         {
            const type = matched[2].split(':')[1];

            if (type) { returnType = `: ${this.getDocHTMLLinkType(type.trim())}`; }
         }

         return `<span>${functionLink}<span>(${innerTypes.join(', ')})</span>${returnType}</span>`;
      }

      // e.g. {a: number, b: string}
      matched = typeName.match(/^\{(.*?)\}$/);

      if (matched)
      {
         if (!matched[1]) { return '{}'; }

         // bad hack: Map.<string, boolean> => Map.<string\Z boolean>
         // bad hack: {a: string, b: boolean} => {a\Y string\Z b\Y boolean}
         const inner = matched[1]
          .replace(/<.*?>/g, (a) => a.replace(/,/g, '\\Z'))
           .replace(/{.*?}/g, (a) => a.replace(/,/g, '\\Z').replace(/:/g, '\\Y'));

         const innerTypes = inner.split(',').map((v) =>
         {
            const tmp = v.split(':').map((v) => v.trim());
            const paramName = tmp[0];

            let typeName = tmp[1].replace(/\\Z/g, ',').replace(/\\Y/g, ':');

            if (typeName.includes('|'))
            {
               typeName = typeName.replace(/^\(/, '').replace(/\)$/, '');

               const typeNames = typeName.split('|').map((v) => v.trim());
               const html = [];

               for (const unionType of typeNames)
               {
                  html.push(this.getDocHTMLLinkType(unionType));
               }

               return `${paramName}: ${html.join('|')}`;
            }
            else
            {
               return `${paramName}: ${this.getDocHTMLLinkType(typeName)}`;
            }
         });

         return `{${innerTypes.join(', ')}}`;
      }

      // e.g. Map<number, string>
      matched = typeName.match(/^(.*?)\.?<(.*?)>$/);

      if (matched)
      {
         const mainType = matched[1];

         // bad hack: Map.<string, boolean> => Map.<string\Z boolean>
         // bad hack: {a: string, b: boolean} => {a\Y string\Z b\Y boolean}
         const inner = matched[2]
          .replace(/<.*?>/g, (a) => a.replace(/,/g, '\\Z'))
           .replace(/{.*?}/g, (a) => a.replace(/,/g, '\\Z').replace(/:/g, '\\Y'));

         const innerTypes = inner.split(',').map((v) =>
         {
            return v.split('|').map((vv) =>
            {
               vv = vv.trim().replace(/\\Z/g, ',').replace(/\\Y/g, ':');

               return this.getDocHTMLLinkType(vv);
            }).join('|');
         });

         // html
         return `${this.getDocHTMLLink(mainType, mainType)}<${innerTypes.join(', ')}>`;
      }

      if (typeName.startsWith('...'))
      {
         typeName = typeName.replace('...', '');

         if (typeName.includes('|'))
         {
            const typeNames = typeName.replace('(', '').replace(')', '').split('|');
            const typeLinks = typeNames.map((v) => this.getDocHTMLLink(v));

            return `...(${typeLinks.join('|')})`;
         }
         else
         {
            return `...${this.getDocHTMLLink(typeName)}`;
         }
      }
      else if (typeName.startsWith('?'))
      {
         typeName = typeName.replace('?', '');

         return `?${this.getDocHTMLLink(typeName)}`;
      }
      else
      {
         return this.getDocHTMLLink(typeName);
      }
   }

   /**
    * Builds identifier signature HTML.
    *
    * @param {DocObject}   doc - Target doc object.
    *
    * @param {boolean}     skipSignatures - Skips adding call, type, and return signatures.
    *
    * @returns {string} Signature HTML.
    */
   static getDocHTMLSignature(doc, skipSignatures = false)
   {
      // call signature
      const callSignatures = [];

      if (doc.params)
      {
         for (const param of doc.params)
         {
            const paramName = param.name;

            if (paramName.includes('.')) { continue; } // for object property
            if (paramName.includes('[')) { continue; } // for array property

            const types = [];

            for (const typeName of param.types)
            {
               types.push(this.getDocHTMLLinkType(typeName));
            }

            callSignatures.push(`${paramName}: ${types.join(' | ')}`);
         }
      }

      // return signature
      const returnSignatures = [];

      if (doc.return)
      {
         for (const typeName of doc.return.types)
         {
            returnSignatures.push(this.getDocHTMLLinkType(typeName));
         }
      }

      // type signature
      let typeSignatures = [];

      if (doc.type)
      {
         for (const typeName of doc.type.types)
         {
            typeSignatures.push(this.getDocHTMLLinkType(typeName));
         }
      }

      // callback is not need type. because type is always function.
      if (doc.kind === 'ModuleFunction')
      {
         typeSignatures = [];
      }

      let html = '';

      if (callSignatures.length)
      {
         html = !skipSignatures ? `(${callSignatures.join(', ')})` : '(...)';
      }
      else
      {
         switch (doc.kind)
         {
            case 'ClassMethod':
            case 'ModuleFunction':
               html = !doc.accessor ? '()' : '';
               break;
         }
      }

      if (returnSignatures.length && !skipSignatures) { html = `${html}: ${returnSignatures.join(' | ')}`; }
      if (typeSignatures.length && !skipSignatures) { html = `${html}: ${typeSignatures.join(' | ')}`; }

      return html;
   }

   /**
    * Builds method of ancestor class link HTML.
    *
    * @param {DocObject} doc - Target doc object.
    *
    * @returns {string} HTML link. If doc does not override ancestor method, returns empty.
    */
   static getDocOverrideMethod(doc)
   {
      const parentDoc = this._docDB.findByName(doc.memberof)[0];

      if (!parentDoc) { return ''; }
      if (!parentDoc._custom_extends_chains) { return ''; }

      const chains = [...parentDoc._custom_extends_chains].reverse();

      for (const longname of chains)
      {
         const superClassDoc = this._docDB.findByName(longname)[0];

         if (!superClassDoc) { continue; }

         const superMethodDoc = this._docDB.find({ name: doc.name, memberof: superClassDoc.longname })[0];

         if (!superMethodDoc) { continue; }

         return this.getDocHTMLLink(superMethodDoc.longname, `${superClassDoc.name}#${superMethodDoc.name}`, true);
      }

      return '';
   }

   /**
    * Builds method of ancestor class description.
    *
    * @param {DocObject} doc - Target doc object.
    *
    * @returns {string} Description. If doc does not override ancestor method, returns empty.
    */
   static getDocOverrideMethodDescription(doc)
   {
      const parentDoc = this._docDB.findByName(doc.memberof)[0];

      if (!parentDoc) { return ''; }
      if (!parentDoc._custom_extends_chains) { return ''; }

      const chains = [...parentDoc._custom_extends_chains].reverse();

      for (const longname of chains)
      {
         const superClassDoc = this._docDB.findByName(longname)[0];

         if (!superClassDoc) { continue; }

         const superMethodDoc = this._docDB.find({ name: doc.name, memberof: superClassDoc.longname })[0];

         if (!superMethodDoc) { continue; }

         if (superMethodDoc.descriptionHTML) { return superMethodDoc.descriptionHTML; }
      }

      return '';
   }

   /**
    * Gets a docs shortened description.
    *
    * e.g. ``this is JavaScript. this is Java.`` => ``this is JavaScript.``.
    *
    * @param {DocObject} doc - target doc object.
    * @param {boolean} [asMarkdown=false] - is true, test as markdown and convert to html.
    *
    * @returns {string} shortened description.
    * @todo shorten before process markdown.
    */
   static getDocShortDescription(doc, asMarkdown = false)
   {
      if (!doc) { return ''; }

      if (doc.summary) { return doc.summary; }

      const desc = doc.description;

      if (!desc) { return ''; }

      let len = desc.length;
      let inSQuote = false;
      let inWQuote = false;
      let inCode = false;

      for (let i = 0; i < desc.length; i++)
      {
         const char1 = desc.charAt(i);
         const char2 = desc.charAt(i + 1);
         const char4 = desc.substr(i, 6);
         const char5 = desc.substr(i, 7);

         if (char1 === '\'')
         {
            inSQuote = !inSQuote;
         }
         else if (char1 === '"')
         {
            inWQuote = !inWQuote;
         }
         else if (char4 === '<code>')
         {
            inCode = true;
         }
         else if (char5 === '</code>')
         {
            inCode = false;
         }

         if (inSQuote || inCode || inWQuote) { continue; }

         if (char1 === '.')
         {
            if (char2 === ' ' || char2 === '\n' || char2 === '<')
            {
               len = i + 1;
               break;
            }
         }
         else if (char1 === '\n' && char2 === '\n')
         {
            len = i + 1;
            break;
         }
      }

      let result = desc.substr(0, len);

      if (asMarkdown)
      {
         // result = markdown(result);
         result = this._eventbus.triggerSync('typhonjs:util:markdown:html:convert', { markdown: result });
      }

      return result;
   }

   /**
    * Get URL of output HTML page.
    *
    * @param {DocObject} doc - Target doc object.
    *
    * @returns {string} URL of output HTML. It is the relative path from output root dir.
    */
   static getDocURL(doc)
   {
      let inner = false;
      let qualifier = '';

      switch (doc.kind)
      {
         case 'ClassMethod':
            qualifier = doc.accessor ? `-${doc.qualifier}` : '';
            inner = true;
            break;

         case 'ClassMember':
         case 'ClassProperty':
         case 'ModuleAssignment':
         case 'ModuleFunction':
         case 'ModuleVariable':
         case 'VirtualTypedef':
            inner = true;
            break;
      }

      if (inner)
      {
         const scope = doc.static ? 'static' : 'instance';
         const fileName = this.getDocFileName(doc);

         return `${fileName}#${scope}-${doc.kind.toLowerCase()}${qualifier}-${doc.name}`;
      }
      else
      {
         return this.getDocFileName(doc);
      }
   }

   /**
    * Returns an array of bare HTML links to identifiers.
    *
    * @param {string[]} longnames - link to these.
    *
    * @param {string}   [text] - link text. default is name property of doc object.
    *
    * @param {boolean}  [inner=false] - if true, use inner link.
    *
    * @returns {Array<string>} HTML links.
    */
   static getDocsBareLinks(longnames, text = void 0, inner = false)
   {
      if (!longnames) { return []; }
      if (!longnames.length) { return []; }

      const links = [];

      for (const longname of longnames)
      {
         if (!longname) { continue; }

         const link = this.getDocHTMLLink(longname, text, inner);

         links.push(link);
      }

      return links;
   }

   /**
    * Builds HTML links to identifiers.
    *
    * @param {string[]} longnames - link to these.
    *
    * @param {string}   [text] - link text. default is name property of doc object.
    *
    * @param {boolean}  [inner=false] - if true, use inner link.
    *
    * @param {string}   [separator='\n'] - used link separator.
    *
    * @returns {string} HTML links.
    */
   static getDocsHTMLLink(longnames, text = void 0, inner = false, separator = '\n')
   {
      if (!longnames) { return ''; }
      if (!longnames.length) { return ''; }

      const links = [];

      for (const longname of longnames)
      {
         if (!longname) { continue; }

         const link = this.getDocHTMLLink(longname, text, inner);

         links.push(`<li>${link}</li>`);
      }

      if (!links.length) { return ''; }

      return `<ul>${links.join(separator)}</ul>`;
   }

   /**
    * Gets base URL HTML page.
    *
    * @param {string} fileName - Output file path.
    *
    * @returns {string} Base URL.
    */
   static getFileURLBase(fileName)
   {
      return '../'.repeat(fileName.split('/').length - 1);
   }

   /**
    * Gets an HTML template loading it into and IceCap instance.
    *
    * @param {string}   filePath - template file path.
    *
    * @param {object}   [options] - IceCap options.
    *
    * @return {string} HTML of template.
    */
   static getIceCapTemplate({ dirName = __dirname, filePath, options = void 0 } = {})
   {
      const file = path.resolve(dirName, dirName !== __dirname ? filePath : `../template/${filePath}`);

      return this._eventbus.triggerSync('typhonjs:ice:cap:create', fs.readFileSync(file, { encoding: 'utf-8' }),
       options);
   }

   /**
    * Returns a file from `template` directory.
    *
    * @param {string} filePath - template file path.
    *
    * @return {string} HTML of template.
    */
   static getTemplate({ dirName = __dirname, filePath } = {})
   {
      const file = path.resolve(dirName, dirName !== __dirname ? filePath : `../template/${filePath}`);

      return fs.readFileSync(file, { encoding: 'utf-8' });
   }

   /**
    * Gets output HTML page title from DocObject or using `title` from {@link TJSDocConfig}.
    *
    * @param {DocObject|string} doc - Target doc object.
    *
    * @returns {string} HTML page title.
    */
   static getTitle(doc = '')
   {
      if (typeof doc !== 'object' && typeof doc !== 'string')
      {
         throw new TypeError(`'doc' is not an 'object' or 'string'.`);
      }

      const name = doc.name || doc.toString();

      if (!name)
      {
         return this._mainConfig.title ? `${this._mainConfig.title} API Documentation` : 'API Documentation';
      }

      return this._mainConfig.title ? `${name} | ${this._mainConfig.title} API Documentation` :
       `${name} | API Documentation`;
   }

   /**
    * Resets the tracked DocDB used for any queries. By default this is set to the main DocDB.
    */
   static reset({ docDB = this._mainDocDB } = {})
   {
      this._docDB = docDB;
   }
}
