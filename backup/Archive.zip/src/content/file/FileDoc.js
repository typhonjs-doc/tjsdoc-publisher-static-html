import fs            from 'fs';

import PublishUtil   from '../../PublishUtil.js';

/**
 * Executes writing class HTML output.
 */
export function onHandlePublish(ev)
{
   if (ev.data.incremental)
   {
      if (ev.data.fileType === 'source') { FileDoc.exec(ev.data); }
   }
   else
   {
      FileDoc.exec(ev.data);
   }
}

/**
 * File output builder.
 *
 * Outputs source code for each file.
 */
class FileDoc
{
   /**
    * Executes writing source code for each file.
    */
   static exec({ docDB, eventbus, filePath = void 0, mainConfig, silent = false } = {})
   {
      const ice = PublishUtil.getIceCapLayout();

      docDB.query(filePath ? { kind: 'ModuleFile', filePath } : { kind: 'ModuleFile' }).each((doc) =>
      {
         const fileName = PublishUtil.getDocFileName(doc);
         const baseUrl = PublishUtil.getFileURLBase(fileName);
         const title = PublishUtil.getTitle(doc);

         ice.load('content', this._buildFileDoc(mainConfig, doc), 'write');
         ice.attr('baseUrl', 'href', baseUrl, 'write');
         ice.text('title', title, 'write');

         eventbus.trigger('tjsdoc:system:file:write', ice.html, fileName, silent);
      });
   }

   /**
    * Build file output HTML.
    *
    * @param {TJSDocConfig}   config - The target project TJSDocConfig instance.
    *
    * @param {DocObject}      doc - target file doc object.
    *
    * @param {EventProxy}     eventbus - An event proxy for the main eventbus.
    *
    * @returns {string} HTML of file page.
    * @private
    */
   static _buildFileDoc(config, doc)
   {
      let fileContent;

      if (config.includeSource) { fileContent = fs.readFileSync(doc.filePath, { encode: 'utf8' }).toString(); }

      const ice = PublishUtil.getIceCapTemplate({ dirName: __dirname, filePath: 'html/file.html' });

      ice.text('title', doc.longname);
      ice.text('content', fileContent);
      ice.drop('emptySourceCode', !!fileContent);

      return ice.html;
   }
}
