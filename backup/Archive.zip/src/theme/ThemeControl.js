import es6Template   from 'es6-template';

const s_LOG_PREPEND = 'tjsdoc-publisher-static-html-theme-control - ';

/**
 *
 */
export default class ThemeEngine
{
   /**
    * @param {PluginEvent} ev - The plugin event.
    */
   static onPluginLoad(ev)
   {
      this._eventbus = ev.eventbus;

      this._eventbus.on('tjsdoc:system:publisher:css:structural:add', this.addStructuralCSS, this);
      this._eventbus.on('tjsdoc:system:publisher:theme:finalize', this.finalizeTheme, this);
   }

   static async onHandlePrePublishAsync()
   {
      this._eventbus.trigger('typhonjs:util:postcss:create',
       { name: 'styles.css', to: 'styles.css', processors: [{ name: 'postcss-cssnext' }] });
   }

   static async onHandlePublishAsync()
   {
      await this.addStructuralCSS({ dirName: __dirname, filePath: 'css/${scope}root.css', scope: 'common/' });
      await this.addStructuralCSS({ dirName: __dirname, filePath: 'css/${scope}media-queries.css', scope: 'common/' });

      await this.addStructuralCSS({ dirName: __dirname, filePath: 'css/${scope}class.css', scope: 'content/class/' });
      await this.addStructuralCSS({ dirName: __dirname, filePath: 'css/${scope}code.css', scope: 'common/' });
      await this.addStructuralCSS({ dirName: __dirname, filePath: 'css/${scope}content.css', scope: 'components/layout/' });
      await this.addStructuralCSS({ dirName: __dirname, filePath: 'css/${scope}details.css', scope: 'components/details/' });
      await this.addStructuralCSS({ dirName: __dirname, filePath: 'css/${scope}drawer.css', scope: 'components/layout/' });
      await this.addStructuralCSS({ dirName: __dirname, filePath: 'css/${scope}example.css', scope: 'common/' });
      await this.addStructuralCSS({ dirName: __dirname, filePath: 'css/${scope}extends-chain.css', scope: 'content/class/' });
      await this.addStructuralCSS({ dirName: __dirname, filePath: 'css/${scope}footer.css', scope: 'components/layout/' });
      await this.addStructuralCSS({ dirName: __dirname, filePath: 'css/${scope}global.css', scope: 'components/layout/' });
      // await this.addStructuralCSS({ dirName: __dirname, filePath: 'css/identifiers.css' });
      await this.addStructuralCSS({ dirName: __dirname, filePath: 'css/${scope}inner-link.css', scope: 'components/layout/' });
      await this.addStructuralCSS({ dirName: __dirname, filePath: 'css/${scope}manual.css', scope: 'content/manual/' });
      await this.addStructuralCSS({ dirName: __dirname, filePath: 'css/${scope}markdown.css', scope: 'common/' });
      await this.addStructuralCSS({ dirName: __dirname, filePath: 'css/${scope}navigation.css', scope: 'components/navigation/' });
      await this.addStructuralCSS({ dirName: __dirname, filePath: 'css/${scope}scrollbar.css', scope: 'components/layout/' });
      await this.addStructuralCSS({ dirName: __dirname, filePath: 'css/${scope}search.css', scope: 'components/layout/' });
      await this.addStructuralCSS({ dirName: __dirname, filePath: 'css/${scope}shared.css', scope: 'common/' });
      await this.addStructuralCSS({ dirName: __dirname, filePath: 'css/${scope}source.css', scope: 'content/source/' });
      await this.addStructuralCSS({ dirName: __dirname, filePath: 'css/${scope}summary.css', scope: 'components/summary/' });
      await this.addStructuralCSS({ dirName: __dirname, filePath: 'css/${scope}test.css', scope: 'content/source/' });
      await this.addStructuralCSS({ dirName: __dirname, filePath: 'css/${scope}toolbar.css', scope: 'components/layout/' });
      await this.addStructuralCSS({ dirName: __dirname, filePath: 'css/${scope}unused.css', scope: 'common/' });
   }

   static async addStructuralCSS({ name = 'styles.css', dirName = void 0, filePath = void 0, ...templateData } = {})
   {
console.error('!!! ThemeControl - addStructuralCSS - 0 - name: ' + name +'; filePath: ' + filePath);

      const structuralFilePath = es6Template(filePath);
      const themeFilePath = es6Template(filePath, templateData);

console.error('!!! ThemeControl - addStructuralCSS - AA - structuralFilePath: ' + structuralFilePath + '; themeFilePath: ' + themeFilePath);

      this._eventbus.trigger('typhonjs:util:postcss:append', { name, dirName, filePath: structuralFilePath });

      const themeCSS = await this._eventbus.triggerAsync('tjsdoc:data:publisher:css:theme:get',
       { name, filePath: themeFilePath });

console.error('!!! ThemeControl - addStructuralCSS - 1 - themeCSS: ' + JSON.stringify(themeCSS));

      if (typeof themeCSS === 'object')
      {
         this._eventbus.trigger('typhonjs:util:postcss:append', themeCSS);
      }
   }

   static async finalizeTheme(ev)
   {
      const result = await this._eventbus.triggerAsync('typhonjs:util:postcss:finalize', { name: 'styles.css' });

console.error('!!!! Publisher - onHandlePostPublishAsync - result.css: ' + JSON.stringify(result.css));

      // const result = await this._eventbus.triggerAsync('typhonjs:util:postcss:finalize:all');

      this._eventbus.trigger('tjsdoc:system:file:write', {
         fileData: result.css,
         filePath: 'css/styles.css',
         logPrepend: s_LOG_PREPEND,
         silent: ev.data.silent
      });
   }
}
