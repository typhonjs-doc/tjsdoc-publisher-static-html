/**
 * Single page builder.
 *
 * "single" means function, variable, typedef, external, etc...
 */
export default class SingleDocBuilder
{
   /**
    * Executes writing each applicable single output file.
    *
    * @param {EventProxy}  eventbus - An event proxy for the main eventbus.
    */
   static exec(eventbus)
   {
      const ice = eventbus.triggerSync('tjsdoc:system:publisher:ice:cap:layout:get');

      ice.autoClose = false;

      const queries =
      [
         { title: 'Functions', query: { kind: 'ModuleFunction' } },
         { title: 'Variables', query: { category: 'ModuleVariable' } },
         { title: 'Typedefs', query: { kind: 'VirtualTypedef' } }
      ];

      for (const query of queries)
      {
         const docs = eventbus.triggerSync('tjsdoc:data:docdb:find', query.query);

         if (!docs.length) { continue; }

         const fileName = eventbus.triggerSync('tjsdoc:system:publisher:doc:file:name:get', docs[0]);
         const baseUrl = eventbus.triggerSync('tjsdoc:system:publisher:file:url:base:get', fileName);

         const title = eventbus.triggerSync('tjsdoc:system:publisher:title:get', query.title);

         ice.load('content', SingleDocBuilder._buildSingleDoc(eventbus, title, query), 'write');
         ice.attr('baseUrl', 'href', baseUrl, 'write');
         ice.text('title', title, 'write');

         eventbus.trigger('tjsdoc:system:file:write', ice.html, fileName);
      }
   }

   /**
    * Build single output.
    *
    * @param {EventProxy}  eventbus - An event proxy for the main eventbus.
    *
    * @param {string}      title - target kind property.
    *
    * @returns {string} HTML of single output.
    * @private
    */
   static _buildSingleDoc(eventbus, title, query)
   {
      const ice = eventbus.triggerSync('tjsdoc:system:publisher:ice:cap:template:get', 'single.html');

      ice.text('title', title);

      // All docs of given kind.
      const accessDocs = eventbus.triggerSync('tjsdoc:data:docdb:find:access:docs', query.query);

      // Get shared access docs between summary and detail output.

      ice.load('summaries', eventbus.triggerSync('tjsdoc:system:publisher:doc:html:summary:get', 'Summary', accessDocs),
       'append');

      ice.load('details', eventbus.triggerSync('tjsdoc:system:publisher:doc:html:detail:get', '', accessDocs));

      return ice.html;
   }
}
