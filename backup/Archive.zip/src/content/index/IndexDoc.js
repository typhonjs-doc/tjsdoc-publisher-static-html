import fs            from 'fs';
import path          from 'path';

import PublishUtil   from '../../PublishUtil.js';

const s_LOG_PREPEND = 'tjsdoc-publisher-static-html-index - ';

/**
 * Executes writing `index.html`.
 *
 * @param {PluginEvent} ev - The plugin event.
 */
export function onHandlePublishAsync(ev)
{
   if (ev.data.incremental)
   {
      if (ev.data.fileType === 'index') { IndexDoc.exec(ev.data); }
   }
   else
   {
      IndexDoc.exec(ev.data);
   }
}

/**
 * Index output builder.
 *
 * Outputs the main `index.html` file for generated documentation including any README.md or other file specified by
 * `config.index`.
 */
class IndexDoc
{
   /**
    * Executes writing `index.html`.
    *
    * @param {EventProxy}  eventbus - An event proxy for the main eventbus.
    */
   static exec({ eventbus, mainConfig, silent } = {})
   {
      const ice = eventbus.triggerSync('tjsdoc:system:publisher:ice:cap:layout:get');
      const title = PublishUtil.getTitle();

      ice.load('content', this._buildIndexDoc(mainConfig, eventbus));
      ice.text('title', title, 'write');

      eventbus.trigger('tjsdoc:system:file:write', {
         fileData: ice.html,
         filePath: 'index.html',
         logPrepend: s_LOG_PREPEND,
         silent
      });
   }

   /**
    * Build index output including converting `config.index` to HTML from markdown.
    *
    * @returns {string} html of index output.
    * @private
    */
   static _buildIndexDoc(config, eventbus)
   {
      let indexContent;

      try
      {
         indexContent = fs.readFileSync(config.index, { encode: 'utf8' }).toString();
      }
      catch (err)
      {
         eventbus.trigger('log:warn', `Could not open 'config.index': ${config.index}`);

         return PublishUtil.getTitle();
      }

      const ice = PublishUtil.getIceCapTemplate({ dirName: __dirname, filePath: 'html/index.html' });
      const ext = path.extname(config.index);

      switch (ext)
      {
         case '.markdown':
         case '.md':
         case '.MD':
            ice.load('index', eventbus.triggerSync('typhonjs:util:markdown:render', { markdown: indexContent }));
            break;

         default:
            ice.load('index', indexContent);
            break;
      }

      return ice.html;
   }
}
