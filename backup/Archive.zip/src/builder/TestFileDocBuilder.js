import fs from 'fs';

/**
 * Test file output HTML builder.
 */
export default class TestFileDocBuilder
{
   /**
    * Executes building output HTML.
    *
    * @param {EventProxy}  eventbus - An event proxy for the main eventbus.
    */
   static exec(eventbus)
   {
      const config = eventbus.triggerSync('tjsdoc:data:config:get');
      const docs = eventbus.triggerSync('tjsdoc:data:docdb:find', { kind: 'ModuleTestFile' });
      const ice = eventbus.triggerSync('tjsdoc:system:publisher:ice:cap:layout:get');

      for (const doc of docs)
      {
         const fileName = eventbus.triggerSync('tjsdoc:system:publisher:doc:file:name:get', doc);
         const baseUrl = eventbus.triggerSync('tjsdoc:system:publisher:file:url:base:get', fileName);
         const title = eventbus.triggerSync('tjsdoc:system:publisher:title:get', doc);

         ice.load('content', TestFileDocBuilder._buildFileDoc(config, doc, eventbus), 'write');
         ice.attr('baseUrl', 'href', baseUrl, 'write');
         ice.text('title', title, 'write');

         eventbus.trigger('tjsdoc:system:file:write', ice.html, fileName);
      }
   }

   /**
    * Build test file output HTML.
    *
    * @param {TJSDocConfig}   config - The target project TJSDocConfig instance.
    *
    * @param {DocObject}      doc - target file doc object.
    *
    * @param {EventProxy}     eventbus - An event proxy for the main eventbus.
    *
    * @returns {string} HTML of file output.
    * @private
    */
   static _buildFileDoc(config, doc, eventbus)
   {
      let fileContent;

      if (config.includeSource) { fileContent = fs.readFileSync(doc.filePath, { encode: 'utf8' }).toString(); }

      const ice = eventbus.triggerSync('tjsdoc:system:publisher:ice:cap:template:get', 'file.html');

      ice.text('title', doc.longname);
      ice.text('content', fileContent);
      ice.drop('emptySourceCode', !!fileContent);

      return ice.html;
   }
}
