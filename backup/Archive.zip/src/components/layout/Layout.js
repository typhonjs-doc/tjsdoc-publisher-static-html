import path          from 'path';

import PublishUtil   from '../../PublishUtil.js';

/**
 *
 */
export default class Layout
{
   /**
    * Stores the publisher config.
    *
    * @param {PluginEvent} ev - The plugin event.
    */
   static onRuntimePreGenerateAsync(ev)
   {
      this._eventbus = ev.eventbus;
      this._eventbus.on('tjsdoc:system:publisher:ice:cap:layout:get', this.getIceCapLayout, this);

      this._pubConfig = ev.data.pubConfig;
   }

   /**
    * Gets the common HTML layout including the left-hand navigation. The default left-hand navigation is loaded by
    * triggering 'tjsdoc:system:publisher:ice:cap:nav:get' which invokes `getIceCapNav`. To provide a new left-hand
    * navigation register a new event binding to return the IceCap / HTML instance and pass in this event path to
    * load it.
    *
    * @param {string}   [navEvent='tjsdoc:system:publisher:ice:cap:nav:get'] - Optional event to trigger sync to receive
    *                                                                          the left-hand navigation HTML.
    *
    * @param {string}   [navData] - Optional data passed to event binding building the left-hand navigation.
    *
    * @return {IceCap} layout output.
    */
   static getIceCapLayout(navEvent = 'tjsdoc:system:publisher:ice:cap:nav:get', navData = void 0)
   {
      const ice = PublishUtil.getIceCapTemplate(
       { dirName: __dirname, filePath: 'html/layout.html', options: { autoClose: false } });

      if (typeof global.$$tjsdoc_version === 'string')
      {
         ice.text('tjsdocVersion', `(${global.$$tjsdoc_version})`);
      }
      else
      {
         ice.drop('tjsdocVersion');
      }

      const overflowMenuItemsLength = this._pubConfig._overflowMenuItems.length;

      const mainMenuItems = [...this._pubConfig._mainMenuItems];

      // Add the overflow menu icon if overflow menu items exist.
      if (overflowMenuItemsLength)
      {
         mainMenuItems.push({ cssClass: 'material-icons tjsdoc-toolbar-button-overflow', label: 'more_vert' });
      }

      ice.loop('mainMenuItem', mainMenuItems, (i, entry, ice) =>
      {
         if (entry.label) { ice.text('mainMenuItem', entry.label); }
         if (entry.href) { ice.attr('mainMenuItem', 'href', entry.href); }
         if (entry.target) { ice.attr('mainMenuItem', 'target', entry.target); }

         if (entry.cssClass) { ice.attr('mainMenuItem', 'class', entry.cssClass); }
         if (entry.cssID) { ice.attr('mainMenuItem', 'id', entry.cssID); }
      });

      // Add overflow menu items or remove the overflow menu link.
      if (overflowMenuItemsLength)
      {
         const overflowMenuItems = [...this._pubConfig._overflowMenuItems];

         const lastItem = overflowMenuItems[overflowMenuItemsLength - 1];

         // Remove any separator that is the last item.
         if (typeof lastItem === 'object' && lastItem.separator) { overflowMenuItems.pop(); }

         ice.loop('overflowMenuItem', overflowMenuItems, (cntr, entry, ice) =>
         {
            // If the entry is a separator then add it.
            if (entry.separator)
            {
               ice.attr('overflowMenuItem', 'class', 'mdc-list-divider', 'write');
               ice.attr('overflowMenuItem', 'role', 'separator', 'write');
            }
            else // Add the menu item.
            {
               if (entry.label) { ice.text('overflowMenuItem', entry.label); }
               if (entry.href) { ice.attr('overflowMenuItem', 'data-href', entry.href); }
               if (entry.target) { ice.attr('overflowMenuItem', 'data-target', entry.target); }

               if (entry.cssClass) { ice.attr('overflowMenuItem', 'class', ` ${entry.cssClass}`); }
               if (entry.cssID) { ice.attr('overflowMenuItem', 'id', ` ${entry.cssID}`); }
            }
         });
      }
      else
      {
         ice.drop('overflowMenuLink', true);
      }

      // see StaticFileBuilder#exec
      ice.loop('userScript', this._pubConfig.scripts, (i, userScript, ice) =>
      {
         const name = `user/scripts/${i}-${path.basename(userScript)}`;

         ice.attr('userScript', 'src', name);
      });

      ice.loop('userStyle', this._pubConfig.styles, (i, userStyle, ice) =>
      {
         const name = `user/css/${i}-${path.basename(userStyle)}`;

         ice.attr('userStyle', 'href', name);
      });

      ice.load('nav', this._eventbus.triggerSync(navEvent, navData));

      return ice;
   }
}
