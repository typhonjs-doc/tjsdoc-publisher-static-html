import path from 'path';

/**
 * Copies all static resources from template.
 */
export function onHandlePublish(ev)
{
   if (!ev.data.incremental) { StaticFileBuilder.exec(ev.data); }
}

/**
 * Static file output builder.
 */
class StaticFileBuilder
{
   /**
    * Copies all static resources from template.
    *
    * @param {EventProxy}  eventbus - An event proxy for the main eventbus.
    */
   static exec({ eventbus, pubConfig, silent } = {})
   {
      eventbus.trigger('typhonjs:util:file:copy', path.resolve(__dirname, '../../template/css'), './css', silent);
      eventbus.trigger('typhonjs:util:file:copy', path.resolve(__dirname, '../../template/script'), './script', silent);
      eventbus.trigger('typhonjs:util:file:copy', path.resolve(__dirname, '../../template/image'), './image', silent);

      eventbus.trigger('typhonjs:util:file:copy', path.resolve(__dirname,
       '../../node_modules/material-components-web/dist/material-components-web.css'),
        './css/material-components-web.css', silent);

      eventbus.trigger('typhonjs:util:file:copy', path.resolve(__dirname,
       '../../node_modules/material-components-web/dist/material-components-web.js'),
        './script/material-components-web.js', silent);

      eventbus.trigger('typhonjs:util:file:copy', path.resolve(__dirname,
       '../../node_modules/velocity-animate/velocity.js'), './script/velocity.js', silent);

      eventbus.trigger('typhonjs:util:file:copy', path.resolve(__dirname, '../../node_modules/zepto/dist/zepto.js'),
       './script/zepto.js', silent);

      // see DocBuilder#_buildLayoutDoc
      const scripts = pubConfig.scripts || [];

      for (let i = 0; i < scripts.length; i++)
      {
         const userScript = scripts[i];
         const name = `./user/script/${i}-${path.basename(userScript)}`;

         eventbus.trigger('typhonjs:util:file:copy', userScript, name, silent);
      }

      const styles = pubConfig.styles || [];

      for (let i = 0; i < styles.length; i++)
      {
         const userStyle = styles[i];
         const name = `./user/css/${i}-${path.basename(userStyle)}`;

         eventbus.trigger('typhonjs:util:file:copy', userStyle, name, silent);
      }
   }
}
