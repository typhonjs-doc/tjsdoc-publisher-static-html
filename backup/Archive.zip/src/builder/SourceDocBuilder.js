import fs         from 'fs';
import path       from 'path';

import dateForUTC from '../utils/dateForUTC.js';

/**
 * Source output builder.
 */
export default class SourceDocBuilder
{
   /**
    * Executes writing source index.
    *
    * @param {EventProxy}  eventbus - An event proxy for the main eventbus.
    */
   static exec(eventbus)
   {
      const ice = eventbus.triggerSync('tjsdoc:system:publisher:ice:cap:layout:get');
      const fileName = 'source.html';
      const baseUrl = eventbus.triggerSync('tjsdoc:system:publisher:file:url:base:get', fileName);
      const title = eventbus.triggerSync('tjsdoc:system:publisher:title:get', 'Source');

      ice.attr('baseUrl', 'href', baseUrl);
      ice.load('content', SourceDocBuilder._buildSourceHTML(eventbus));
      ice.text('title', title, 'write');

      eventbus.trigger('tjsdoc:system:file:write', ice.html, fileName);
   }

   /**
    * Build source list output HTML.
    *
    * @param {EventProxy}  eventbus - An event proxy for the main eventbus.
    *
    * @returns {string} HTML of source list.
    * @private
    */
   static _buildSourceHTML(eventbus)
   {
      const ice = eventbus.triggerSync('tjsdoc:system:publisher:ice:cap:template:get', 'source.html');
      const docs = eventbus.triggerSync('tjsdoc:data:docdb:find', { kind: 'file' });
      const config = eventbus.triggerSync('tjsdoc:data:config:get');

      const useCoverage = config.docCoverage;

      const coverage = eventbus.triggerSync('tjsdoc:publisher:get:doc:coverage');

      let coverageFiles;

      if (useCoverage) { coverageFiles = coverage.files; }

      ice.drop('coverageBadge', !useCoverage);
      ice.attr('files', 'data-use-coverage', !!useCoverage);

      if (useCoverage)
      {
         const actual = coverage.actualCount;
         const expect = coverage.expectCount;
         const coverageCount = `${actual}/${expect}`;

         ice.text('totalCoverageCount', coverageCount);
      }

      ice.loop('file', docs, (i, doc, ice) =>
      {
         const absFilePath = path.resolve(config._dirPath, doc.filePath);
         const content = fs.readFileSync(absFilePath).toString();
         const lines = content.split('\n').length - 1;
         const stat = fs.statSync(absFilePath);
         const date = dateForUTC(stat.ctime);

         let coverageRatio;
         let coverageCount;
         let undocumentLines;

         if (useCoverage && coverageFiles[doc.longname])
         {
            const actual = coverageFiles[doc.longname].actualCount;
            const expect = coverageFiles[doc.longname].expectCount;

            coverageRatio = `${Math.floor(100 * actual / expect)} %`;
            coverageCount = `${actual}/${expect}`;

            undocumentLines = coverageFiles[doc.longname].undocumentLines.sort().join(',');
         }
         else
         {
            coverageRatio = '-';
         }

         const identifierDocs = eventbus.triggerSync('tjsdoc:data:docdb:find',
          { longname: { left: `${doc.longname}~` }, kind: ['class', 'function', 'variable'] });

         const identifiers = identifierDocs.map((doc) =>
         {
            return eventbus.triggerSync('tjsdoc:system:publisher:doc:html:link:get', doc.longname);
         });

         if (undocumentLines)
         {
            const url = eventbus.triggerSync('tjsdoc:system:publisher:doc:url:get', doc);

            const link = eventbus.triggerSync('tjsdoc:system:publisher:doc:html:file:link:get', doc).replace(/href=".*\.html"/,
             `href="${url}#errorLines=${undocumentLines}"`);

            ice.load('filePath', link);
         }
         else
         {
            ice.load('filePath', eventbus.triggerSync('tjsdoc:system:publisher:doc:html:file:link:get', doc));
         }

         ice.text('coverage', coverageRatio);
         ice.text('coverageCount', coverageCount);
         ice.text('lines', lines);
         ice.text('updated', date);
         ice.text('size', `${stat.size} byte`);
         ice.load('identifier', identifiers.join('\n') || '-');
      });

      return ice.html;
   }
}
