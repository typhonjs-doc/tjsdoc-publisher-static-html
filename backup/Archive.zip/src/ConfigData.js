import fs   from 'fs';

/**
 * Defines the data used by typhonjs-config-resolver to validate static HTML publisher / config.publisherOptions.
 */
export default class ConfigData
{
   /**
    * @returns {ConfigResolverData}
    */
   static createResolverData()
   {
      return {
         defaultValues: ConfigData.defaultValues(),
         postValidate: ConfigData.postValidate(),
         preValidate: ConfigData.preValidate(),
         upgradeMergeList: ConfigData.upgradeMergeList()
      };
   }

   /**
    * Generates the default values data structure set to a PubStaticHTMLConfig object after extended config files are
    * resolved. Any fields not already set will be set to the default values defined before.
    *
    * @returns {object}
    */
   static defaultValues()
   {
      return {
         'publisherOptions._manualConfig': [],

         'publisherOptions._manualGlobs': { all: [], sections: {} },

         'publisherOptions.debug': false,

         'publisherOptions.scripts': [],

         'publisherOptions.styles': []
      };
   }

   /**
    * Generates the post-validation data structure for bulk checking a PubStaticHTMLConfig object. If a field is
    * present it will be validated otherwise no particular fields are checked.
    *
    * @returns {object}
    */
   static postValidate()
   {
      return {
         'publisherOptions._manualConfig':
         {
            required: true,
            test: 'array',
            expected: (entry) =>
             typeof entry === 'object' && typeof entry.label === 'string' && Array.isArray(entry.paths),
            message: `manual config is malformed`
         },

         'publisherOptions.debug': { required: false, test: 'entry', type: 'boolean' },

         'publisherOptions.manual': { required: false, test: 'entry', type: 'object' },

         'publisherOptions.manual.coverage': { required: false, test: 'entry', type: 'boolean' },

         'publisherOptions.manual.asset': { required: false, test: 'entry', expected: (entry) => fs.existsSync(entry),
          message: `file does not exist` },

         'publisherOptions.manual.index': { required: false, test: 'entry', expected: (entry) => fs.existsSync(entry),
          message: `file does not exist` },

         'publisherOptions.scripts': { required: false, test: 'array', expected: (entry) => fs.existsSync(entry),
          message: `file does not exist` },

         'publisherOptions.styles': { required: false, test: 'array', expected: (entry) => fs.existsSync(entry),
          message: `file does not exist` }
      };
   }

   /**
    * Generates the pre-validation data structure for bulk checking a PubStaticHTMLConfig object. If a field is present
    * it will be validated otherwise no particular fields are checked.
    *
    * @returns {object}
    */
   static preValidate()
   {
      return {
         // Test that files exist for user supplied manual entries.
         'publisherOptions.manual':
         {
            required: false,
            test: 'object',
            expected: (manual) =>
            {
               for (const key in manual)
               {
                  if (Array.isArray(manual[key]))
                  {
                     for (const entry of manual[key])
                     {
                        if (!fs.existsSync(entry)) { return false; }
                     }
                  }
               }

               return true;
            },
            message: `user supplied manual file does not exist`
         }
      };
   }

   /**
    * Returns config keys that are a string and are upgraded to an array or are already an array to be merged.
    *
    * @returns {Array<string>}
    */
   static upgradeMergeList()
   {
      return [
         'scripts',
         'styles'
      ];
   }
}

