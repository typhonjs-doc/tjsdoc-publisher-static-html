import es6Template   from 'es6-template';

import PostCSS       from '../PostCSS.js';

const s_LOG_PREPEND = 'typhonjs-util-theme-engine - ';

/**
 *
 */
export default class ThemeEngine
{
   constructor()
   {
      this._postcss = new PostCSS();
   }

   /**
    * @param {PluginEvent} ev - The plugin event.
    */
   onPluginLoad(ev)
   {
      this._eventbus = ev.eventbus;

      this._eventbus.on('typhonjs:util:theme:engine:create', this.createTheme, this);
      this._eventbus.on('typhonjs:util:theme:engine:css:append', this.structuralCSSAppend, this);
      this._eventbus.on('typhonjs:util:theme:engine:css:append:all', this.structuralCSSAppendAll, this);
      this._eventbus.on('typhonjs:util:theme:engine:css:prepend', this.structuralCSSPrepend, this);
      this._eventbus.on('typhonjs:util:theme:engine:css:prepend:all', this.structuralCSSPrependAll, this);
      this._eventbus.on('typhonjs:util:theme:engine:finalize', this.finalizeTheme, this);
   }

   /**
    * Creates a theme which defaults to just a `styles.css` and `CSSNext` as the only PostCSS processor.
    *
    * @param {string|Array<string>} [files='styles.css'] - A string or array of strings for CSS files associated with
    *                                                      a theme.
    *
    * @param {Array<object>}        [processors=[{ name: 'postcss-cssnext' }]] - PostCSS processors.
    *
    * @returns {Promise.<void>}
    */
   async createTheme({ files = 'styles.css', processors = [{ name: 'postcss-cssnext' }] } = {})
   {
      if (!Array.isArray(files) && typeof files !== 'string')
      {
         throw new TypeError(`'files' is not a 'string' or 'array'.`);
      }

      if (!Array.isArray(processors)) { throw new TypeError(`'processors' is not an 'array'.`); }

      if (typeof files === 'string')
      {
         this._postcss.create({ name: files, to: files, processors });
      }
      else if (Array.isArray(files))
      {
         for (const entry of files)
         {
            this._postcss.create({ name: entry, to: entry, processors });
         }
      }
   }

   async finalizeTheme()
   {
      const themeResources = await this._eventbus.triggerAsync('typhonjs:util:theme:resources:get');

      const copyResources = [];

      if (typeof themeResources === 'object')
      {
         if (Array.isArray(themeResources.append) && themeResources.append.length)
         {
            for (const entry of themeResources.append)
            {
               this._postcss.append(entry);
            }
         }

         if (Array.isArray(themeResources.prepend) && themeResources.prepend.length)
         {
            for (const entry of themeResources.prepend)
            {
               this._postcss.prepend(entry);
            }
         }

         if (Array.isArray(themeResources.copy) && themeResources.copy.length)
         {
            copyResources.push(...themeResources.copy);
         }
      }

// TODO implement finalize:all
      const styles = await this._postcss.finalize({ name: 'styles.css' });

      return {
         css: [{ name: 'styles.css', fileData: styles }],
         copy: copyResources
      };
   }

   async structuralCSSAdd(action = 'append', { name = 'styles.css', dirName = void 0, filePath = void 0,
    ...templateData } = {})
   {
      if (typeof action !== 'string') { throw new TypeError(`'action' is not a 'string'.`); }
      if (action !== 'append' && action !== 'prepend') { throw new Error(`'action' is not 'append' or 'prepend'.`); }

console.error('!!! ThemeEngine - structuralCSSAdd - 0 - name: ' + name +'; filePath: ' + filePath);

      const structuralFilePath = es6Template(filePath);
      const themeFilePath = es6Template(filePath, templateData);

console.error('!!! ThemeEngine - structuralCSSAdd - AA - structuralFilePath: ' + structuralFilePath + '; themeFilePath: ' + themeFilePath);

      action === 'append' ? this._postcss.append({ name, dirName, filePath: structuralFilePath }) :
       this._postcss.prepend({ name, dirName, filePath: structuralFilePath });

      const themeCSS = await this._eventbus.triggerAsync('typhonjs:util:theme:css:get',
       { name, filePath: themeFilePath });

console.error('!!! ThemeEngine - structuralCSSAdd - 1 - themeCSS: ' + JSON.stringify(themeCSS));

      if (Array.isArray(themeCSS))
      {
         for (const entry of themeCSS)
         {
            action === 'append' ? this._postcss.append(entry) : this._postcss.prepend(entry);
         }
      }
      else if (typeof themeCSS === 'object')
      {
         action === 'append' ? this._postcss.append(themeCSS) : this._postcss.prepend(themeCSS);
      }
   }

   async structuralCSSAppend(data = {})
   {
      await this.structuralCSSAdd('append', data);
   }

   async structuralCSSAppendAll(data = [])
   {
      const promises = [];

      for (const entry of data) { promises.push(this.structuralCSSAdd('append', entry)); }

      return Promise.all(promises);
   }

   async structuralCSSPrepend(data = {})
   {
      await this.structuralCSSAdd('prepend', data);
   }

   async structuralCSSPrependAll(data = [])
   {
      const promises = [];

      for (const entry of data) { promises.push(this.structuralCSSAdd('prepend', entry)); }

      return Promise.all(promises);
   }
}
