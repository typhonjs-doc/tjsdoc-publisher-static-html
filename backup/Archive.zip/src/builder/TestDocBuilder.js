/**
 * Test file output HTML builder.
 */
export default class TestDocBuilder
{
   /**
    * Executes building output HTML.
    *
    * @param {EventProxy}  eventbus - An event proxy for the main eventbus.
    */
   static exec(eventbus)
   {
      const testDescribeDoc = eventbus.triggerSync('tjsdoc:data:docdb:find',
       { kind: 'Test', qualifier: 'describe' })[0];

      if (!testDescribeDoc) { return; }

      const ice = eventbus.triggerSync('tjsdoc:system:publisher:ice:cap:layout:get');
      const fileName = eventbus.triggerSync('tjsdoc:system:publisher:doc:file:name:get', testDescribeDoc);
      const baseUrl = eventbus.triggerSync('tjsdoc:system:publisher:file:url:base:get', fileName);
      const title = eventbus.triggerSync('tjsdoc:system:publisher:title:get', 'Test');

      ice.load('content', TestDocBuilder._buildTestDocHTML(eventbus));
      ice.attr('baseUrl', 'href', baseUrl);
      ice.text('title', title);

      eventbus.trigger('tjsdoc:system:file:write', ice.html, fileName);
   }

   /**
    * Build whole test file output HTML.
    *
    * @param {EventProxy}  eventbus - An event proxy for the main eventbus.
    *
    * @returns {string} HTML of whole test file.
    * @private
    */
   static _buildTestDocHTML(eventbus)
   {
      const ice = eventbus.triggerSync('tjsdoc:system:publisher:ice:cap:template:get', 'test.html');
      const testDescribeHTML = TestDocBuilder._buildTestDescribeDocHTML(eventbus);

      ice.load('tests', testDescribeHTML);

      return ice.html;
   }

   /**
    * Build test describe list HTML.
    *
    * @param {EventProxy}  eventbus - An event proxy for the main eventbus.
    *
    * @param {number}      [depth=0] - test depth.
    *
    * @param {string}      [memberof] - target test.
    *
    * @returns {string} html of describe list.
    * @private
    */
   static _buildTestDescribeDocHTML(eventbus, depth = 0, memberof = void 0)
   {
      const cond = { kind: 'Test', qualifier: 'describe', testDepth: depth };

      if (memberof) { cond.memberof = memberof; }

      const describeDocs = eventbus.triggerSync('tjsdoc:data:docdb:find:sorted', 'testId asec', cond);

      let padding;
      let html = '';

      for (const describeDoc of describeDocs)
      {
         const ice = eventbus.triggerSync('tjsdoc:system:publisher:ice:cap:template:get', 'testDescribe.html');

         const testCount = eventbus.triggerSync('tjsdoc:data:docdb:find',
         {
            kind: 'Test',
            qualifier: 'it',
            longname: { regex: new RegExp(`^${describeDoc.longname}\\.`) }
         }).length;

         padding = 10 * (depth + 1);

         ice.attr('testDescribe', 'data-test-depth', depth);

         ice.into('testDescribe', describeDoc, (describeDoc, ice) =>
         {
            const descriptionHTML = eventbus.triggerSync('tjsdoc:system:publisher:doc:html:file:link:get', describeDoc,
             describeDoc.description);

            let testTargetsHTML = [];

            for (const testTarget of describeDoc._custom_test_targets || [])
            {
               testTargetsHTML.push(eventbus.triggerSync('tjsdoc:system:publisher:doc:html:link:get', testTarget[0],
                testTarget[1]));
            }

            testTargetsHTML = testTargetsHTML.join('\n') || '-';

            ice.load('testDescription', descriptionHTML);
            ice.attr('testDescription', 'style', `padding-left: ${padding}px`);
            ice.load('testTarget', testTargetsHTML);
            ice.text('testCount', testCount);
         });

         padding = 10 * (depth + 2);

         const itDocs = eventbus.triggerSync('tjsdoc:data:docdb:find:sorted', 'testId asec',
         {
            kind: 'Test',
            qualifier: 'it',
            testDepth: depth + 1,
            memberof: describeDoc.longname
         });

         ice.loop('testIt', itDocs, (i, itDoc, ice) =>
         {
            const descriptionHTML = eventbus.triggerSync('tjsdoc:system:publisher:doc:html:file:link:get', itDoc,
             itDoc.description);

            let testTargetsHTML = [];

            for (const testTarget of itDoc._custom_test_targets || [])
            {
               testTargetsHTML.push(eventbus.triggerSync('tjsdoc:system:publisher:doc:html:link:get', testTarget[0],
                testTarget[1]));
            }

            testTargetsHTML = testTargetsHTML.join('\n') || '-';

            ice.attr('testIt', 'data-test-depth', depth + 1);
            ice.load('testDescription', descriptionHTML);
            ice.attr('testDescription', 'style', `padding-left: ${padding}px`);
            ice.load('testTarget', testTargetsHTML);
         });

         const innerDescribeHTML = TestDocBuilder._buildTestDescribeDocHTML(eventbus, depth + 1, describeDoc.longname);

         html += `\n${ice.html}\n${innerDescribeHTML}`;
      }

      return html;
   }
}
