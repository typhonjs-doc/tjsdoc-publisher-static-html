import markdown from './markdown.js';

/**
 * shorten description.
 * e.g. ``this is JavaScript. this is Java.`` => ``this is JavaScript.``.
 *
 * @param {DocObject} doc - target doc object.
 * @param {boolean} [asMarkdown=false] - is true, test as markdown and convert to html.
 *
 * @returns {string} shorten description.
 * @todo shorten before process markdown.
 */
export default function shorten(doc, asMarkdown = false)
{
   if (!doc) { return ''; }

   if (doc.summary) { return doc.summary; }

   const desc = doc.description;

   if (!desc) { return ''; }

   let len = desc.length;
   let inSQuote = false;
   let inWQuote = false;
   let inCode = false;

   for (let i = 0; i < desc.length; i++)
   {
      const char1 = desc.charAt(i);
      const char2 = desc.charAt(i + 1);
      const char4 = desc.substr(i, 6);
      const char5 = desc.substr(i, 7);

      if (char1 === '\'')
      {
         inSQuote = !inSQuote;
      }
      else if (char1 === '"')
      {
         inWQuote = !inWQuote;
      }
      else if (char4 === '<code>')
      {
         inCode = true;
      }
      else if (char5 === '</code>')
      {
         inCode = false;
      }

      if (inSQuote || inCode || inWQuote) { continue; }

      if (char1 === '.')
      {
         if (char2 === ' ' || char2 === '\n' || char2 === '<')
         {
            len = i + 1;
            break;
         }
      }
      else if (char1 === '\n' && char2 === '\n')
      {
         len = i + 1;
         break;
      }
   }

   let result = desc.substr(0, len);

   if (asMarkdown)
   {
      result = markdown(result);
   }

   return result;
}
