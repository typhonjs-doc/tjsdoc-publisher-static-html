import path          from 'path';

import PublishUtil   from '../../PublishUtil.js';

/**
 *
 */
export default class Layout
{
   /**
    * Stores the publisher config.
    *
    * @param {PluginEvent} ev - The plugin event.
    */
   static onRuntimePreGenerateAsync(ev)
   {
      this._eventbus = ev.eventbus;
      this._eventbus.on('tjsdoc:system:publisher:ice:cap:layout:get', this.getIceCapLayout, this);

      this._pubConfig = ev.data.pubConfig;
   }

   /**
    * Gets the common HTML layout including the left-hand navigation. The default left-hand navigation is loaded by
    * triggering 'tjsdoc:system:publisher:ice:cap:nav:get' which invokes `getIceCapNav`. To provide a new left-hand
    * navigation register a new event binding to return the IceCap / HTML instance and pass in this event path to
    * load it.
    *
    * @param {string}   [navEvent='tjsdoc:system:publisher:ice:cap:nav:get'] - Optional event to trigger sync to receive
    *                                                                          the left-hand navigation HTML.
    *
    * @param {string}   [navData] - Optional data passed to event binding building the left-hand navigation.
    *
    * @return {IceCap} layout output.
    */
   static getIceCapLayout(navEvent = 'tjsdoc:system:publisher:ice:cap:nav:get', navData = void 0)
   {
      const ice = PublishUtil.getIceCapTemplate(
       { dirName: __dirname, filePath: 'html/layout.html', options: { autoClose: false } });

      if (typeof global.$$tjsdoc_version === 'string')
      {
         ice.text('tjsdocVersion', `(${global.$$tjsdoc_version})`);
      }
      else
      {
         ice.drop('tjsdocVersion');
      }

      if (this._pubConfig._mainMenuLinks.length)
      {
         ice.loop('mainMenuLink', this._pubConfig._mainMenuLinks, (i, entry, ice) =>
         {
            if (entry.label) { ice.text('mainMenuLink', entry.label); }
            if (entry.href) { ice.attr('mainMenuLink', 'href', entry.href); }
            if (entry.target) { ice.attr('mainMenuLink', 'target', entry.target); }

            if (entry.cssClass) { ice.attr('mainMenuLink', 'class', entry.cssClass); }
            if (entry.cssID) { ice.attr('mainMenuLink', 'id', entry.cssID); }
         });
      }

      // see StaticFileBuilder#exec
      ice.loop('userScript', this._pubConfig.scripts, (i, userScript, ice) =>
      {
         const name = `user/scripts/${i}-${path.basename(userScript)}`;

         ice.attr('userScript', 'src', name);
      });

      ice.loop('userStyle', this._pubConfig.styles, (i, userStyle, ice) =>
      {
         const name = `user/css/${i}-${path.basename(userStyle)}`;

         ice.attr('userStyle', 'href', name);
      });

      ice.load('nav', this._eventbus.triggerSync(navEvent, navData));

      return ice;
   }
}
