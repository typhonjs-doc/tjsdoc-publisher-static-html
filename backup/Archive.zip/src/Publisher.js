import path                from 'path';

import PublisherRaw        from 'tjsdoc-publisher-raw-data';
import ThemeEngine         from 'typhonjs-theme-engine';

import ConfigData          from './ConfigData.js';
import PublishDocResolver  from './PublishDocResolver.js';
import PublishUtil         from './PublishUtil.js';

import themeDefault        from 'typhonjs-plugin-theme-default';
import themeDark           from 'typhonjs-plugin-theme-dark';

const s_LOG_PREPEND = 'tjsdoc-publisher-static-html - ';

export default class Publisher
{
   /**
    * Adds all common runtime plugins.
    *
    * @param {PluginEvent} ev - The plugin event.
    */
   static async onPluginLoad(ev)
   {
      const eventbus = ev.eventbus;

      // Adds an event binding to return the config resolver data for the publisher module.
      eventbus.on('tjsdoc:data:config:publisher:resolver:get', () => ConfigData.createResolverData());

      await eventbus.triggerAsync('plugins:async:add:all', [
         { name: 'typhonjs-ice-cap', instance: require('typhonjs-ice-cap') },
         { name: 'typhonjs-theme-engine', instance: new ThemeEngine() },

         { name: 'tjsdoc-publisher-raw-data', instance: PublisherRaw },
         { name: 'tjsdoc-publisher-static-html-util', instance: PublishUtil },

         { name: 'typhonjs-plugin-theme-default', instance: themeDefault },
         // { name: 'typhonjs-plugin-theme-dark', instance: themeDark },

         // These plugins create main menu links so order matters.
         { name: 'tjsdoc-publisher-static-html-index', instance: require('./content/index/IndexDoc') },
         { name: 'tjsdoc-publisher-static-html-manual', instance: require('./content/manual/ManualDoc') },
         { name: 'tjsdoc-publisher-static-html-reference', instance: require('./content/reference/ReferenceDoc') },
         { name: 'tjsdoc-publisher-static-html-source', instance: require('./content/source/SourceDoc') },
         { name: 'tjsdoc-publisher-static-html-test', instance: require('./content/test/TestDoc') },
         { name: 'tjsdoc-publisher-static-html-repo-link', instance: require('./actions/RepoLink') },

         { name: 'tjsdoc-publisher-static-html-doccoverage', instance: require('./actions/coverage/DocCoverage') },
         { name: 'tjsdoc-publisher-static-html-package', instance: require('./actions/PackageCopy') },
         { name: 'tjsdoc-publisher-static-html-search', instance: require('./actions/SearchIndex') },
         { name: 'tjsdoc-publisher-static-html-resources', instance: require('./actions/StaticFileCopy') },

         { name: 'tjsdoc-publisher-static-html-details', instance: require('./components/details/Details') },
         { name: 'tjsdoc-publisher-static-html-layout', instance: require('./components/layout/Layout') },
         { name: 'tjsdoc-publisher-static-html-nav', instance: require('./components/navigation/old/OldNav') },
         { name: 'tjsdoc-publisher-static-html-summary', instance: require('./components/summary/Summary') },

         { name: 'tjsdoc-publisher-static-html-class', instance: require('./content/class/ClassDoc') },
         { name: 'tjsdoc-publisher-static-html-file', instance: require('./content/file/FileDoc') },
         { name: 'tjsdoc-publisher-static-html-single', instance: require('./content/single/SingleDoc') },
         { name: 'tjsdoc-publisher-static-html-test-file', instance: require('./content/test/TestFileDoc') }
      ]);

      // Instances are being loaded into the plugin manager so auto log filtering needs an explicit filter.
      eventbus.trigger('log:filter:add',
      {
         type: 'inclusive',
         name: 'tjsdoc-publisher-static-html',
         filterString: '(tjsdoc-publisher-static-html\/dist|tjsdoc-publisher-static-html\/src)'
      });
   }

   static async onRuntimePreGenerateAsync(ev)
   {
      // Add PublishDocResolver in onPreGenerate so that it executes after CoreDocResolver with the shared
      // event binding.
      await ev.eventbus.triggerAsync('plugins:async:add',
       { name: 'tjsdoc-doc-resolver-publish', instance: new PublishDocResolver() });

      // Set IceCap debug mode if `this._pubConfig.debug` is true. Helps find any errors in template generation.
      ev.eventbus.trigger('typhonjs:ice:cap:debug:set', ev.data.pubConfig.debug);
   }

   static async onHandlePrePublishAsync(ev)
   {
      // Handle special cases for incremental publishing
      if (ev.data.incremental)
      {
         // Incremental publishing is not available when output is compressed.
         if (ev.data.mainConfig.compressOutput)
         {
            throw new Error(
             `${s_LOG_PREPEND}can not incrementally publish as config option 'compressOutput' is enabled.`);
         }

         // If non-minimal incremental publishing then add source coverage.
         if (!ev.data.minimal)
         {
            ev.data.sourceCoverage = ev.data.docDB.getSourceCoverage({ includeFiles: true });
         }
      }
      else
      {
         // Create a 'styles.css' theme for processing / addition of structural CSS.
         // await ev.eventbus.triggerAsync('typhonjs:theme:engine:create', { map: { inline: false } });

         // await ev.eventbus.triggerAsync('typhonjs:theme:engine:create',
          // { files: ['material-components-web.css', 'styles.css'] });
          // { files: ['styles.css', 'material-components-web.css'] });


         // await ev.eventbus.triggerAsync('typhonjs:theme:engine:create',
         //  { files: ['styles.css', 'material-components-web.css'], debug: true });

//          const mcwPath = path.resolve(__dirname, '../node_modules/material-components-web/dist');
//
// console.error('!!!! Publisher - onHandlePrePublishAsync - mcwPath: ' + mcwPath);
//
//          await ev.eventbus.triggerAsync('typhonjs:theme:engine:css:append', {
//             name: 'material-components-web.css',
//             dirName: mcwPath,
//             filePath: './${scope}material-components-web.css',
//             scope: 'css/mcw/'
//          });

         // await ev.eventbus.triggerAsync('typhonjs:theme:engine:create');

         await ev.eventbus.triggerAsync('typhonjs:theme:engine:create', { debug: true });

         // Handle publish all / complete; always add source coverage.
         ev.data.sourceCoverage = ev.data.docDB.getSourceCoverage({ includeFiles: true });
      }

      // Registers current DocDB association.
      PublishUtil.reset(ev.data);

      // Note the compression format extension will automatically be added.
      if (!ev.data.incremental && ev.data.mainConfig.compressOutput)
      {
         ev.eventbus.trigger('tjsdoc:system:file:archive:create',
          { filePath: 'docs', logPrepend: s_LOG_PREPEND, silent: ev.data.silent });
      }
   }

   static async onHandlePublishAsync(ev)
   {
      if (!ev.data.incremental)
      {
         await ev.eventbus.triggerAsync('typhonjs:theme:engine:css:append:all', [
            { dirName: __dirname, filePath: 'css/${scope}root.css', scope: 'common/' },
            { dirName: __dirname, filePath: 'css/${scope}media-queries.css', scope: 'common/' },

            { dirName: __dirname, filePath: 'css/${scope}details.css', scope: 'components/details/' },

            { dirName: __dirname, filePath: 'css/${scope}content.css', scope: 'components/layout/' },
            { dirName: __dirname, filePath: 'css/${scope}drawer.css', scope: 'components/layout/' },
            { dirName: __dirname, filePath: 'css/${scope}footer.css', scope: 'components/layout/' },
            { dirName: __dirname, filePath: 'css/${scope}global.css', scope: 'components/layout/' },
            { dirName: __dirname, filePath: 'css/${scope}inner-link.css', scope: 'components/layout/' },
            { dirName: __dirname, filePath: 'css/${scope}scrollbar.css', scope: 'components/layout/' },
            { dirName: __dirname, filePath: 'css/${scope}search.css', scope: 'components/layout/' },
            { dirName: __dirname, filePath: 'css/${scope}toolbar.css', scope: 'components/layout/' },

            { dirName: __dirname, filePath: 'css/${scope}manual.css', scope: 'content/manual/' },

            { dirName: __dirname, filePath: 'css/${scope}navigation.css', scope: 'components/navigation/' },

            { dirName: __dirname, filePath: 'css/${scope}summary.css', scope: 'components/summary/' },

            { dirName: __dirname, filePath: 'css/${scope}class.css', scope: 'content/class/' },
            { dirName: __dirname, filePath: 'css/${scope}extends-chain.css', scope: 'content/class/' },

            { dirName: __dirname, filePath: 'css/${scope}source.css', scope: 'content/source/' },
            { dirName: __dirname, filePath: 'css/${scope}test.css', scope: 'content/source/' },

            { dirName: __dirname, filePath: 'css/${scope}prettify.css', scope: 'common/' },
            { dirName: __dirname, filePath: 'css/${scope}code.css', scope: 'common/' },
            { dirName: __dirname, filePath: 'css/${scope}example.css', scope: 'common/' },
            { dirName: __dirname, filePath: 'css/${scope}markdown.css', scope: 'common/' },
            { dirName: __dirname, filePath: 'css/${scope}shared.css', scope: 'common/' },
            { dirName: __dirname, filePath: 'css/${scope}unused.css', scope: 'common/' }
         ]);
      }
   }

   static async onHandlePostPublishAsync(ev)
   {
      if (!ev.data.incremental)
      {
         const results = await ev.eventbus.triggerAsync('typhonjs:theme:engine:finalize');

         if (typeof results === 'object')
         {
            if (Array.isArray(results.css) && results.css.length)
            {
               for (const entry of results.css)
               {
console.error('!!! Publisher - onHandlePostPublishAsync - entry keys: ' + JSON.stringify(Object.keys(entry)));
console.error('!!! Publisher - onHandlePostPublishAsync - entry.data keys: ' + JSON.stringify(Object.keys(entry.data)));
                  ev.eventbus.trigger('tjsdoc:system:file:write', {
                     fileData: entry.data.css,
                     filePath: `css/${entry.name}`,
                     logPrepend: s_LOG_PREPEND,
                     silent: ev.data.silent
                  });

                  if (entry.data.map)
                  {
                     ev.eventbus.trigger('tjsdoc:system:file:write', {
                        fileData: entry.data.map,
                        filePath: `css/${entry.name}.map`,
                        logPrepend: s_LOG_PREPEND,
                        silent: ev.data.silent
                     });
                  }

                  // ev.eventbus.trigger('tjsdoc:system:file:write', {
                  //    fileData: entry.fileData,
                  //    filePath: `css/${entry.name}`,
                  //    logPrepend: s_LOG_PREPEND,
                  //    silent: ev.data.silent
                  // });
               }
            }

            if (Array.isArray(results.copy) && results.copy.length)
            {
               for (const entry of results.copy)
               {
                  ev.eventbus.trigger('typhonjs:util:file:copy', {
                     srcPath: entry.fullPath,
                     destPath: entry.filePath,
                     logPrepend: s_LOG_PREPEND,
                     silent: ev.data.silent
                  });
               }
            }
         }

         if (ev.data.mainConfig.compressOutput)
         {
            await ev.eventbus.triggerAsync('typhonjs:util:file:archive:finalize', { logPrepend: s_LOG_PREPEND });
         }
      }

      // Resets DocDB to main DocDB.
      PublishUtil.reset();
   }
}
