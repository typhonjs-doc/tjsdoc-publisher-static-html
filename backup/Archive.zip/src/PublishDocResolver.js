import markdown from './utils/markdown.js';

/**
 * Resolve various publisher related properties in DocDB / TaffyDB data.
 */
export default class PublishDocResolver
{
   /**
    * Resolve various properties.
    *
    * @param {EventProxy}  eventbus - An event proxy for the main eventbus.
    */
   static resolve(eventbus)
   {
      eventbus.trigger('log:info:raw', 'publish resolve: markdown in description');
      PublishDocResolver._resolveMarkdown(eventbus);

      eventbus.trigger('log:info:raw', 'publish resolve: link');
      PublishDocResolver._resolveLink(eventbus);

      eventbus.trigger('log:info:raw', 'publish resolve: test relation');
      PublishDocResolver._resolveTestRelation(eventbus);
   }

   /**
    * Resolve description as markdown.
    *
    * @param {EventProxy}  eventbus - An event proxy for the main eventbus.
    *
    * @private
    */
   static _resolveMarkdown(eventbus)
   {
      const convert = (doc) =>
      {
         for (const key of Object.keys(doc))
         {
            const value = doc[key];

            if (key === 'description' && typeof value === 'string')
            {
               doc[`${key}Raw`] = doc[key];
               doc[key] = markdown(value, false);
            }
            else if (typeof value === 'object' && value)
            {
               convert(value);
            }
         }
      };

      for (const doc of eventbus.triggerSync('tjsdoc:data:docdb:find')) { convert(doc); }
   }

   /**
    * Resolve @link tags as HTML links.
    *
    * @param {EventProxy}  eventbus - An event proxy for the main eventbus.
    *
    * @private
    * @todo Resolve all ``description`` property.
    */
   static _resolveLink(eventbus)
   {
      const link = (str) =>
      {
         if (!str) { return str; }

         return str.replace(/\{@link ([\w#_\-.:~\/$]+)}/g, (str, longname) =>
         {
            return eventbus.triggerSync('tjsdoc:system:publisher:doc:html:link:get', longname, longname);
         });
      };

      eventbus.triggerSync('tjsdoc:data:docdb:query').each((v) =>
      {
         v.description = link(v.description);

         if (v.params)
         {
            for (const param of v.params)
            {
               param.description = link(param.description);
            }
         }

         if (v.properties)
         {
            for (const property of v.properties)
            {
               property.description = link(property.description);
            }
         }

         if (v.return)
         {
            v.return.description = link(v.return.description);
         }

         if (v.throws)
         {
            for (const _throw of v.throws)
            {
               _throw.description = link(_throw.description);
            }
         }

         if (v.see)
         {
            for (let i = 0; i < v.see.length; i++)
            {
               if (v.see[i].indexOf('{@link') === 0)
               {
                  v.see[i] = link(v.see[i]);
               }
               else if (v.see[i].indexOf('<a href') === 0)
               {
                  // ignore
               }
               else
               {
                  v.see[i] = `<a href="${v.see[i]}">${v.see[i]}</a>`;
               }
            }
         }
      });
   }

   /**
    * Resolve tests and identifier relationships adding the following special properties:
    * - ``_custom_tests``: longnames of test doc.
    * - ``_custom_test_targets``: longnames of identifier.
    *
    * @param {EventProxy}  eventbus - An event proxy for the main eventbus.
    *
    * @private
    */
   static _resolveTestRelation(eventbus)
   {
      const testDocs = eventbus.triggerSync('tjsdoc:data:docdb:find', { kind: ['testDescribe', 'testIt'] });

      for (const testDoc of testDocs)
      {
         const testTargets = testDoc.testTargets;

         if (!testTargets) { continue; }

         for (const testTarget of testTargets)
         {
            const doc = eventbus.triggerSync('tjsdoc:data:docdb:find:by:name', testTarget)[0];

            if (doc)
            {
               if (!doc._custom_tests) { doc._custom_tests = []; }

               doc._custom_tests.push(testDoc.longname);

               if (!testDoc._custom_test_targets) { testDoc._custom_test_targets = []; }

               testDoc._custom_test_targets.push([doc.longname, testTarget]);
            }
            else
            {
               if (!testDoc._custom_test_targets) { testDoc._custom_test_targets = []; }

               testDoc._custom_test_targets.push([testTarget, testTarget]);
            }
         }
      }

      // test full description
      for (const testDoc of testDocs)
      {
         const desc = [];
         const parents = (testDoc.memberof.split('~')[1] || '').split('.');

         for (const parent of parents)
         {
            const doc = eventbus.triggerSync('tjsdoc:data:docdb:find', { kind: ['testDescribe', 'testIt'], name: parent })[0];

            if (!doc) { continue; }

            desc.push(doc.descriptionRaw);
         }

         desc.push(testDoc.descriptionRaw);
         testDoc.testFullDescription = desc.join(' ');
      }
   }
}
