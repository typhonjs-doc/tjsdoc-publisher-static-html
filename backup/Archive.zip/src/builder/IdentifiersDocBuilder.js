/**
 * Identifier output builder.
 */
export default class IdentifiersDocBuilder
{
   /**
    * Executes writing identifiers / reference page.
    *
    * @param {EventProxy}  eventbus - An event proxy for the main eventbus.
    */
   static exec(eventbus)
   {
      const ice = eventbus.triggerSync('tjsdoc:system:publisher:ice:cap:layout:get');
      const title = eventbus.triggerSync('tjsdoc:system:publisher:title:get', 'Index');

      ice.load('content', IdentifiersDocBuilder._buildIdentifierDoc(eventbus));
      ice.text('title', title, 'write');

      eventbus.trigger('tjsdoc:system:file:write', ice.html, 'identifiers.html');

      // Create an event binding to retrieve the HTML identifiers (used in ManualDocBuilder).
      eventbus.on('tjsdoc:publisher:get:html:identifiers', () => { return ice.html; });
   }

   /**
    * Build identifier output.
    *
    * @param {EventProxy}  eventbus - An event proxy for the main eventbus.
    *
    * @return {IceCap} built output.
    * @private
    */
   static _buildIdentifierDoc(eventbus)
   {
      const ice = eventbus.triggerSync('tjsdoc:system:publisher:ice:cap:template:get', 'identifiers.html');

      ice.load('classSummary', eventbus.triggerSync('tjsdoc:system:publisher:doc:html:summary:get', null, 'class',
       'Class Summary'), 'append');

      ice.load('interfaceSummary', eventbus.triggerSync('tjsdoc:system:publisher:doc:html:summary:get', null, 'interface',
       'Interface Summary'), 'append');

      ice.load('functionSummary', eventbus.triggerSync('tjsdoc:system:publisher:doc:html:summary:get', null, 'function',
       'Function Summary'), 'append');

      ice.load('variableSummary', eventbus.triggerSync('tjsdoc:system:publisher:doc:html:summary:get', null, 'variable',
       'Variable Summary'), 'append');

      ice.load('typedefSummary', eventbus.triggerSync('tjsdoc:system:publisher:doc:html:summary:get', null, 'typedef',
       'Typedef Summary'), 'append');

      ice.load('externalSummary', eventbus.triggerSync('tjsdoc:system:publisher:doc:html:summary:get', null, 'external',
       'External Summary'), 'append');

      return ice;
   }
}
