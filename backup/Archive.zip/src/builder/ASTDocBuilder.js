/**
 * AST Output Builder.
 *
 * The parsed AST for the project is output to `config.destination`/ast
 */
export default class ASTDocBuilder
{
   /**
    * Executes writing AST output.
    *
    * @param {EventProxy}  eventbus - An event proxy for the main eventbus.
    */
   static exec(eventbus)
   {
      const config = eventbus.triggerSync('tjsdoc:data:config:get');

      // Note the compression format extension will automatically be added.
      if (config.compressData) { eventbus.trigger('tjsdoc:system:file:archive:create', 'ast'); }

      // Write doc data as JSON to 'docData.json'
      const fileDocs = eventbus.triggerSync('tjsdoc:data:docdb:find:sorted', '__docId__ asec', { kind: 'ModuleFile' });

      for (const doc of fileDocs)
      {
         const astJSON = config.compactData ? JSON.stringify(doc.node) : JSON.stringify(doc.node, null, 3);
         const filePath = `ast/${doc.filePath}.json`;

         eventbus.trigger('tjsdoc:system:file:write', astJSON, filePath);
      }

      if (config.compressData) { eventbus.trigger('typhonjs:util:file:archive:finalize'); }
   }
}
