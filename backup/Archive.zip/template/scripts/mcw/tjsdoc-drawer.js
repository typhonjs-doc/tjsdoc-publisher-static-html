/**
 * Provides special handling for the TJSDoc left-hand navigation drawer. Below are overrides to the standard MCW
 * MDCTemporaryDrawer component. In particular the drawer is only fully enabled when TJSDoc enters a minitarized state
 * set by the media query in `drawer.css`. When the width exceeds this media query then the drawer is automatically
 * opened and the associated click and key handlers are disabled. Associated CSS directives are present for the
 * full and minaturized state; for instance the `.content` margin left value which is set to 0 when minaturized.
 */
(function()
{
   var MDCTemporaryDrawer = mdc.drawer.MDCTemporaryDrawer;
   var drawer = new MDCTemporaryDrawer($('.tjsdoc-temporary-drawer')[0]);

   var clickHandler = drawer.foundation_.componentClickHandler_;
   var keyHandler = drawer.foundation_.documentKeydownHandler_;

   var initialized = false;

   var drawerController = function()
   {
      var width = $(window).width();

      if (width < 798 && drawer.open)
      {
         drawer.open = false;
         drawer.foundation_.adapter_.registerInteractionHandler('click', clickHandler);
      }
      else if (width >= 798 && !drawer.open)
      {
         drawer.open = true;
         drawer.foundation_.adapter_.deregisterInteractionHandler('click', clickHandler);
         drawer.foundation_.adapter_.deregisterDocumentKeydownHandler(keyHandler);
      }
   };

   // When the browser loads a page potentially open the navigation drawer.
   $(document).ready(drawerController);

   // When the browser window is resized potentially close / open the navigation drawer.
   $(window).resize(drawerController);

   /**
    * Provides an `onClick` handler for the top left-hand menu. This menu is only shown when TJSDoc enters a
    * minitarized state set by the media query in `toolbar.css`.
    */
   $('.tjsdoc-toolbar-button-drawer').on('click', function() { drawer.open = !drawer.open; });
})();
