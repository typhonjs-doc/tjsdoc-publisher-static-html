import PublishUtil from '../../PublishUtil.js';

const s_LOG_PREPEND = 'tjsdoc-publisher-static-html-test-file - ';

/**
 * Handles adding main menu link.
 *
 * @param {PluginEvent} ev - The plugin event.
 */
export function onHandleConfigAsync(ev)
{
   // Skip processing if no tests are available.
   if (ev.data.mainConfig.test)
   {
      ev.data.pubConfig._mainToolbarOverflowItems.push({ label: 'Test', href: 'test.html' });
      ev.data.pubConfig._mainToolbarOverflowItems.push({ separator: true });
   }
}

/**
 * Executes building output HTML.
 */
export function onHandlePublishAsync(ev)
{
   if (ev.data.incremental)
   {
      if (ev.data.fileType === 'test') { TestDoc.exec(ev.data); }
   }
   else
   {
      TestDoc.exec(ev.data);
   }
}

/**
 * Test file output HTML builder.
 */
class TestDoc
{
   /**
    * Executes building output HTML.
    *
    * @param {DocDB}    docDB - Target DocDB.
    *
    * @param {EventProxy}  eventbus - An event proxy for the main eventbus.
    */
   static exec({ docDB, eventbus, mainConfig, silent } = {})
   {
      // Skip processing if no tests are available.
      if (!mainConfig.test) { return; }

      const testDescribeDoc = docDB.find({ kind: 'Test', qualifier: 'describe' })[0];

      if (!testDescribeDoc) { return; }

      const ice = eventbus.triggerSync('tjsdoc:system:publisher:ice:cap:layout:get');
      const filePath = PublishUtil.getDocFileName(testDescribeDoc);
      const baseUrl = PublishUtil.getFileURLBase(filePath);
      const title = PublishUtil.getTitle('Test');

      ice.load('content', TestDoc._buildTestDocHTML(docDB));
      ice.attr('baseUrl', 'href', baseUrl);
      ice.text('title', title);

      eventbus.trigger('tjsdoc:system:file:write', { fileData: ice.html, filePath, logPrepend: s_LOG_PREPEND, silent });
   }

   /**
    * Build whole test file output HTML.
    *
    * @param {DocDB}    docDB - Target DocDB.
    *
    * @returns {string} HTML of whole test file.
    * @private
    */
   static _buildTestDocHTML(docDB)
   {
      const ice = PublishUtil.getIceCapTemplate({ dirName: __dirname, filePath: 'html/test.html' });
      const testDescribeHTML = TestDoc._buildTestDescribeDocHTML(docDB);

      ice.load('tests', testDescribeHTML);

      return ice.html;
   }

   /**
    * Build test describe list HTML.
    *
    * @param {DocDB}    docDB - Target DocDB.
    *
    * @param {number}   [depth=0] - test depth.
    *
    * @param {string}   [memberof] - target test.
    *
    * @returns {string} html of describe list.
    * @private
    */
   static _buildTestDescribeDocHTML(docDB, depth = 0, memberof = void 0)
   {
      const cond = { kind: 'Test', qualifier: 'describe', testDepth: depth };

      if (memberof) { cond.memberof = memberof; }

      const describeDocs = docDB.findSorted('testId asec', cond);

      let padding;
      let html = '';

      for (const describeDoc of describeDocs)
      {
         const ice = PublishUtil.getIceCapTemplate({ dirName: __dirname, filePath: 'html/testDescribe.html' });

         const testCount = docDB.find(
         {
            kind: 'Test',
            qualifier: 'it',
            longname: { regex: new RegExp(`^${describeDoc.longname}\\.`) }
         }).length;

         padding = 10 * (depth + 1);

         ice.attr('testDescribe', 'data-test-depth', depth);

         ice.into('testDescribe', describeDoc, (describeDoc, ice) =>
         {
            const descriptionHTML = PublishUtil.getDocHTMLFileLink(describeDoc, describeDoc.description);

            let testTargetsHTML = [];

            for (const testTarget of describeDoc._custom_test_targets || [])
            {
               testTargetsHTML.push(PublishUtil.getDocHTMLLink(testTarget[0], testTarget[1]));
            }

            testTargetsHTML = testTargetsHTML.join('\n') || '-';

            ice.load('testDescription', descriptionHTML);
            ice.attr('testDescription', 'style', `padding-left: ${padding}px`);
            ice.load('testTarget', testTargetsHTML);
            ice.text('testCount', testCount);
         });

         padding = 10 * (depth + 2);

         const itDocs = docDB.findSorted('testId asec',
         {
            kind: 'Test',
            qualifier: 'it',
            testDepth: depth + 1,
            memberof: describeDoc.longname
         });

         ice.loop('testIt', itDocs, (i, itDoc, ice) =>
         {
            const descriptionHTML = PublishUtil.getDocHTMLFileLink(itDoc, itDoc.description);

            let testTargetsHTML = [];

            for (const testTarget of itDoc._custom_test_targets || [])
            {
               testTargetsHTML.push(PublishUtil.getDocHTMLLink(testTarget[0], testTarget[1]));
            }

            testTargetsHTML = testTargetsHTML.join('\n') || '-';

            ice.attr('testIt', 'data-test-depth', depth + 1);
            ice.load('testDescription', descriptionHTML);
            ice.attr('testDescription', 'style', `padding-left: ${padding}px`);
            ice.load('testTarget', testTargetsHTML);
         });

         const innerDescribeHTML = TestDoc._buildTestDescribeDocHTML(docDB, depth + 1, describeDoc.longname);

         html += `\n${ice.html}\n${innerDescribeHTML}`;
      }

      return html;
   }
}
