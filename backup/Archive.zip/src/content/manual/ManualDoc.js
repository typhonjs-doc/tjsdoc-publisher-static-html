import cheerio       from 'cheerio';
import fs            from 'fs';
import path          from 'path';

import PublishUtil   from '../../PublishUtil.js';

import markdown      from '../../utils/markdown.js';

const s_LOG_PREPEND = 'tjsdoc-publisher-static-html-manual - ';

/**
 * Handles parsing manual config and glob data.
 *
 * @param {PluginEvent} ev - The plugin event.
 */
export function onHandleConfigAsync(ev)
{
   // Add event binding to directly retrieve the manual globs data.
   ev.eventbus.on('tjsdoc:data:config:publisher:manual:globs:get', () => ev.data.pubConfig._manualGlobs);

   const manual = ev.data.pubConfig.manual;

   // Only process if a manual is defined
   if (manual)
   {
      ev.data.pubConfig._mainMenuLinks.push({ label: 'Manual', href: './manual/index.html' });

      const manualConfig = ev.data.pubConfig._manualConfig;
      const manualGlobs = ev.data.pubConfig._manualGlobs;

      if (typeof manual.index === 'string')
      {
         manualGlobs.all.push(manual.index);
         manualGlobs.sections._index = [manual.index];
      }

      for (const key in manual)
      {
         // Entries that are an array are user supplied entries into the manual so push these files to _manualConfig
         // and _manualGlobs.
         if (Array.isArray(manual[key]))
         {
            // For the label capitalize the first letter at each word boundary.
            manualConfig.push({ label: key.replace(/\b[a-z]/g, (c) => c.toUpperCase()), paths: manual[key] });

            manualGlobs.all.push(...manual[key]);
            manualGlobs.sections[key] = manual[key];
         }
      }
   }
}

/**
 * Executes writing manual based on `publisherOptions.manual`.
 */
export function onHandlePublishAsync(ev)
{
   if (ev.data.incremental)
   {
      if (ev.data.fileType === 'manual') { ManualDoc.exec(ev.data); }
   }
   else
   {
      ManualDoc.exec(ev.data);
   }
}

/**
 * Append CSS
 *
 * @param {PluginEvent} ev - The plugin event.
 */
export function onHandlePrePublishAsync(ev)
{
   // ev.eventbus.trigger('typhonjs:theme:postcss:append',
   //  { name: 'styles.css', dirName: __dirname, filePath: 'css/manual.css' });
}

// Module private ---------------------------------------------------------------------------------------------------

/**
 * Stores the cached left-hand navigation.
 * @ignore
 */
let cachedHTMLNav;

/**
 * Manual output builder.
 */
class ManualDoc
{
   /**
    * Executes writing manual based on `publisherOptions.manual`.
    *
    * @param {EventProxy}  eventbus - An event proxy for the main eventbus.
    */
   static exec({ eventbus, pubConfig, silent = false } = {})
   {
      // Remove cached left-hand navigation.
      cachedHTMLNav = void 0;

      if (!pubConfig.manual) { return; }

      const manualConfig = pubConfig._manualConfig;
      const ice = eventbus.triggerSync('tjsdoc:system:publisher:ice:cap:layout:get');

      ice.autoDrop = false;

      ice.attr('rootContainer', 'class', ' manual-root');

      {
         const filePath = 'manual/index.html';
         const baseUrl = PublishUtil.getFileURLBase(filePath);

         ice.load('content', ManualDoc._buildManualCardIndex(pubConfig), 'write');

         ice.load('nav', ManualDoc._buildManualNav(pubConfig), 'write');

         ice.text('title', 'Manual', 'write');

         ice.attr('baseUrl', 'href', baseUrl, 'write');

         ice.attr('rootContainer', 'class', ' manual-index');

         eventbus.trigger('tjsdoc:system:file:write', {
            fileData: ice.html,
            filePath,
            logPrepend: s_LOG_PREPEND,
            silent
         });

         ice.attr('rootContainer', 'class', ' manual-index', 'remove');
      }

      for (const item of manualConfig)
      {
         if (!item.paths) { continue; }

         for (const itemPath of item.paths)
         {
            const filePath = ManualDoc._getManualOutputFileName(item, itemPath);
            const baseUrl = PublishUtil.getFileURLBase(filePath);

            ice.load('content', ManualDoc._buildManual(item, itemPath), 'write');
            ice.load('nav', ManualDoc._buildManualNav(pubConfig), 'write');
            ice.text('title', item.label, 'write');
            ice.attr('baseUrl', 'href', baseUrl, 'write');

            eventbus.trigger('tjsdoc:system:file:write', {
               fileData: ice.html,
               filePath,
               logPrepend: s_LOG_PREPEND,
               silent
            });
         }
      }

      if (pubConfig.manual.asset)
      {
         eventbus.trigger('typhonjs:util:file:copy', {
            srcPath: pubConfig.manual.asset,
            destPath: 'manual/asset',
            logPrepend: s_LOG_PREPEND,
            silent
         });
      }
   }

   /**
    * Build manual navigation.
    *
    * @param {EventProxy}           eventbus - An event proxy for the main eventbus.
    *
    * @param {ManualConfigItem[]}   manualConfig - target manual config.
    *
    * @return {IceCap} built navigation
    * @private
    */
   static _buildManualNav(pubConfig)
   {
      // Return a cached version of the left-hand navigation.
      if (cachedHTMLNav) { return cachedHTMLNav; }

      // Otherwise build left-hand navigation and cache it.

      const ice = ManualDoc._buildManualIndex(pubConfig);
      const $root = cheerio.load(ice.html).root();

      $root.find('.markdown').removeClass('markdown');

      cachedHTMLNav = $root.html();

      return cachedHTMLNav;
   }

   /**
    * Build manual.
    *
    * @param {ManualConfigItem}  item - target manual config item.
    *
    * @param {string}            filePath - target manual file path.
    *
    * @return {IceCap} built manual.
    * @private
    */
   static _buildManual(item, filePath)
   {
      const html = ManualDoc._convertMDToHTML(filePath);
      const ice = PublishUtil.getIceCapTemplate({ dirName: __dirname, filePath: 'html/manual.html' });

      ice.text('title', item.label);
      ice.load('content', html);

      // convert relative src to base url relative src.
      const $root = cheerio.load(ice.html).root();

      $root.find('img').each((i, el) =>
      {
         const $el = cheerio(el);
         const src = $el.attr('src');

         if (!src) { return; }
         if (src.match(/^http[s]?:/)) { return; }
         if (src.charAt(0) === '/') { return; }

         $el.attr('src', `./manual/${src}`);
      });

      $root.find('a').each((i, el) =>
      {
         const $el = cheerio(el);
         const href = $el.attr('href');

         if (!href) { return; }
         if (href.match(/^http[s]?:/)) { return; }
         if (href.charAt(0) === '/') { return; }
         if (href.charAt(0) === '#') { return; }

         $el.attr('href', `./manual/${href}`);
      });

      return $root.html();
   }

   /**
    * Build manual card style index.
    *
    * @param {ManualConfigItem[]}   manualConfig - target manual config.
    *
    * @return {IceCap} built index.
    * @private
    */
   static _buildManualCardIndex(pubConfig)
   {
      const cards = [];

      for (const manualItem of pubConfig._manualConfig)
      {
         for (const filePath of manualItem.paths)
         {
            const type = manualItem.label.toLowerCase();
            const fileName = ManualDoc._getManualOutputFileName(manualItem, filePath);
            const html = ManualDoc._buildManual(manualItem, filePath);
            const $root = cheerio.load(html).root();
            const h1Count = $root.find('h1').length;
            const sectionCount = $root.find('h1,h2,h3,h4,h5').length;

            $root.find('h1').each((i, el) =>
            {
               const $el = cheerio(el);
               const label = $el.text();
               const link = h1Count === 1 ? fileName : `${fileName}#${$el.attr('id')}`;

               let card = `<h1>${label}</h1>`;

               const nextAll = $el.nextAll();

               for (let cntr = 0; cntr < nextAll.length; cntr++)
               {
                  const next = nextAll.get(cntr);
                  const tagName = next.tagName.toLowerCase();

                  if (tagName === 'h1') { return; }

                  const $next = cheerio(next);

                  card += `<${tagName}>${$next.html()}</${tagName}>`;
               }

               cards.push({ label, link, card, type, sectionCount });
            });
         }
      }

      const ice = PublishUtil.getIceCapTemplate({ dirName: __dirname, filePath: 'html/manualCardIndex.html' });

      ice.loop('cards', cards, (i, card, ice) =>
      {
         ice.text('label-inner', card.label);
         ice.attr('label', 'class', `manual-color manual-color-${card.type}`);

         const sectionCount = Math.min((card.sectionCount / 5) + 1, 5);

         ice.attr('label', 'data-section-count', '■'.repeat(sectionCount));

         ice.attr('link', 'href', card.link);
         ice.load('card', card.card);
      });

      if (pubConfig.manual.index)
      {
         const userIndex = ManualDoc._convertMDToHTML(pubConfig.manual.index);

         ice.load('manualUserIndex', userIndex);
      }
      else
      {
         ice.drop('manualUserIndex', true);
      }

      return ice;
   }

   /**
    * Build manual index.
    *
    * @param {ManualConfigItem[]}   manualConfig - target manual config.
    *
    * @return {IceCap} built index.
    * @private
    */
   static _buildManualIndex(pubConfig)
   {
      const ice = PublishUtil.getIceCapTemplate({ dirName: __dirname, filePath: 'html/manualIndex.html' });

      ice.loop('manual', pubConfig._manualConfig, (i, item, ice) =>
      {
         const toc = [];

         for (const filePath of item.paths)
         {
            const fileName = ManualDoc._getManualOutputFileName(item, filePath);
            const html = ManualDoc._convertMDToHTML(filePath);
            const $root = cheerio.load(html).root();
            const h1Count = $root.find('h1').length;
            const sectionCount = $root.find('h1,h2,h3,h4,h5').length;

            $root.find('h1,h2,h3,h4,h5').each((i, el) =>
            {
               const $el = cheerio(el);
               const label = $el.text();
               const indent = `indent-${el.tagName.toLowerCase()}`;

               let link = `${fileName}#${$el.attr('id')}`;

               if (el.tagName.toLowerCase() === 'h1' && h1Count === 1) { link = fileName; }

               toc.push({ label, link, indent, sectionCount });
            });
         }

         ice.attr('manual', 'data-toc-name', item.label.toLowerCase());

         ice.loop('manualNav', toc, (i, tocItem, ice) =>
         {
            if (tocItem.indent === 'indent-h1')
            {
               ice.attr('manualNav', 'class',
                  `${tocItem.indent} manual-color manual-color-${item.label.toLowerCase()}`);

               const sectionCount = Math.min((tocItem.sectionCount / 5) + 1, 5);

               ice.attr('manualNav', 'data-section-count', '■'.repeat(sectionCount));
            }
            else
            {
               ice.attr('manualNav', 'class', tocItem.indent);
            }

            ice.attr('manualNav', 'data-link', tocItem.link.split('#')[0]);
            ice.text('link', tocItem.label);
            ice.attr('link', 'href', tocItem.link);
         });
      });

      return ice;
   }

   /**
    * Get manual file name.
    *
    * @param {ManualConfigItem}  item - target manual config item.
    *
    * @param {string}            filePath - target manual markdown file path.
    *
    * @returns {string} file name.
    * @private
    */
   static _getManualOutputFileName(item, filePath)
   {
      if (item.fileName) { return item.fileName; }

      const fileName = path.parse(filePath).name;

      return `manual/${item.label.toLowerCase()}/${fileName}.html`;
   }

   /**
    * Convert markdown to html. If markdown has only one `h1` and its text is `item.label`, remove the `h1`.
    * because duplication of `h1` in output HTML.
    *
    * @param {string} filePath - target.
    *
    * @returns {string} converted html.
    * @private
    */
   static _convertMDToHTML(filePath)
   {
      const content = fs.readFileSync(filePath).toString();
      const html = markdown(content);
      const $root = cheerio.load(html).root();

      return $root.html();
   }
}
