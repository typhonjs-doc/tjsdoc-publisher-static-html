import escape        from 'escape-html';
import fs            from 'fs';
import path          from 'path';

import parseExample  from './utils/parseExample.js';
import shorten       from './utils/shorten.js';

/**
 * Defines several event bindings which aid in the publishing process.
 *
 * 'tjsdoc:system:publisher:doc:file:name:get' -
 * 'tjsdoc:system:publisher:doc:html:decorator:get' -
 * 'tjsdoc:system:publisher:doc:html:deprecated:get' -
 * 'tjsdoc:system:publisher:doc:html:detail:get' -
 * 'tjsdoc:system:publisher:doc:html:experimental:get' -
 * 'tjsdoc:system:publisher:doc:html:file:link:get' -
 * 'tjsdoc:system:publisher:doc:html:link:get' -
 * 'tjsdoc:system:publisher:doc:html:link:type:get' -
 * 'tjsdoc:system:publisher:doc:html:signature:get' -
 * 'tjsdoc:system:publisher:doc:html:summary:get' -
 * 'tjsdoc:system:publisher:doc:override:method:get' -
 * 'tjsdoc:system:publisher:doc:override:method:description:get' -
 * 'tjsdoc:system:publisher:doc:url:get' -
 * 'tjsdoc:system:publisher:docs:html:link:get' -
 * 'tjsdoc:system:publisher:docs:ice:cap:detail:get' -
 * 'tjsdoc:system:publisher:docs:ice:cap:summary:get' -
 * 'tjsdoc:system:publisher:file:url:base:get' -
 * 'tjsdoc:system:publisher:ice:cap:layout:get' -
 * 'tjsdoc:system:publisher:ice:cap:nav:get' -
 * 'tjsdoc:system:publisher:ice:cap:properties:get' -
 * 'tjsdoc:system:publisher:ice:cap:template:get' - Loads a template file into an ice-cap instance.
 * 'tjsdoc:system:publisher:template:get' - Loads a template file.
 * 'tjsdoc:system:publisher:title:get' -
 */
export default class PublisherEvents
{
   /**
    * Registers and defines implicitly all functions exposed via event bindings.
    *
    * @param {EventProxy}  eventbus - An event proxy for the main eventbus.
    */
   static register(eventbus)
   {
      // Remove any old cached left-hand navigation.
      cachedIceNav = void 0;

      // Register all events on the eventbus.
      eventbus.on('tjsdoc:system:publisher:doc:file:name:get', getDocFileName);
      eventbus.on('tjsdoc:system:publisher:doc:html:decorator:get', getDocHTMLDecorator);
      eventbus.on('tjsdoc:system:publisher:doc:html:deprecated:get', getDocHTMLDeprecated);
      eventbus.on('tjsdoc:system:publisher:doc:html:detail:get', getDocHTMLDetail); //
      eventbus.on('tjsdoc:system:publisher:doc:html:experimental:get', getDocHTMLExperimental);
      eventbus.on('tjsdoc:system:publisher:doc:html:file:link:get', getDocHTMLFileLink);
      eventbus.on('tjsdoc:system:publisher:doc:html:link:get', getDocHTMLLink);
      eventbus.on('tjsdoc:system:publisher:doc:html:link:type:get', getDocHTMLLinkType);
      eventbus.on('tjsdoc:system:publisher:doc:html:signature:get', getDocHTMLSignature);
      eventbus.on('tjsdoc:system:publisher:doc:html:summary:get', getDocHTMLSummary); //
      eventbus.on('tjsdoc:system:publisher:doc:override:method:get', getDocOverrideMethod);
      eventbus.on('tjsdoc:system:publisher:doc:override:method:description:get', getDocOverrideMethodDescription);
      eventbus.on('tjsdoc:system:publisher:doc:url:get', getDocURL);
      eventbus.on('tjsdoc:system:publisher:docs:html:link:get', getDocsHTMLLink);
      eventbus.on('tjsdoc:system:publisher:docs:ice:cap:detail:get', getDocsIceCapDetail);
      eventbus.on('tjsdoc:system:publisher:docs:ice:cap:summary:get', getDocsIceCapSummary);
      eventbus.on('tjsdoc:system:publisher:file:url:base:get', getFileURLBase);
      eventbus.on('tjsdoc:system:publisher:ice:cap:layout:get', getIceCapLayout);
      eventbus.on('tjsdoc:system:publisher:ice:cap:nav:get', getIceCapNav);
      eventbus.on('tjsdoc:system:publisher:ice:cap:properties:get', getIceCapProperties);
      eventbus.on('tjsdoc:system:publisher:ice:cap:template:get', getIceCapTemplate);
      eventbus.on('tjsdoc:system:publisher:template:get', getTemplate);
      eventbus.on('tjsdoc:system:publisher:title:get', getTitle);

      // Define implicit methods below. Note that eventbus is internally referenced. --------------------------------

      /**
       * Get file name for output HTML page from a doc object.
       *
       * @param {DocObject} doc - Target doc object.
       *
       * @returns {string} file name.
       */
      function getDocFileName(doc)
      {
         let longname = doc.longname;

         // Replace any leading relative path `.` with `,` so that the generated doc files are not placed outside of
         // the `config.destination` path, but retain a general indication of where the source files are located.
         if (longname)
         {
            // TODO: Verify on Windows
            longname = longname.replace(/^(?:\.\.\/)+/, (match) => match.replace(/(\.\.)+/g, ',,'));
         }

         switch (doc.kind)
         {
            case 'ModuleAssignment':
            case 'ModuleVariable':
               return 'variable/index.html';

            case 'ModuleFunction':
               return 'function/index.html';

            case 'ClassMember':
            case 'ClassMethod':
            case 'ClassProperty':
            {
               const parentDoc = eventbus.triggerSync('tjsdoc:data:docdb:find', { longname: doc.memberof })[0];

               return getDocFileName(parentDoc);
            }

            case 'VirtualExternal':
               return 'external/index.html';

            case 'VirtualTypedef':
               return 'typedef/index.html';

            case 'ModuleClass':
               return `class/${longname}.html`;

            case 'ModuleFile':
               return `file/${longname}.html`;

            case 'ModuleTestFile':
               return `test-file/${longname}.html`;

            case 'Test':
               return 'test.html';

            default:
               throw new Error('DocBuilder: can not resolve file name.');
         }
      }

      /**
       * Builds decorator description.
       *
       * @param {DocObject} doc - Target doc object.
       *
       * @returns {string} description. if doc does not override ancestor method, returns empty.
       */
      function getDocHTMLDecorator(doc)
      {
         if (!doc.decorators) { return ''; }

         const links = [];

         for (const decorator of doc.decorators)
         {
            const link = getDocHTMLLink(decorator.name, decorator.name, false, 'ModuleFunction');

            links.push(decorator.arguments ? `<li>${link}${decorator.arguments}</li>` : `<li>${link}</li>`);
         }

         if (!links.length) { return ''; }

         return `<ul>${links.join('\n')}</ul>`;
      }

      /**
       * Builds deprecated HTML.
       *
       * @param {DocObject} doc - Target doc object.
       *
       * @returns {string} If doc is not deprecated, returns empty.
       */
      function getDocHTMLDeprecated(doc)
      {
         if (doc.deprecated)
         {
            let deprecated = 'Deprecated';

            if (typeof doc.deprecated === 'string') { deprecated += `: ${doc.deprecated}`; }

            return deprecated;
         }
         else
         {
            return '';
         }
      }

      /**
       * Builds detail output HTML by parent doc.
       *
       * @param {string}   title - Detail title.
       *
       * @param {*[]}      accessDocs - A multi-dimensional array from DocDB with public, private, protected DocObjects.
       *
       * @returns {string} HTML of detail.
       */
      function getDocHTMLDetail(title, accessDocs)
      {
         let html = '';

         for (const accessDoc of accessDocs)
         {
            const docs = accessDoc[1];

            if (!docs.length) { continue; }

            let prefix = '';

            if (docs[0].static) { prefix = 'Static '; }

            const _title = `${prefix}${accessDoc[0]} ${title}`;
            const result = getDocsIceCapDetail(docs, _title);

            if (result) { html += result.html; }
         }

         return html;
      }

      /**
       * Builds experimental HTML.
       *
       * @param {DocObject} doc - Target doc object.
       *
       * @returns {string} If doc object is not experimental, returns empty.
       */
      function getDocHTMLExperimental(doc)
      {
         if (doc.experimental)
         {
            let experimental = 'Experimental';

            if (typeof doc.experimental === 'string') { experimental += `: ${doc.experimental}`; }

            return experimental;
         }
         else
         {
            return '';
         }
      }

      /**
       * Builds HTML link to file page.
       *
       * @param {DocObject}   doc - target doc object.
       *
       * @param {string|null} [text] - link text.
       *
       * @returns {string} HTML of link.
       */
      function getDocHTMLFileLink(doc, text)
      {
         if (!doc) { return ''; }

         let fileDoc;

         if (doc.kind === 'ModuleFile' || doc.kind === 'ModuleTestFile')
         {
            fileDoc = doc;
         }
         else
         {
            const filePath = doc.longname.split('~')[0];

            fileDoc = eventbus.triggerSync('tjsdoc:data:docdb:find',
             { kind: ['ModuleFile', 'ModuleTestFile'], longname: filePath })[0];
         }

         if (!fileDoc) { return ''; }

         if (!text) { text = fileDoc.name; }

         if (doc.kind === 'ModuleFile' || doc.kind === 'ModuleTestFile')
         {
            return `<span><a href="${getDocURL(fileDoc)}">${text}</a></span>`;
         }
         else
         {
            return `<span><a href="${getDocURL(fileDoc)}#lineNumber${doc.lineNumber}">${text}</a></span>`;
         }
      }

      /**
       * build HTML link to identifier.
       *
       * @param {string}   longname - link to
       *
       * @param {string}   [text] - link text. default is name property of doc object.
       *
       * @param {boolean}  [inner=false] - if true, use inner link.
       *
       * @param {string}   [kind] - specify target kind property.
       *
       * @param {string}   [qualifier] - specify target qualifier property.
       *
       * @returns {string} HTML of link.
       */
      function getDocHTMLLink(longname, text = void 0, inner = false, kind = void 0, qualifier = void 0)
      {
         if (!longname) { return ''; }

         if (typeof longname !== 'string') { throw new Error(JSON.stringify(longname)); }

         const doc = eventbus.triggerSync('tjsdoc:data:docdb:find:by:name', longname, kind, qualifier)[0];

         if (!doc)
         {
            // If longname is HTML tag do not escape.
            return longname.startsWith('<') ? `<span>${longname}</span>` : `<span>${escape(text || longname)}</span>`;
         }

         if (doc.kind === 'VirtualExternal')
         {
            text = doc.name;

            return `<span><a href="${doc.externalLink}">${text}</a></span>`;
         }
         else
         {
            text = escape(text || doc.name);

            const url = getDocURL(doc, inner);

            return url ? `<span><a href="${url}">${text}</a></span>` : `<span>${text}</span>`;
         }
      }

      /**
       * Get HTML link of type.
       *
       * @param {string} typeName - type name(e.g. ``number[]``, ``Map<number, string>``)
       *
       * @returns {string} HTML of link.
       * @todo re-implement with parser combinator.
       */
      function getDocHTMLLinkType(typeName)
      {
         // e.g. number[]
         let matched = typeName.match(/^(.*?)\[\]$/);

         if (matched)
         {
            typeName = matched[1];

            return `<span>${getDocHTMLLink(typeName, typeName)}<span>[]</span></span>`;
         }

         // e.g. function(a: number, b: string): boolean
         matched = typeName.match(/function *\((.*?)\)(.*)/);

         if (matched)
         {
            const functionLink = getDocHTMLLink('function');

            if (!matched[1] && !matched[2]) { return `<span>${functionLink}<span>()</span></span>`; }

            let innerTypes = [];

            if (matched[1])
            {
               // bad hack: Map.<string, boolean> => Map.<string\Z boolean>
               // bad hack: {a: string, b: boolean} => {a\Y string\Z b\Y boolean}
               const inner = matched[1]
                .replace(/<.*?>/g, (a) => a.replace(/,/g, '\\Z'))
                 .replace(/{.*?}/g, (a) => a.replace(/,/g, '\\Z').replace(/:/g, '\\Y'));

               innerTypes = inner.split(',').map((v) =>
               {
                  const tmp = v.split(':').map((v) => v.trim());

                  if (tmp.length !== 2)
                  {
                     throw new SyntaxError(`Invalid function type annotation: \`${matched[0]}\``);
                  }

                  const paramName = tmp[0];
                  const typeName = tmp[1].replace(/\\Z/g, ',').replace(/\\Y/g, ':');

                  return `${paramName}: ${getDocHTMLLinkType(typeName)}`;
               });
            }

            let returnType = '';

            if (matched[2])
            {
               const type = matched[2].split(':')[1];

               if (type) { returnType = `: ${getDocHTMLLinkType(type.trim())}`; }
            }

            return `<span>${functionLink}<span>(${innerTypes.join(', ')})</span>${returnType}</span>`;
         }

         // e.g. {a: number, b: string}
         matched = typeName.match(/^\{(.*?)\}$/);

         if (matched)
         {
            if (!matched[1]) { return '{}'; }

            // bad hack: Map.<string, boolean> => Map.<string\Z boolean>
            // bad hack: {a: string, b: boolean} => {a\Y string\Z b\Y boolean}
            const inner = matched[1]
             .replace(/<.*?>/g, (a) => a.replace(/,/g, '\\Z'))
              .replace(/{.*?}/g, (a) => a.replace(/,/g, '\\Z').replace(/:/g, '\\Y'));

            const innerTypes = inner.split(',').map((v) =>
            {
               const tmp = v.split(':').map((v) => v.trim());
               const paramName = tmp[0];

               let typeName = tmp[1].replace(/\\Z/g, ',').replace(/\\Y/g, ':');

               if (typeName.includes('|'))
               {
                  typeName = typeName.replace(/^\(/, '').replace(/\)$/, '');

                  const typeNames = typeName.split('|').map((v) => v.trim());
                  const html = [];

                  for (const unionType of typeNames)
                  {
                     html.push(getDocHTMLLinkType(unionType));
                  }

                  return `${paramName}: ${html.join('|')}`;
               }
               else
               {
                  return `${paramName}: ${getDocHTMLLinkType(typeName)}`;
               }
            });

            return `{${innerTypes.join(', ')}}`;
         }

         // e.g. Map<number, string>
         matched = typeName.match(/^(.*?)\.?<(.*?)>$/);

         if (matched)
         {
            const mainType = matched[1];

            // bad hack: Map.<string, boolean> => Map.<string\Z boolean>
            // bad hack: {a: string, b: boolean} => {a\Y string\Z b\Y boolean}
            const inner = matched[2]
             .replace(/<.*?>/g, (a) => a.replace(/,/g, '\\Z'))
              .replace(/{.*?}/g, (a) => a.replace(/,/g, '\\Z').replace(/:/g, '\\Y'));

            const innerTypes = inner.split(',').map((v) =>
            {
               return v.split('|').map((vv) =>
               {
                  vv = vv.trim().replace(/\\Z/g, ',').replace(/\\Y/g, ':');

                  return getDocHTMLLinkType(vv);
               }).join('|');
            });

            // html
            return `${getDocHTMLLink(mainType, mainType)}<${innerTypes.join(', ')}>`;
         }

         if (typeName.startsWith('...'))
         {
            typeName = typeName.replace('...', '');

            if (typeName.includes('|'))
            {
               const typeNames = typeName.replace('(', '').replace(')', '').split('|');
               const typeLinks = typeNames.map((v) => getDocHTMLLink(v));

               return `...(${typeLinks.join('|')})`;
            }
            else
            {
               return `...${getDocHTMLLink(typeName)}`;
            }
         }
         else if (typeName.startsWith('?'))
         {
            typeName = typeName.replace('?', '');

            return `?${getDocHTMLLink(typeName)}`;
         }
         else
         {
            return getDocHTMLLink(typeName);
         }
      }

      /**
       * Builds identifier signature HTML.
       *
       * @param {DocObject} doc - Target doc object.
       *
       * @returns {string} Signature HTML.
       */
      function getDocHTMLSignature(doc)
      {
         // call signature
         const callSignatures = [];

         if (doc.params)
         {
            for (const param of doc.params)
            {
               const paramName = param.name;

               if (paramName.includes('.')) { continue; } // for object property
               if (paramName.includes('[')) { continue; } // for array property

               const types = [];

               for (const typeName of param.types)
               {
                  types.push(getDocHTMLLinkType(typeName));
               }

               callSignatures.push(`${paramName}: ${types.join(' | ')}`);
            }
         }

         // return signature
         const returnSignatures = [];

         if (doc.return)
         {
            for (const typeName of doc.return.types)
            {
               returnSignatures.push(getDocHTMLLinkType(typeName));
            }
         }

         // type signature
         let typeSignatures = [];

         if (doc.type)
         {
            for (const typeName of doc.type.types)
            {
               typeSignatures.push(getDocHTMLLinkType(typeName));
            }
         }

         // callback is not need type. because type is always function.
         if (doc.kind === 'ModuleFunction')
         {
            typeSignatures = [];
         }

         let html = '';

         if (callSignatures.length)
         {
            html = `(${callSignatures.join(', ')})`;
         }
         else
         {
            switch (doc.kind)
            {
               case 'ClassMethod':
               case 'ModuleFunction':
                  html = !doc.accessor ? '()' : '';
                  break;
            }
         }

         if (returnSignatures.length) { html = `${html}: ${returnSignatures.join(' | ')}`; }
         if (typeSignatures.length) { html = `${html}: ${typeSignatures.join(' | ')}`; }

         return html;
      }

      /**
       * Builds summary output HTML from parent doc.
       *
       * @param {string}   title - Summary title.
       *
       * @param {*[]}      accessDocs - A multi-dimensional array from DocDB with public, private, protected DocObjects.
       *
       * @returns {string} HTML of summary.
       */
      function getDocHTMLSummary(title, accessDocs)
      {
         let html = '';

         for (const accessDoc of accessDocs)
         {
            const docs = accessDoc[1];

            if (!docs.length) { continue; }

            let prefix = '';

            if (docs[0].static) { prefix = 'Static '; }

            const _title = `${prefix}${accessDoc[0]} ${title}`;
            const result = getDocsIceCapSummary(docs, _title);

            if (result) { html += result.html; }
         }

         return html;
      }

      /**
       * Builds method of ancestor class link HTML.
       *
       * @param {DocObject} doc - Target doc object.
       *
       * @returns {string} HTML link. If doc does not override ancestor method, returns empty.
       */
      function getDocOverrideMethod(doc)
      {
         const parentDoc = eventbus.triggerSync('tjsdoc:data:docdb:find:by:name', doc.memberof)[0];

         if (!parentDoc) { return ''; }
         if (!parentDoc._custom_extends_chains) { return ''; }

         const chains = [...parentDoc._custom_extends_chains].reverse();

         for (const longname of chains)
         {
            const superClassDoc = eventbus.triggerSync('tjsdoc:data:docdb:find:by:name', longname)[0];

            if (!superClassDoc) { continue; }

            const superMethodDoc = eventbus.triggerSync('tjsdoc:data:docdb:find',
             { name: doc.name, memberof: superClassDoc.longname })[0];

            if (!superMethodDoc) { continue; }

            return getDocHTMLLink(superMethodDoc.longname, `${superClassDoc.name}#${superMethodDoc.name}`, true);
         }

         return '';
      }

      /**
       * Builds method of ancestor class description.
       *
       * @param {DocObject} doc - Target doc object.
       *
       * @returns {string} Description. If doc does not override ancestor method, returns empty.
       */
      function getDocOverrideMethodDescription(doc)
      {
         const parentDoc = eventbus.triggerSync('tjsdoc:data:docdb:find:by:name', doc.memberof)[0];

         if (!parentDoc) { return ''; }
         if (!parentDoc._custom_extends_chains) { return ''; }

         const chains = [...parentDoc._custom_extends_chains].reverse();

         for (const longname of chains)
         {
            const superClassDoc = eventbus.triggerSync('tjsdoc:data:docdb:find:by:name', longname)[0];

            if (!superClassDoc) { continue; }

            const superMethodDoc = eventbus.triggerSync('tjsdoc:data:docdb:find',
             { name: doc.name, memberof: superClassDoc.longname })[0];

            if (!superMethodDoc) { continue; }

            if (superMethodDoc.descriptionHTML) { return superMethodDoc.descriptionHTML; }
         }

         return '';
      }

      /**
       * Get URL of output HTML page.
       *
       * @param {DocObject} doc - Target doc object.
       *
       * @returns {string} URL of output HTML. It is the relative path from output root dir.
       */
      function getDocURL(doc)
      {
         let inner = false;
         let qualifier = '';

         switch (doc.kind)
         {
            case 'ClassMethod':
               qualifier = doc.accessor ? `-${doc.qualifier}` : '';
               inner = true;
               break;

            case 'ClassMember':
            case 'ClassProperty':
            case 'ModuleAssignment':
            case 'ModuleFunction':
            case 'ModuleVariable':
            case 'VirtualTypedef':
               inner = true;
               break;
         }

         if (inner)
         {
            const scope = doc.static ? 'static' : 'instance';
            const fileName = getDocFileName(doc);

            return `${fileName}#${scope}-${doc.kind.toLowerCase()}${qualifier}-${doc.name}`;
         }
         else
         {
            return getDocFileName(doc);
         }
      }

      /**
       * Builds HTML links to identifiers.
       *
       * @param {string[]} longnames - link to these.
       *
       * @param {string}   [text] - link text. default is name property of doc object.
       *
       * @param {boolean}  [inner=false] - if true, use inner link.
       *
       * @param {string}   [separator='\n'] - used link separator.
       *
       * @returns {string} HTML links.
       */
      function getDocsHTMLLink(longnames, text = void 0, inner = false, separator = '\n')
      {
         if (!longnames) { return ''; }
         if (!longnames.length) { return ''; }

         const links = [];

         for (const longname of longnames)
         {
            if (!longname) { continue; }

            const link = getDocHTMLLink(longname, text, inner);

            links.push(`<li>${link}</li>`);
         }

         if (!links.length) { return ''; }

         return `<ul>${links.join(separator)}</ul>`;
      }

      /**
       * Builds detail output HTML from multiple docs.
       *
       * @param {DocObject[]} docs - Target docs.
       *
       * @param {string}      title - Detail title.
       *
       * @return {IceCap} Detail output.
       */
      function getDocsIceCapDetail(docs, title)
      {
         const ice = getIceCapTemplate('details.html');

         ice.text('title', title);
         ice.drop('title', !docs.length);

         ice.loop('detail', docs, (i, doc, ice) =>
         {
            const scope = doc.static ? 'static' : 'instance';
            const qualifier = doc.kind === 'ClassMethod' && doc.accessor ? `-${doc.qualifier}` : '';

            ice.attr('anchor', 'id', `${scope}-${doc.kind.toLowerCase()}${qualifier}-${doc.name}`);
            ice.text('generator', doc.generator ? '*' : '');
            ice.text('async', doc.async ? 'async' : '');
            ice.text('name', doc.name);
            ice.text('abstract', doc.abstract ? 'abstract' : '');
            ice.text('access', doc.access);
            ice.load('signature', getDocHTMLSignature(doc));
            ice.load('description', doc.descriptionHTML || getDocOverrideMethodDescription(doc));

            switch (doc.kind)
            {
               case 'ClassMethod':
                  if (doc.accessor) { ice.text('kind', doc.qualifier); }
                  else { ice.drop('kind'); }
                  break;

               default:
                  ice.drop('kind');
                  break;
            }

            if (doc.export && doc.importPath && doc.importStyle)
            {
               const link = getDocHTMLFileLink(doc, doc.importPath);

               ice.into('importPath', `import ${doc.importStyle} from '${link}'`, (code, ice) =>
               {
                  ice.load('importPathCode', code);
               });
            }
            else
            {
               ice.drop('importPath');
            }

            switch (doc.kind)
            {
               case 'ClassProperty':
               case 'ClassMember':
               case 'ClassMethod':
                  ice.text('static', doc.static ? 'static' : '');
                  break;

               default:
                  ice.drop('static');
                  break;
            }

            ice.load('source', getDocHTMLFileLink(doc, 'source'));
            ice.text('since', doc.since, 'append');
            ice.load('deprecated', getDocHTMLDeprecated(doc));
            ice.load('experimental', getDocHTMLExperimental(doc));
            ice.text('version', doc.version, 'append');
            ice.load('see', getDocsHTMLLink(doc.see), 'append');
            ice.load('todo', getDocsHTMLLink(doc.todo), 'append');
            ice.load('override', getDocOverrideMethod(doc));
            ice.load('decorator', getDocHTMLDecorator(doc), 'append');

            let isFunction = false;

            switch (doc.kind)
            {
               case 'ClassMethod':
                  isFunction = !doc.accessor;
                  break;

               case 'ModuleFunction':
                  isFunction = true;
                  break;
            }

            if (doc.kind === 'VirtualTypedef' && doc.params && doc.type.types[0] === 'function') { isFunction = true; }

            if (isFunction)
            {
               ice.load('properties', getIceCapProperties(doc.params, 'Params:'));
            }
            else
            {
               ice.load('properties', getIceCapProperties(doc.properties, 'Properties:'));
            }

            // return
            if (doc.return)
            {
               ice.load('returnDescription', doc.return.descriptionHTML);

               const typeNames = [];

               for (const typeName of doc.return.types)
               {
                  typeNames.push(getDocHTMLLinkType(typeName));
               }

               if (typeof doc.return.nullable === 'boolean')
               {
                  const nullable = doc.return.nullable;

                  ice.load('returnType', `${typeNames.join(' | ')} (nullable: ${nullable})`);
               }
               else
               {
                  ice.load('returnType', typeNames.join(' | '));
               }

               ice.load('returnProperties', getIceCapProperties(doc.properties, 'Return Properties:'));
            }
            else
            {
               ice.drop('returnParams');
            }

            // throws
            if (doc.throws)
            {
               ice.loop('throw', doc.throws, (i, exceptionDoc, ice) =>
               {
                  ice.load('throwName', getDocHTMLLink(exceptionDoc.types[0]));
                  ice.load('throwDesc', exceptionDoc.descriptionHTML);
               });
            }
            else
            {
               ice.drop('throwWrap');
            }

            // fires
            if (doc.emits)
            {
               ice.loop('emit', doc.emits, (i, emitDoc, ice) =>
               {
                  ice.load('emitName', getDocHTMLLink(emitDoc.types[0]));
                  ice.load('emitDesc', emitDoc.descriptionHTML);
               });
            }
            else
            {
               ice.drop('emitWrap');
            }

            // listens
            if (doc.listens)
            {
               ice.loop('listen', doc.listens, (i, listenDoc, ice) =>
               {
                  ice.load('listenName', getDocHTMLLink(listenDoc.types[0]));
                  ice.load('listenDesc', listenDoc.descriptionHTML);
               });
            }
            else
            {
               ice.drop('listenWrap');
            }

            // example
            ice.into('example', doc.examples, (examples, ice) =>
            {
               ice.loop('exampleDoc', examples, (i, exampleDoc, ice) =>
               {
                  const parsed = parseExample(exampleDoc);

                  ice.text('exampleCode', parsed.body);
                  ice.text('exampleCaption', parsed.caption);
               });
            });

            // tests
            ice.into('tests', doc._custom_tests, (tests, ice) =>
            {
               ice.loop('test', tests, (i, test, ice) =>
               {
                  const testDoc = eventbus.triggerSync('tjsdoc:data:docdb:find', { longname: test })[0];

                  ice.load('test', getDocHTMLFileLink(testDoc, testDoc.testFullDescription));
               });
            });
         });

         return ice;
      }

      /**
       * Builds summary output HTML from multiple docs.
       *
       * @param {DocObject[]} docs - Target docs.
       *
       * @param {string}      title - Summary title.
       *
       * @param {boolean}     [innerLink=false] - If true, link in summary is inner link.
       *
       * @return {IceCap} Summary output.
       */
      function getDocsIceCapSummary(docs, title, innerLink = false)
      {
         if (docs.length === 0) { return null; }

         const ice = getIceCapTemplate('summary.html');

         ice.text('title', title);

         ice.loop('target', docs, (i, doc, ice) =>
         {
            ice.text('generator', doc.generator ? '*' : '');
            ice.text('async', doc.async ? 'async' : '');
            ice.text('abstract', doc.abstract ? 'abstract' : '');
            ice.text('access', doc.access);
            ice.load('signature', getDocHTMLSignature(doc));
            ice.load('description', shorten(doc, true));
            ice.load('name', getDocHTMLLink(doc.longname, null, innerLink, doc.kind, doc.qualifier));

            switch (doc.kind)
            {
               case 'ClassMethod':
                  if (doc.accessor)
                  {
                     ice.text('kind', doc.qualifier);
                  }
                  else
                  {
                     ice.drop('kind');
                  }
                  break;

               default:
                  ice.drop('kind');
                  break;
            }

            switch (doc.kind)
            {
               case 'ClassProperty':
               case 'ClassMember':
               case 'ClassMethod':
                  ice.text('static', doc.static ? 'static' : '');
                  break;

               default:
                  ice.drop('static');
                  break;
            }

            ice.text('since', doc.since);
            ice.load('deprecated', getDocHTMLDeprecated(doc));
            ice.load('experimental', getDocHTMLExperimental(doc));
            ice.text('version', doc.version);
         });

         return ice;
      }

      /**
       * Gets base URL HTML page.
       *
       * @param {string} fileName - Output file path.
       *
       * @returns {string} Base URL.
       */
      function getFileURLBase(fileName)
      {
         return '../'.repeat(fileName.split('/').length - 1);
      }

      /**
       * Gets the common HTML layout including the left-hand navigation. The default left-hand navigation is loaded by
       * triggering 'tjsdoc:system:publisher:ice:cap:nav:get' which invokes `getIceCapNav`. To provide a new left-hand
       * navigation register a new event binding to return the IceCap / HTML instance and pass in this event path to
       * load it.
       *
       * @param {string}   [navEvent='tjsdoc:system:publisher:ice:cap:nav:get'] - Optional event to trigger sync to receive the
       *                                                                left-hand navigation HTML.
       *
       * @return {IceCap} layout output.
       */
      function getIceCapLayout(navEvent = 'tjsdoc:system:publisher:ice:cap:nav:get')
      {
         const config = eventbus.triggerSync('tjsdoc:data:config:get');
         const pubConfig = eventbus.triggerSync('tjsdoc:data:publisher:config:get');

         const info = eventbus.triggerSync('tjsdoc:data:package:object:format');

         const ice = getIceCapTemplate('layout.html', { autoClose: false });

         if (typeof global.$$tjsdoc_version === 'string')
         {
            ice.text('tjsdocVersion', `(${global.$$tjsdoc_version})`);
         }
         else
         {
            ice.drop('tjsdocVersion');
         }

         if (typeof info === 'object' && info.repository.url)
         {
            ice.attr('repoURL', 'href', info.repository.url);

            if (info.repository.url.match(new RegExp('^https?://github.com/')))
            {
               ice.attr('repoURL', 'class', 'repo-url-github');
            }
         }
         else
         {
            ice.drop('repoURL');
         }

         ice.drop('testLink', !config.test);

         // see StaticFileBuilder#exec
         ice.loop('userScript', pubConfig.scripts, (i, userScript, ice) =>
         {
            const name = `user/script/${i}-${path.basename(userScript)}`;

            ice.attr('userScript', 'src', name);
         });

         ice.loop('userStyle', pubConfig.styles, (i, userStyle, ice) =>
         {
            const name = `user/css/${i}-${path.basename(userStyle)}`;

            ice.attr('userStyle', 'href', name);
         });

         ice.drop('manualHeaderLink', !pubConfig.manual);

         if (pubConfig.manual && pubConfig.manual.globalIndex)
         {
            ice.drop('manualHeaderLink');
         }

         ice.load('nav', eventbus.triggerSync(navEvent));

         return ice;
      }

      /**
       * Builds common navigation output.
       *
       * @return {IceCap} Navigation output.
       */
      function getIceCapNav()
      {
         // Return a cached version of the left-hand navigation if available.
         if (cachedIceNav) { return cachedIceNav; }

         // Otherwise build the cached left-hand navigation.

         const ice = getIceCapTemplate('nav.html');

         const kind =
         [
            'ModuleAssignment',
            'ModuleClass',
            'ModuleFunction',
            'ModuleVariable',
            'VirtualExternal',
            'VirtualTypedef'
         ];

         const allDocs = eventbus.triggerSync('tjsdoc:data:docdb:find', { kind }).filter((v) => !v.builtinVirtual);

         const sortData =
         {
            ModuleClass: { order: 0, text: 'C' },
            ModuleInterface: { order: 1, text: 'I' },
            ModuleFunction: { order: 2, text: 'F' },
            ModuleAssignment: { order: 3, text: 'V' },
            ModuleVariable: { order: 3, text: 'V' },
            VirtualTypedef: { order: 4, text: 'T' },
            VirtualExternal: { order: 5, text: 'E' }
         };

         allDocs.sort((a, b) =>
         {
            const filePathA = a.longname.split('~')[0];
            const filePathB = b.longname.split('~')[0];
            const dirPathA = path.dirname(filePathA);
            const dirPathB = path.dirname(filePathB);
            const kindA = a.interface ? 'ModuleInterface' : a.kind;
            const kindB = b.interface ? 'ModuleInterface' : b.kind;

            if (dirPathA === dirPathB)
            {
               const kindAOrder = sortData[kindA].order;
               const kindBOrder = sortData[kindB].order;

               if (kindAOrder === kindBOrder)
               {
                  return a.longname > b.longname ? 1 : -1;
               }
               else
               {
                  // return kindOrder[kindA] > kindOrder[kindB] ? 1 : -1;
                  return kindAOrder > kindBOrder ? 1 : -1;
               }
            }
            else
            {
               return dirPathA > dirPathB ? 1 : -1;
            }
         });

         let lastDirPath = '.';

         ice.loop('doc', allDocs, (i, doc, ice) =>
         {
            const filePath = doc.longname.split('~')[0];
            const dirPath = path.dirname(filePath);
            const kind = doc.interface ? 'ModuleInterface' : doc.kind;
            const kindText = sortData[kind].text;
            const kindClass = `kind-${kind}`;

            ice.load('name', getDocHTMLLink(doc.longname));
            ice.load('kind', kindText);
            ice.attr('kind', 'class', kindClass);
            ice.text('dirPath', dirPath);
            ice.drop('dirPath', lastDirPath === dirPath);

            lastDirPath = dirPath;
         });

         // Save to cached version.
         cachedIceNav = ice;

         return ice;
      }

      /**
       * Build properties output.
       *
       * @param {ParsedParam[]}  [properties=[]] - Properties in doc object.
       * @param {string}         title - Output title.
       *
       * @return {IceCap} Built properties output.
       */
      function getIceCapProperties(properties = [], title = 'Properties:')
      {
         const ice = getIceCapTemplate('properties.html');

         ice.text('title', title);

         ice.loop('property', properties, (i, prop, ice) =>
         {
            ice.autoDrop = false;
            ice.attr('property', 'data-depth', prop.name.split('.').length - 1);
            ice.text('name', prop.name);
            ice.attr('name', 'data-depth', prop.name.split('.').length - 1);
            ice.load('description', prop.descriptionHTML);

            const typeNames = [];

            for (const typeName of prop.types)
            {
               typeNames.push(getDocHTMLLinkType(typeName));
            }

            ice.load('type', typeNames.join(' | '));

            // appendix
            const appendix = [];

            if (prop.optional)
            {
               appendix.push('<li>optional</li>');
            }

            if ('defaultValue' in prop)
            {
               appendix.push(`<li>default: ${prop.defaultValue}</li>`);
            }

            if (typeof prop.nullable === 'boolean')
            {
               appendix.push(`<li>nullable: ${prop.nullable}</li>`);
            }

            if (appendix.length)
            {
               ice.load('appendix', `<ul>${appendix.join('\n')}</ul>`);
            }
            else
            {
               ice.text('appendix', '');
            }
         });

         if (!properties || properties.length === 0)
         {
            ice.drop('properties');
         }

         return ice;
      }

      /**
       * Gets an HTML template loading it into and IceCap instance.
       *
       * @param {string}   fileName - template file name.
       *
       * @param {object}   [options] - IceCap options.
       *
       * @return {string} HTML of template.
       */
      function getIceCapTemplate(fileName, options = void 0)
      {
         const filePath = path.resolve(__dirname, `../template/${fileName}`);

         return eventbus.triggerSync('typhonjs:ice:cap:create', fs.readFileSync(filePath, { encoding: 'utf-8' }),
          options);
      }

      /**
       * Returns a file from `template` directory.
       *
       * @param {string} fileName - template file name.
       *
       * @return {string} HTML of template.
       */
      function getTemplate(fileName)
      {
         const filePath = path.resolve(__dirname, `../template/${fileName}`);

         return fs.readFileSync(filePath, { encoding: 'utf-8' });
      }

      /**
       * Gets output HTML page title from DocObject or using `title` from {@link TJSDocConfig}.
       *
       * @param {DocObject|string} doc - Target doc object.
       *
       * @returns {string} HTML page title.
       */
      function getTitle(doc = '')
      {
         if (typeof doc !== 'object' && typeof doc !== 'string')
         {
            throw new TypeError(`'doc' is not an 'object' or 'string'.`);
         }

         const config = eventbus.triggerSync('tjsdoc:data:config:get');

         const name = doc.name || doc.toString();

         if (!name)
         {
            return config.title ? `${config.title} API Document` : 'API Document';
         }

         return config.title ? `${name} | ${config.title} API Document` : `${name} | API Document`;
      }
   }
}

// Module private ---------------------------------------------------------------------------------------------------

let cachedIceNav;
