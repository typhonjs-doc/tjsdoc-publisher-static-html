import fs      from 'fs';
import path    from 'path';
import postcss from 'postcss';

export default class PostCSS
{
   constructor()
   {
      this.groups = new Map();
   }

   /**
    * @param {PluginEvent} ev - The plugin event.
    */
   onPluginLoad(ev)
   {
      this._eventbus = ev.eventbus;

      this._eventbus.on('typhonjs:util:postcss:append', this.append, this);
      this._eventbus.on('typhonjs:util:postcss:create', this.create, this);
      this._eventbus.on('typhonjs:util:postcss:finalize', this.finalize, this);
      this._eventbus.on('typhonjs:util:postcss:process', this.process, this);
   }

   append({ name, css, dirName, filePath, from = 'unknown', options, silent = false } = {})
   {
      if (typeof silent !== 'boolean') { throw new TypeError(`'silent' is not a 'boolean'.`); }

      if (!this.groups.has(name))
      {
         if (!silent)
         {
            this._eventbus.trigger('log:warn', `PostCSS append: A processing group does not exist for '${name}'.`);
         }

         return;
      }

      const entry = this.groups.get(name);

      if (typeof css === 'string')
      {
         entry.root.append(postcss.parse(css, { from }));
      }
      else if (typeof filePath === 'string')
      {
         const file = typeof dirName === 'string' ? path.resolve(dirName, filePath) : path.resolve(filePath);

         const cssFile = fs.readFileSync(path.resolve(file), 'utf8');

         entry.root.append(postcss.parse(`\n${cssFile}`, { from: file }));
      }
      else
      {
         if (!silent)
         {
            this._eventbus.trigger('log:error', `PostCSS append: no valid css or file path provided.`);
         }

         throw new Error('PostCSS append: no valid css or file path provided.');
      }
   }

   appendProcess({ name, css, options, silent = false } = {})
   {

   }

   create({ name, options, silent = false, to = 'unknown', map = true, processors = [] } = {})
   {
      if (typeof silent !== 'boolean') { throw new TypeError(`'silent' is not a 'boolean'.`); }

      if (this.groups.has(name))
      {
         if (!silent)
         {
            this._eventbus.trigger('log:warn', `PostCSS create: A processing group already exists for '${name}'.`);
         }

         return;
      }

      this.groups.set(name, new GroupEntry(to, map, processors));
   }

   async finalize({ name, silent = false } = {})
   {
      if (typeof silent !== 'boolean') { throw new TypeError(`'silent' is not a 'boolean'.`); }

      if (!this.groups.has(name))
      {
         if (!silent)
         {
            this._eventbus.trigger('log:warn', `PostCSS append: A processing group does not exist for '${name}'.`);
         }

         return;
      }

      const entry = this.groups.get(name);

      let result = entry.root.toResult({ to: entry.to, map: entry.map });

      if (entry.processors.length)
      {
         result = await postcss(entry.processors).process(result);
      }

      this.groups.delete(name);

      return result;
   }

   process()
   {

   }
}

class GroupEntry
{
   constructor(to, map, processors)
   {
      this.to = to;
      this.map = map;
      this.processors = processors.map((entry) =>
      {
         if (typeof entry === 'object')
         {
            if (entry.instance === 'object')
            {
               return entry.instance;
            }
            else if (typeof entry.name === 'string')
            {
               return entry.options ? require(entry.name)(entry.options) : require(entry.name);
            }
            else
            {
               throw new Error(
                `PostCSS - GroupEntry error: an entry in processors does not include 'name' or 'instance' entries.`);
            }
         }
         else
         {
            throw new Error(`PostCSS - GroupEntry error: an entry in processors is not an 'object'.`);
         }
      });

      this.root = postcss.root();
   }
}
