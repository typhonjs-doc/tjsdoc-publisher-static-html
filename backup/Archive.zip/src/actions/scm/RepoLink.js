import path from 'path';

const s_LOG_PREPEND = 'tjsdoc-publisher-static-html-repo-link - ';

/**
 * Copies all static resources.
 */
export function onHandlePublishAsync(ev)
{
   if (!ev.data.incremental)
   {
      ev.eventbus.trigger('typhonjs:util:file:copy', {
         srcPath: path.resolve(__dirname, './images'),
         destPath: './images/scm',
         logPrepend: s_LOG_PREPEND,
         silent: ev.data.silent
      });
   }
}

/**
 * Handles adding main menu link for any repository.
 *
 * @param {PluginEvent} ev - The plugin event.
 */
export function onRuntimePreGenerateAsync(ev)
{
   if (typeof ev.data.packageInfo === 'object' && ev.data.packageInfo.repository.url)
   {
      const menuEntry = { label: 'Repository', href: ev.data.packageInfo.repository.url, target: '_blank' };

      // Add CSS class for github repo url
      if (ev.data.packageInfo.repository.url.match(new RegExp('^https?://github.com/')))
      {
         menuEntry.cssClass = 'repo-url-github';
      }

      ev.data.pubConfig._mainMenuLinks.push(menuEntry);
   }
}
