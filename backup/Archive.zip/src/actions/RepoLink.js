/**
 * Handles adding main menu link for any repository.
 *
 * @param {PluginEvent} ev - The plugin event.
 */
export function onRuntimePreGenerateAsync(ev)
{
   if (typeof ev.data.packageInfo === 'object' && ev.data.packageInfo.repository.url)
   {
      const menuEntry = { label: 'Repository', href: ev.data.packageInfo.repository.url, target: '_blank' };
console.error('!! RepoLink - onRuntimePreGenerateAsync - ev.data.packageInfo.repository keys: ' + JSON.stringify(Object.keys(ev.data.packageInfo.repository)));
      // Add CSS class for github repo url

      // if (ev.data.packageInfo.repository.url.match(new RegExp('^https?://github.com/')))
      // {
      //    menuEntry.cssClass = 'tjsdoc-toolbar-icon scm-github';
      //    ev.data.pubConfig._mainMenuItems.push(menuEntry);
      // }
      if (ev.data.packageInfo.repository.type)
      {
         menuEntry.cssClass = `tjsdoc-toolbar-icon scm-${ev.data.packageInfo.repository.type}`;
         ev.data.pubConfig._mainMenuItems.push(menuEntry);
      }
      else
      {
         ev.data.pubConfig._overflowMenuItems.push(menuEntry);
         ev.data.pubConfig._overflowMenuItems.push({ separator: true });
      }
   }
}
