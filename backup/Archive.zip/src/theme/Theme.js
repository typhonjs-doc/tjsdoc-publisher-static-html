import fs   from 'fs';
import path from 'path';

const s_LOG_PREPEND = 'tjsdoc-publisher-static-html-theme - ';

/**
 *
 */
export default class Theme
{
   static themeDirName = void 0;
   static postcssPlugins = [];
   static prependCSS = [];

   /**
    * @param {PluginEvent} ev - The plugin event.
    */
   static onPluginLoad(ev)
   {
      if (typeof this.themeDirName !== 'string')
      {
         throw new TypeError(`${s_LOG_PREPEND} error: 'themeDirName' is not a 'string'.`);
      }

      this._eventbus = ev.eventbus;

      this._eventbus.on('tjsdoc:data:publisher:css:theme:get', this.getThemeCSS, this);
   }

   /**
    * Stores the publisher config.
    *
    * @param {PluginEvent} ev - The plugin event.
    */
   static onHandlePrePublishAsync()
   {
      for (const filePath of this.prependCSS)
      {
         this._eventbus.trigger('typhonjs:util:postcss:append',
          { name: 'styles.css', dirName: this.themeDirName, filePath });
      }
   }

   /**
    * Copies images
    *
    * @param {PluginEvent} ev - The plugin event.
    */
   static onHandlePublishAsync(ev)
   {
      const imagePath = path.resolve(this.themeDirName, './images');

      if (!ev.data.incremental && fs.existsSync(imagePath))
      {
         ev.eventbus.trigger('typhonjs:util:file:copy', {
            srcPath: imagePath,
            destPath: './images',
            logPrepend: s_LOG_PREPEND,
            silent: ev.data.silent
         });
      }
   }

   /**
    * Attempts to resolve a theme CSS matching a structural CSS addition.
    *
    * @param name
    * @param filePath
    * @returns {{name: *, dirName: *, filePath: *}}
    */
   static getThemeCSS({ name = void 0, filePath = void 0 } = {})
   {
console.error('!!! Theme - getThemeCSS - name: ' + name +'; filePath: ' + filePath);

      return fs.existsSync(path.resolve(this.themeDirName, filePath)) ?
       { name, dirName: this.themeDirName, filePath } : void 0;
   }
}
