import hljs             from 'highlight.js'; // https://highlightjs.org/
import Markdown         from 'markdown-it';
import markdownItAnchor from 'markdown-it-anchor';
import sanitizeHtml     from 'sanitize-html';

const md = new Markdown({ breaks: false, linkify: true, highlight: s_HIGHLIGHT });

// Add default plugin.
md.use(markdownItAnchor);

// Add rules to wrap tables with mobile responsive `div`.
md.renderer.rules.table_open = () => { return '<div class="table-overflow">\n<table>\n'; };
md.renderer.rules.table_close = () => { return '</table>\n</div>\n'; };

/**
 * Provides a TyphonJS plugin support for `markdown-it`.
 */
export default class MarkdownIt
{
   /**
    * Adds all common runtime plugins.
    *
    * @param {PluginEvent} ev - The plugin event.
    */
   onPluginLoad(ev)
   {
      ev.eventbus.on('typhonjs:util:markdown:html:convert', this.markdown, this);
   }

   /**
    * Convert markdown text to html.
    *
    * @param {string} markdown - markdown text.
    * @param {boolean} [breaks=false] if true, break line. FYI gfm is not breaks.
    *
    * @return {string} HTML.
    */
   markdown({ markdown = '', breaks = false } = {})
   {
      md.set({ breaks });

      return sanitizeHtml(md.render(markdown), s_SANITIZE_OPTIONS);
   }
}

const s_ALLOWED_TAGS = ['span', 'div', 'img', 'h1', 'h2', 'h3', 'h4', 'h5', 'h6', 'blockquote', 'p', 'a', 'ul', 'ol',
 'nl', 'li', 'b', 'i', 'strong', 'em', 'strike', 'code', 'hr', 'br', 'div', 'table', 'thead', 'caption', 'tbody', 'tr',
  'th', 'td', 'code', 'pre'];

const s_ALLOWED_ATTRS = { '*': ['src', 'href', 'title', 'class', 'id', 'name', 'width', 'height', 'target'] };

const s_SANITIZE_OPTIONS = {
   allowedTags: s_ALLOWED_TAGS,
   allowedAttributes: s_ALLOWED_ATTRS
};

const s_HIGHLIGHT = (str, lang) =>
{
   if (lang && hljs.getLanguage(lang))
   {
      try
      {
         return `<pre class="hljs"><code>${hljs.highlight(lang, str, true).value}</code></pre>`;
      }
      catch (__) { /* nop */ }
   }

   return `<pre class="hljs"><code>${Markdown.utils.escapeHtml(str)}</code></pre>`;
};

// import marked from 'marked';
// import escape from 'escape-html';
//
// /**
//  * convert markdown text to html.
//  *
//  * @param {string} text - markdown text.
//  * @param {boolean} [breaks=false] if true, break line. FYI gfm is not breaks.
//  *
//  * @return {string} html.
//  */
// export default function markdown(text, breaks = false)
// {
//    s_MARKED_OPTIONS.breaks = breaks;
//
//    // compiled
//    return marked(text, s_MARKED_OPTIONS);
// }
//
// const s_AVAILABLE_TAGS =
//  ['span', 'a', 'p', 'div', 'img', 'h1', 'h2', 'h3', 'h4', 'h5', 'br', 'hr', 'li', 'ul', 'ol', 'code', 'pre'];
//
// const s_AVAILABLE_ATTRS = ['src', 'href', 'title', 'class', 'id', 'name', 'width', 'height', 'target'];
//
// const s_RENDERER = new marked.Renderer();
//
// // Wrap all generated tables in div with `table-overflow` class to ensure tables have scrollable overflow for
// // mobile responsive design.
// s_RENDERER.table = (header, body) =>
// {
//    return `<div class="table-overflow"><table><thead>${header}</thead><tbody>${body}</tbody></table></div>`;
// };
//
// const s_MARKED_OPTIONS =
// {
//    gfm: true,
//    tables: true,
//    sanitize: true,
//    renderer: s_RENDERER,
//    highlight: (code) =>
//    {
//       return `<code class="source-code prettyprint">${escape(code)}</code>`;
//    },
//    sanitizer: (tag) =>
//    {
//       if (tag.match(/<!--.*-->/)) { return tag; }
//
//       const tagName = tag.match(/^<\/?(\w+)/)[1];
//
//       if (!s_AVAILABLE_TAGS.includes(tagName))
//       {
//          return escape(tag);
//       }
//
//       // sanitized tag
//       return tag.replace(/([\w\-]+)=(["'].*?["'])/g, (_, attr, val) =>
//       {
//          if (!s_AVAILABLE_ATTRS.includes(attr))
//          {
//             return '';
//          }
//
//          if (!val.includes('javascript:'))
//          {
//             return '';
//          }
//
//          return `${attr}=${val}`;
//       });
//    }
// };
