import fs            from 'fs';

import PublishUtil   from '../../PublishUtil.js';

/**
 * Executes building output HTML.
 */
export function onHandlePublish(ev)
{
   if (ev.data.incremental)
   {
      if (ev.data.fileType === 'test') { TestFileDoc.exec(ev.data); }
   }
   else
   {
      TestFileDoc.exec(ev.data);
   }
}

/**
 * Test file output HTML builder.
 */
class TestFileDoc
{
   /**
    * Executes building output HTML.
    *
    * @param {EventProxy}  eventbus - An event proxy for the main eventbus.
    */
   static exec({ docDB, eventbus, filePath, mainConfig, silent } = {})
   {
      // Skip processing if no tests are available.
      if (!mainConfig.test) { return; }

      const ice = PublishUtil.getIceCapLayout();

      const docs = docDB.find(filePath ? { kind: 'ModuleTestFile', filePath } : { kind: 'ModuleTestFile' });

      for (const doc of docs)
      {
         const fileName = PublishUtil.getDocFileName(doc);
         const baseUrl = PublishUtil.getFileURLBase(fileName);
         const title = PublishUtil.getTitle(doc);

         ice.load('content', TestFileDoc._buildFileDoc(mainConfig, doc), 'write');
         ice.attr('baseUrl', 'href', baseUrl, 'write');
         ice.text('title', title, 'write');

         eventbus.trigger('tjsdoc:system:file:write', ice.html, fileName, silent);
      }
   }

   /**
    * Build test file output HTML.
    *
    * @param {TJSDocConfig}   config - The target project TJSDocConfig instance.
    *
    * @param {DocObject}      doc - target file doc object.
    *
    * @returns {string} HTML of file output.
    * @private
    */
   static _buildFileDoc(config, doc)
   {
      let fileContent;

      if (config.includeSource) { fileContent = fs.readFileSync(doc.filePath, { encode: 'utf8' }).toString(); }

      const ice = PublishUtil.getIceCapTemplate({ dirName: __dirname, filePath: 'html/testfile.html' });

      ice.text('title', doc.longname);
      ice.text('content', fileContent);
      ice.drop('emptySourceCode', !!fileContent);

      return ice.html;
   }
}
