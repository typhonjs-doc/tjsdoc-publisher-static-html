import Theme from '../Theme.js';

/**
 *
 */
export default class ThemeLight extends Theme
{
   static themeDirName = __dirname;
   static prependCSS = ['css/components/layout/fonts.css'];
}
