/**
 * Single page builder.
 *
 * "single" means function, variable, typedef, external, etc...
 */
export default class SingleDocBuilder
{
   /**
    * Executes writing each applicable single output file.
    *
    * @param {EventProxy}  eventbus - An event proxy for the main eventbus.
    */
   static exec(eventbus)
   {
      const ice = eventbus.triggerSync('tjsdoc:system:publisher:ice:cap:layout:get');

      ice.autoClose = false;

      const kinds = ['function', 'variable', 'typedef'];

      for (const kind of kinds)
      {
         const docs = eventbus.triggerSync('tjsdoc:data:docdb:find', { kind });

         if (!docs.length) { continue; }

         const fileName = eventbus.triggerSync('tjsdoc:system:publisher:doc:file:name:get', docs[0]);
         const baseUrl = eventbus.triggerSync('tjsdoc:system:publisher:file:url:base:get', fileName);

         let title = kind.replace(/^(\w)/, (c) => c.toUpperCase());

         title = eventbus.triggerSync('tjsdoc:system:publisher:title:get', title);

         ice.load('content', SingleDocBuilder._buildSingleDoc(eventbus, kind), 'write');
         ice.attr('baseUrl', 'href', baseUrl, 'write');
         ice.text('title', title, 'write');

         eventbus.trigger('tjsdoc:system:file:write', ice.html, fileName);
      }
   }

   /**
    * Build single output.
    *
    * @param {EventProxy}  eventbus - An event proxy for the main eventbus.
    *
    * @param {string}      kind - target kind property.
    *
    * @returns {string} HTML of single output.
    * @private
    */
   static _buildSingleDoc(eventbus, kind)
   {
      const title = kind.replace(/^(\w)/, (c) => c.toUpperCase());
      const ice = eventbus.triggerSync('tjsdoc:system:publisher:ice:cap:template:get', 'single.html');

      ice.text('title', title);

      ice.load('summaries', eventbus.triggerSync('tjsdoc:system:publisher:doc:html:summary:get', null, kind,
       'Summary'), 'append');

      ice.load('details', eventbus.triggerSync('tjsdoc:system:publisher:doc:html:detail:get', null, kind, ''));

      return ice.html;
   }
}
