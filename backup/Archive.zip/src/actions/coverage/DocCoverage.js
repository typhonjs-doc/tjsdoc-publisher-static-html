import PublishUtil from '../../PublishUtil.js';

const s_LOG_PREPEND = 'tjsdoc-publisher-static-html-doccoverage - ';

/**
 * Executes writing AST output.
 */
export function onHandlePublishAsync(ev)
{
   if (ev.data.incremental)
   {
      if (ev.data.fileType === 'source' && !ev.data.minimal) { DocCoverage.exec(ev.data); }
   }
   else
   {
      DocCoverage.exec(ev.data);
   }
}

/**
 * Documentation coverage output builder.
 *
 * Creates badge.svg and writes coverage data.
 */
class DocCoverage
{
   /**
    * Executes writing badge.svg and documentation coverage data.
    *
    * @param {EventProxy}  eventbus - An event proxy for the plugin eventbus.
    *
    * @param {object}      sourceCoverage - The DocDB source coverage data.
    */
   static exec({ eventbus, mainConfig, silent, sourceCoverage } = {})
   {
      if (mainConfig.docCoverage && sourceCoverage)
      {
         eventbus.trigger('tjsdoc:system:file:write', {
            fileData: JSON.stringify(sourceCoverage, null, 2),
            filePath: 'coverage.json',
            logPrepend: s_LOG_PREPEND,
            silent
         });

         // create badge
         let badge = PublishUtil.getTemplate({ dirName: __dirname, filePath: 'images/badge.svg' });

         badge = badge.replace(/@ratio@/g, sourceCoverage.text);
         badge = badge.replace(/@color@/g, sourceCoverage.htmlColor);

         eventbus.trigger('tjsdoc:system:file:write', {
            fileData: badge,
            filePath: 'badge.svg',
            logPrepend: s_LOG_PREPEND,
            silent
         });
      }
   }
}

