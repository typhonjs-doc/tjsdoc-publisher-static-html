import parseExample  from '../../utils/parseExample.js';

import PublishUtil   from '../../PublishUtil.js';

const s_LOG_PREPEND = 'tjsdoc-publisher-static-html-class - ';

/**
 * Executes writing class HTML output.
 */
export function onHandlePublishAsync(ev)
{
   if (ev.data.incremental)
   {
      if (ev.data.fileType === 'source') { ClassDoc.exec(ev.data); }
   }
   else
   {
      ClassDoc.exec(ev.data);
   }
}

class ClassDoc
{
   /**
    * Executes writing class HTML output.
    */
   static exec({ docDB, eventbus, filePath = void 0, silent = false } = {})
   {
      const ice = eventbus.triggerSync('tjsdoc:system:publisher:ice:cap:layout:get');

      ice.autoDrop = false;

      docDB.query(filePath ? { kind: 'ModuleClass', filePath } : { kind: 'ModuleClass' }).each((doc) =>
      {
         const filePath = PublishUtil.getDocFileName(doc);
         const baseUrl = PublishUtil.getFileURLBase(filePath);
         const title = PublishUtil.getTitle(doc);

         ice.load('content', ClassDoc._buildClassDoc(doc, docDB, eventbus), 'write');
         ice.attr('baseUrl', 'href', baseUrl, 'write');
         ice.text('title', title, 'write');

         eventbus.trigger('tjsdoc:system:file:write', {
            fileData: ice.html,
            filePath,
            logPrepend: s_LOG_PREPEND,
            silent
         });
      });
   }

   /**
    * Build class output.
    *
    * @param {DocObject}   doc - class doc object.
    * @param {DocDB}       docDB - Target DocDB.
    *
    * @returns {IceCap} built output.
    * @private
    */
   static _buildClassDoc(doc, docDB, eventbus)
   {
      const expressionExtends = ClassDoc._buildExpressionExtendsHTML(doc);
      const mixinClasses = ClassDoc._buildMixinClassesHTML(doc);
      const extendsChain = ClassDoc._buildExtendsChainHTML(doc);
      const directSubclass = ClassDoc._buildDirectSubclassHTML(doc);
      const indirectSubclass = ClassDoc._buildIndirectSubclassHTML(doc);

      const instanceDocs = docDB.find({ category: 'ModuleVariable' }).filter((v) =>
      {
         return v.type && v.type.types.includes(doc.longname);
      });

      const ice = PublishUtil.getIceCapTemplate({ dirName: __dirname, filePath: 'html/class.html' });

      // header
      if (doc.export && doc.importPath && doc.importStyle)
      {
         const link = PublishUtil.getDocHTMLFileLink(doc, doc.importPath);

         ice.into('importPath', `import ${doc.importStyle} from '${link}'`, (code, ice) =>
         {
            ice.load('importPathCode', code);
         });
      }

      ice.text('access', doc.access);
      ice.text('kind', doc.interface ? 'interface' : 'class');
      ice.load('source', PublishUtil.getDocHTMLFileLink(doc, 'source'), 'append');
      ice.text('since', doc.since, 'append');
      ice.text('version', doc.version, 'append');

      ice.into('expressionExtends', expressionExtends,
       (expressionExtends, ice) => ice.load('expressionExtendsCode', expressionExtends));

      ice.load('mixinExtends', mixinClasses, 'append');
      ice.load('extendsChain', extendsChain, 'append');
      ice.load('directSubclass', directSubclass, 'append');
      ice.load('indirectSubclass', indirectSubclass, 'append');

      ice.load('implements', PublishUtil.getDocsHTMLLink(doc.implements, null, false, ', '), 'append');

      ice.load('indirectImplements', PublishUtil.getDocsHTMLLink(doc._custom_indirect_implements, null, false, ', '),
       'append');

      ice.load('directImplemented', PublishUtil.getDocsHTMLLink(doc._custom_direct_implemented, null, false, ', '),
       'append');

      ice.load('indirectImplemented', PublishUtil.getDocsHTMLLink(doc._custom_indirect_implemented, null, false, ', '),
       'append');

      // self
      ice.text('name', doc.name);
      ice.load('description', doc.descriptionHTML);

      ice.load('deprecated', PublishUtil.getDocHTMLDeprecated(doc));
      ice.load('experimental', PublishUtil.getDocHTMLExperimental(doc));
      ice.load('see', PublishUtil.getDocsHTMLLink(doc.see), 'append');
      ice.load('todo', PublishUtil.getDocsHTMLLink(doc.todo), 'append');
      ice.load('decorator', PublishUtil.getDocHTMLDecorator(doc), 'append');

      ice.into('instanceDocs', instanceDocs, (instanceDocs, ice) =>
      {
         ice.loop('instanceDoc', instanceDocs, (i, instanceDoc, ice) =>
         {
            ice.load('instanceDoc', PublishUtil.getDocHTMLLink(instanceDoc.longname));
         });
      });

      ice.into('exampleDocs', doc.examples, (examples, ice) =>
      {
         ice.loop('exampleDoc', examples, (i, example, ice) =>
         {
            const parsed = parseExample(example);

            ice.text('exampleCode', parsed.body);
            ice.text('exampleCaption', parsed.caption);
         });
      });

      ice.into('tests', doc._custom_tests, (tests, ice) =>
      {
         ice.loop('test', tests, (i, test, ice) =>
         {
            const testDoc = docDB.find({ longname: test })[0];

            ice.load('test', PublishUtil.getDocHTMLFileLink(testDoc, testDoc.testFullDescription));
         });
      });


      // Store `memberof` query value with `doc.longname`.
      const memberof = doc.longname;

      // Get shared access docs between summary and detail output.

      // Static class members (category)
      let accessDocs = docDB.findAccessDocs({ 'category': 'ClassMember', 'static': true, memberof });

      ice.load('staticMemberSummary',
       eventbus.triggerSync('tjsdoc:system:publisher:doc:html:summary:get', accessDocs, 'Members'));

      ice.load('staticMemberDetails',
       eventbus.triggerSync('tjsdoc:system:publisher:doc:html:detail:get', accessDocs, 'Members'));


      // Static class methods (only direct methods; no constructors or accessors)
      accessDocs = docDB.findAccessDocs({ 'kind': 'ClassMethod', 'qualifier': 'method', 'static': true, memberof });

      ice.load('staticMethodSummary',
       eventbus.triggerSync('tjsdoc:system:publisher:doc:html:summary:get', accessDocs, 'Methods'));

      ice.load('staticMethodDetails',
       eventbus.triggerSync('tjsdoc:system:publisher:doc:html:detail:get', accessDocs, 'Methods'));

      // Only class constructors
      accessDocs = docDB.findAccessDocs({ kind: 'ClassMethod', qualifier: 'constructor', memberof });

      ice.load('constructorSummary',
       eventbus.triggerSync('tjsdoc:system:publisher:doc:html:summary:get', accessDocs, 'Constructors'));

      ice.load('constructorDetails',
       eventbus.triggerSync('tjsdoc:system:publisher:doc:html:detail:get', accessDocs, 'Constructors'));


      // Only class members (category)
      accessDocs = docDB.findAccessDocs({ 'category': 'ClassMember', 'static': false, memberof });

      ice.load('memberSummary',
       eventbus.triggerSync('tjsdoc:system:publisher:doc:html:summary:get', accessDocs, 'Members'));

      ice.load('memberDetails',
       eventbus.triggerSync('tjsdoc:system:publisher:doc:html:detail:get', accessDocs, 'Members'));

      // Class methods (only direct methods; no constructors or accessors)
      accessDocs = docDB.findAccessDocs({ 'kind': 'ClassMethod', 'qualifier': 'method', 'static': false, memberof });

      ice.load('methodSummary',
       eventbus.triggerSync('tjsdoc:system:publisher:doc:html:summary:get', accessDocs, 'Methods'));

      ice.load('methodDetails',
       eventbus.triggerSync('tjsdoc:system:publisher:doc:html:detail:get', accessDocs, 'Methods'));

      ice.load('inheritedSummary', ClassDoc._buildInheritedSummaryHTML(doc, docDB, eventbus), 'append');

      return ice;
   }

   /**
    * Build mixin extends HTML.
    *
    * @param {DocObject}   doc - target class doc.
    *
    * @return {string} mixin extends HTML.
    * @private
    */
   static _buildMixinClassesHTML(doc)
   {
      if (!doc.extends) { return ''; }
      if (doc.extends.length <= 1) { return ''; }

      const links = [];

      for (const longname of doc.extends) { links.push(PublishUtil.getDocHTMLLink(longname)); }

      return `<div>${links.join(', ')}</div>`;
   }

   /**
    * Build expression extends HTML.
    *
    * @param {DocObject}   doc - target class doc.
    *
    * @return {string} expression extends HTML.
    * @private
    */
   static _buildExpressionExtendsHTML(doc)
   {
      if (!doc.expressionExtends) { return ''; }

      const html = doc.expressionExtends.replace(/[A-Z_$][a-zA-Z0-9_$]*/g, (v) => PublishUtil.getDocHTMLLink(v));

      return `class ${doc.name} extends ${html}`;
   }

   /**
    * Build class ancestor extends chain.
    *
    * @param {DocObject}   doc - target class doc.
    *
    * @returns {string} extends chain links HTML.
    * @private
    */
   static _buildExtendsChainHTML(doc)
   {
      if (!doc._custom_extends_chains) { return ''; }
      if (doc.extends.length > 1) { return ''; }

      const links = [];

      for (const longname of doc._custom_extends_chains) { links.push(PublishUtil.getDocHTMLLink(longname)); }

      links.push(doc.name);

      return `<div>${links.join(' → ')}</div>`;
   }

   /**
    * Build in-direct subclass list.
    *
    * @param {DocObject}   doc - target class doc.
    *
    * @returns {string} HTML of in-direct subclass links.
    * @private
    */
   static _buildIndirectSubclassHTML(doc)
   {
      if (!doc._custom_indirect_subclasses) { return ''; }

      const links = [];

      for (const longname of doc._custom_indirect_subclasses) { links.push(PublishUtil.getDocHTMLLink(longname)); }

      return `<div>${links.join(', ')}</div>`;
   }

   /**
    * Build direct subclass list.
    *
    * @param {DocObject}   doc - target class doc.
    *
    * @returns {string} HTML of direct subclass links.
    * @private
    */
   static _buildDirectSubclassHTML(doc)
   {
      if (!doc._custom_direct_subclasses) { return ''; }

      const links = [];

      for (const longname of doc._custom_direct_subclasses) { links.push(PublishUtil.getDocHTMLLink(longname)); }

      return `<div>${links.join(', ')}</div>`;
   }

   /**
    * Build inherited method / member summary.
    *
    * @param {DocObject}   doc - target class doc.
    *
    * @param {DocDB}       docDB - Target DocDB.
    *
    * @returns {string} HTML of inherited method/member from ancestor classes.
    * @private
    */
   static _buildInheritedSummaryHTML(doc, docDB, eventbus)
   {
      let docName;

      switch (doc.kind)
      {
         case 'ModuleClass':
            docName = 'class';
            break;

         case 'interface':       // TODO INTERFACE?
            docName = 'interface';
            break;

         default:
            return '';
      }

      const longnames = [...doc._custom_extends_chains || []];

      const html = [];

      for (const longname of longnames)
      {
         const superDoc = docDB.find({ longname })[0];

         if (!superDoc) { continue; }

         // All class members and just class methods that aren't accessors or the constructor.
         const targetDocs = docDB.find([{ memberof: longname, category: 'ClassMember' },
          { memberof: longname, kind: 'ClassMethod', qualifier: 'method' }]);

         const orderAccess = { 'public': 0, 'protected': 1, 'private': 2 };
         const orderKind = { get: 0, set: 0, member: 1, method: 2 };
         const orderKindFinal = { get: 0, set: 1, member: 2 };

         targetDocs.sort((a, b) =>
         {
            if (a.static !== b.static) { return -(a.static - b.static); }

            const aKind = a.kind === 'ClassMethod' ? a.qualifier : a.kind;
            const bKind = b.kind === 'ClassMethod' ? b.qualifier : b.kind;

            if (orderKind[aKind] !== orderKind[bKind]) { return orderKind[aKind] - orderKind[bKind]; }

            if (a.access !== b.access) { return orderAccess[a.access] - orderAccess[b.access]; }

            if (a.name !== b.name) { return a.name < b.name ? -1 : 1; }

            return orderKindFinal[aKind] - orderKindFinal[bKind];
         });

         const title = `<span class="toggle closed"></span> From ${docName} ${
          PublishUtil.getDocHTMLLink(longname, superDoc.name)}`;

         const result = eventbus.triggerSync('tjsdoc:system:publisher:docs:ice:cap:summary:get',
          targetDocs, '----------', false, superDoc.kind);

         if (result)
         {
            result.load('title', title, 'write');
            html.push(result.html);
         }
      }

      return html.join('\n');
   }
}
