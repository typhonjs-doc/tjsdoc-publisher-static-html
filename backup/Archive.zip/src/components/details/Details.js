import PublishUtil   from '../../PublishUtil.js';

import parseExample  from '../../utils/parseExample.js';

/**
 * @param {PluginEvent} ev - The plugin event.
 */
export function onPluginLoad(ev)
{
   ev.eventbus.on('tjsdoc:system:publisher:doc:html:detail:get', Details.getDocHTMLDetail, Details);
   ev.eventbus.on('tjsdoc:system:publisher:docs:ice:cap:detail:get', Details.getDocsIceCapDetail, Details);
   ev.eventbus.on('tjsdoc:system:publisher:ice:cap:properties:get', Details.getIceCapProperties, Details);
}

/**
 *
 */
class Details
{
   /**
    * Builds detail output HTML by parent doc.
    *
    * @param {AccessDocs}  accessDocs - An object from DocDB with the following access keys `Public`, `Private`,
    *                                   `Protected` indexing an associated DocObject[].
    *
    * @param {string}      [title] - Detail title.
    *
    * @returns {string} HTML of detail.
    */
   static getDocHTMLDetail(accessDocs, title = '')
   {
      let html = '';

      for (const accessType in accessDocs)
      {
         const docs = accessDocs[accessType];

         if (!docs.length) { continue; }

         let prefix = '';

         if (docs[0].static) { prefix = 'Static '; }

         const _title = `${prefix}${accessType} ${title}`;
         const result = this.getDocsIceCapDetail(docs, _title);

         if (result) { html += result.html; }
      }

      return html;
   }

   /**
    * Builds detail output HTML from multiple docs.
    *
    * @param {DocObject[]} docs - Target docs.
    *
    * @param {string}      title - Detail title.
    *
    * @return {IceCap} Detail output.
    */
   static getDocsIceCapDetail(docs, title)
   {
      const ice = PublishUtil.getIceCapTemplate({ dirName: __dirname, filePath: 'html/details.html' });

      ice.text('title', title);
      ice.drop('title', !docs.length);

      ice.loop('detail', docs, (i, doc, ice) =>
      {
         const scope = doc.static ? 'static' : 'instance';
         const qualifier = doc.kind === 'ClassMethod' && doc.accessor ? `-${doc.qualifier}` : '';

         ice.attr('anchor', 'id', `${scope}-${doc.kind.toLowerCase()}${qualifier}-${doc.name}`);
         ice.text('generator', doc.generator ? '*' : '');
         ice.text('async', doc.async ? 'async' : '');
         ice.text('name', doc.name);
         ice.text('abstract', doc.abstract ? 'abstract' : '');
         ice.text('access', doc.access);
         ice.load('signature', PublishUtil.getDocHTMLSignature(doc));
         ice.load('description', doc.descriptionHTML || PublishUtil.getDocOverrideMethodDescription(doc));

         switch (doc.kind)
         {
            case 'ClassMethod':
               if (doc.accessor) { ice.text('kind', doc.qualifier); }
               else { ice.drop('kind'); }
               break;

            default:
               ice.drop('kind');
               break;
         }

         if (doc.export && doc.importPath && doc.importStyle)
         {
            const link = PublishUtil.getDocHTMLFileLink(doc, doc.importPath);

            ice.into('importPath', `import ${doc.importStyle} from '${link}'`, (code, ice) =>
            {
               ice.load('importPathCode', code);
            });
         }
         else
         {
            ice.drop('importPath');
         }

         switch (doc.kind)
         {
            case 'ClassProperty':
            case 'ClassMember':
            case 'ClassMethod':
               ice.text('static', doc.static ? 'static' : '');
               break;

            default:
               ice.drop('static');
               break;
         }

         ice.load('source', PublishUtil.getDocHTMLFileLink(doc, 'source'));
         ice.text('since', doc.since, 'append');
         ice.load('deprecated', PublishUtil.getDocHTMLDeprecated(doc));
         ice.load('experimental', PublishUtil.getDocHTMLExperimental(doc));
         ice.text('version', doc.version, 'append');
         ice.load('see', PublishUtil.getDocsHTMLLink(doc.see), 'append');
         ice.load('todo', PublishUtil.getDocsHTMLLink(doc.todo), 'append');
         ice.load('override', PublishUtil.getDocOverrideMethod(doc));
         ice.load('decorator', PublishUtil.getDocHTMLDecorator(doc), 'append');

         let isFunction = false;

         switch (doc.kind)
         {
            case 'ClassMethod':
               isFunction = !doc.accessor;
               break;

            case 'ModuleFunction':
               isFunction = true;
               break;
         }

         if (doc.kind === 'VirtualTypedef' && doc.params && doc.type.types[0] === 'function') { isFunction = true; }

         if (isFunction)
         {
            ice.load('properties', this.getIceCapProperties(doc.params, 'Params:'));
         }
         else
         {
            ice.load('properties', this.getIceCapProperties(doc.properties, 'Properties:'));
         }

         // return
         if (doc.return)
         {
            ice.load('returnDescription', doc.return.descriptionHTML);

            const typeNames = [];

            for (const typeName of doc.return.types)
            {
               typeNames.push(PublishUtil.getDocHTMLLinkType(typeName));
            }

            if (typeof doc.return.nullable === 'boolean')
            {
               const nullable = doc.return.nullable;

               ice.load('returnType', `${typeNames.join(' | ')} (nullable: ${nullable})`);
            }
            else
            {
               ice.load('returnType', typeNames.join(' | '));
            }

            ice.load('returnProperties', this.getIceCapProperties(doc.properties, 'Return Properties:'));
         }
         else
         {
            ice.drop('returnParams');
         }

         // throws
         if (doc.throws)
         {
            ice.loop('throw', doc.throws, (i, exceptionDoc, ice) =>
            {
               ice.load('throwName', PublishUtil.getDocHTMLLink(exceptionDoc.types[0]));
               ice.load('throwDesc', exceptionDoc.descriptionHTML);
            });
         }
         else
         {
            ice.drop('throwWrap');
         }

         // fires
         if (doc.emits)
         {
            ice.loop('emit', doc.emits, (i, emitDoc, ice) =>
            {
               ice.load('emitName', PublishUtil.getDocHTMLLink(emitDoc.types[0]));
               ice.load('emitDesc', emitDoc.descriptionHTML);
            });
         }
         else
         {
            ice.drop('emitWrap');
         }

         // listens
         if (doc.listens)
         {
            ice.loop('listen', doc.listens, (i, listenDoc, ice) =>
            {
               ice.load('listenName', PublishUtil.getDocHTMLLink(listenDoc.types[0]));
               ice.load('listenDesc', listenDoc.descriptionHTML);
            });
         }
         else
         {
            ice.drop('listenWrap');
         }

         // example
         ice.into('example', doc.examples, (examples, ice) =>
         {
            ice.loop('exampleDoc', examples, (i, exampleDoc, ice) =>
            {
               const parsed = parseExample(exampleDoc);

               ice.text('exampleCode', parsed.body);
               ice.text('exampleCaption', parsed.caption);
            });
         });

         // tests
         ice.into('tests', doc._custom_tests, (tests, ice) =>
         {
            ice.loop('test', tests, (i, test, ice) =>
            {
               const testDoc = PublishUtil._docDB.find({ longname: test })[0];

               ice.load('test', PublishUtil.getDocHTMLFileLink(testDoc, testDoc.testFullDescription));
            });
         });
      });

      return ice;
   }

   /**
    * Build properties output.
    *
    * @param {ParsedParam[]}  [properties=[]] - Properties in doc object.
    * @param {string}         title - Output title.
    *
    * @return {IceCap} Built properties output.
    */
   static getIceCapProperties(properties = [], title = 'Properties:')
   {
      const ice = PublishUtil.getIceCapTemplate({ dirName: __dirname, filePath: 'html/properties.html' });

      ice.text('title', title);

      ice.loop('property', properties, (i, prop, ice) =>
      {
         ice.autoDrop = false;
         ice.attr('property', 'data-depth', prop.name.split('.').length - 1);
         ice.text('name', prop.name);
         ice.attr('name', 'data-depth', prop.name.split('.').length - 1);
         ice.load('description', prop.descriptionHTML);

         const typeNames = [];

         for (const typeName of prop.types)
         {
            typeNames.push(PublishUtil.getDocHTMLLinkType(typeName));
         }

         ice.load('type', typeNames.join(' | '));

         // appendix
         const appendix = [];

         if (prop.optional)
         {
            appendix.push('<li>optional</li>');
         }

         if ('defaultValue' in prop)
         {
            appendix.push(`<li>default: ${prop.defaultValue}</li>`);
         }

         if (typeof prop.nullable === 'boolean')
         {
            appendix.push(`<li>nullable: ${prop.nullable}</li>`);
         }

         if (appendix.length)
         {
            ice.load('appendix', `<ul>${appendix.join('\n')}</ul>`);
         }
         else
         {
            ice.text('appendix', '');
         }
      });

      if (!properties || properties.length === 0)
      {
         ice.drop('properties');
      }

      return ice;
   }
}
