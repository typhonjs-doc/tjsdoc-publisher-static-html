import PublishUtil   from '../../PublishUtil.js';

/**
 *
 */
export default class Details
{
   /**
    * @param {PluginEvent} ev - The plugin event.
    */
   static onPluginLoad(ev)
   {
      this._eventbus = ev.eventbus;

      ev.eventbus.on('tjsdoc:system:publisher:doc:html:detail:get', Details.getDocHTMLDetail, Details);
      ev.eventbus.on('tjsdoc:system:publisher:docs:ice:cap:detail:get', Details.getDocsIceCapDetail, Details);
      ev.eventbus.on('tjsdoc:system:publisher:ice:cap:properties:get', Details.getIceCapProperties, Details);
   }

   /**
    * Builds detail output HTML by parent doc.
    *
    * @param {AccessDocs}  accessDocs - An object from DocDB with the following access keys `Public`, `Private`,
    *                                   `Protected` indexing an associated DocObject[].
    *
    * @param {string}      [title] - Detail title.
    *
    * @returns {string} HTML of detail.
    */
   static getDocHTMLDetail(accessDocs, title = '')
   {
      let html = '';

      for (const accessType in accessDocs)
      {
         const docs = accessDocs[accessType];

         if (!docs.length) { continue; }

         let prefix = '';

         if (docs[0].static) { prefix = 'Static '; }

         const _title = `${prefix}${accessType} ${title}`;
         const result = this.getDocsIceCapDetail(docs, _title);

         if (result) { html += result.html; }
      }

      return html;
   }

   /**
    * Builds detail output HTML from multiple docs.
    *
    * @param {DocObject[]} docs - Target docs.
    *
    * @param {string}      title - Detail title.
    *
    * @return {IceCap} Detail output.
    */
   static getDocsIceCapDetail(docs, title)
   {
      const ice = PublishUtil.getIceCapTemplate({ dirName: __dirname, filePath: 'html/details.html' });

      ice.text('title', title);
      ice.drop('title', !docs.length);

      ice.loop('detail', docs, (i, doc, ice) =>
      {
         const scope = doc.static ? 'static' : 'instance';
         const qualifier = doc.kind === 'ClassMethod' && doc.accessor ? `-${doc.qualifier}` : '';

         ice.attr('anchor', 'id', `${scope}-${doc.kind.toLowerCase()}${qualifier}-${doc.name}`);
         ice.text('generator', doc.generator ? '*' : '');
         ice.text('async', doc.async ? 'async' : '');
         ice.text('name', doc.name);
         ice.text('abstract', doc.abstract ? 'abstract' : '');
         ice.text('access', doc.access);
         ice.load('signature', PublishUtil.getDocHTMLSignature(doc));
         ice.load('description', doc.descriptionHTML || PublishUtil.getDocOverrideMethodDescription(doc));

         switch (doc.kind)
         {
            case 'ClassMethod':
               if (doc.accessor) { ice.text('kind', doc.qualifier); }
               else { ice.drop('kind'); }
               break;

            default:
               ice.drop('kind');
               break;
         }

         if (doc.export && doc.importPath && doc.importStyle)
         {
            const link = PublishUtil.getDocHTMLFileLink(doc, doc.importPath);

            ice.into('importPath', `import ${doc.importStyle} from '${link}'`, (code, ice) =>
            {
               ice.load('importPathCode', code);
            });
         }
         else
         {
            ice.drop('importPath');
         }

         switch (doc.kind)
         {
            case 'ClassProperty':
            case 'ClassMember':
            case 'ClassMethod':
               ice.text('static', doc.static ? 'static' : '');
               break;

            default:
               ice.drop('static');
               break;
         }

         ice.load('source', PublishUtil.getDocHTMLFileLink(doc, 'source'));
         ice.text('since', doc.since, 'append');
         ice.load('deprecated', PublishUtil.getDocHTMLDeprecated(doc));
         ice.load('experimental', PublishUtil.getDocHTMLExperimental(doc));
         ice.text('version', doc.version, 'append');

         const override = PublishUtil.getDocOverrideMethod(doc);

         if (override !== '')
         {
            ice.load('override', override, 'append');
         }
         else
         {
            ice.drop('overrideWrapper');
         }

         const decorator = PublishUtil.getDocHTMLDecorator(doc);

         if (decorator !== '')
         {
            ice.load('decorator', decorator, 'append');
         }
         else
         {
            ice.drop('decoratorWrapper');
         }

         let isFunction = false;

         switch (doc.kind)
         {
            case 'ClassMethod':
               isFunction = !doc.accessor;
               break;

            case 'ModuleFunction':
               isFunction = true;
               break;
         }

         if (doc.kind === 'VirtualTypedef' && doc.params && doc.type.types[0] === 'function') { isFunction = true; }

         if (isFunction)
         {
            ice.load('properties', this.getIceCapProperties(doc.params, 'Params:'));
         }
         else
         {
            ice.load('properties', this.getIceCapProperties(doc.properties, 'Properties:'));
         }

         // return: If there is a return description or properties then data will be inserted into the default
         // template. However, if no return description or properties exist then just the return type will overwrite
         // the `returnGroup` section of the template.
         if (doc.return)
         {
            let returnType = 'returnType';
            let iceMode = 'append';

            if (doc.return.descriptionHTML || doc.properties)
            {
               ice.load('returnDescription', doc.return.descriptionHTML);
               ice.load('returnProperties', this.getIceCapProperties(doc.properties, 'Return Properties:'));
            }
            else
            {
               returnType = 'returnGroup';
               iceMode = 'write';
            }

            const typeNames = [];

            for (const typeName of doc.return.types)
            {
               typeNames.push(PublishUtil.getDocHTMLLinkType(typeName));
            }

            if (typeof doc.return.nullable === 'boolean')
            {
               const nullable = doc.return.nullable;

               ice.load(returnType, `${typeNames.join(' | ')} (nullable: ${nullable})`, iceMode);
            }
            else
            {
               ice.load(returnType, typeNames.join(' | '), iceMode);
            }
         }
         else
         {
            ice.drop('returnParams');
         }

         // throws
         if (doc.throws)
         {
            ice.loop('throw', doc.throws, (i, exceptionDoc, ice) =>
            {
               ice.load('throwName', PublishUtil.getDocHTMLLink(exceptionDoc.types[0]));
               ice.load('throwDesc', exceptionDoc.descriptionHTML);

               // Potentially add element style `border: none;` to `throwName` if there is no description.
               if (exceptionDoc.descriptionHTML === '')
               {
                  ice.attr('throwName', 'style', 'border: none;');
               }
            });
         }
         else
         {
            ice.drop('throwWrap');
         }

         // fires
         if (doc.emits)
         {
            ice.loop('emit', doc.emits, (i, emitDoc, ice) =>
            {
               ice.load('emitName', PublishUtil.getDocHTMLLink(emitDoc.types[0]));
               ice.load('emitDesc', emitDoc.descriptionHTML);

               // Potentially add element style `border: none;` to `emitName` if there is no description.
               if (emitDoc.descriptionHTML === '')
               {
                  ice.attr('emitName', 'style', 'border: none;');
               }
            });
         }
         else
         {
            ice.drop('emitWrap');
         }

         // listens
         if (doc.listens)
         {
            ice.loop('listen', doc.listens, (i, listenDoc, ice) =>
            {
               ice.load('listenName', PublishUtil.getDocHTMLLink(listenDoc.types[0]));
               ice.load('listenDesc', listenDoc.descriptionHTML);

               // Potentially add element style `border: none;` to `listenName` if there is no description.
               if (listenDoc.descriptionHTML === '')
               {
                  ice.attr('listenName', 'style', 'border: none;');
               }
            });
         }
         else
         {
            ice.drop('listenWrap');
         }

         // example
         ice.into('example', doc.examples, (examples, ice) =>
         {
            ice.loop('exampleDoc', examples, (i, example, ice) =>
            {
               const parsed = this._eventbus.triggerSync('tjsdoc:system:publisher:parse:example', example);

               ice.text('exampleCaption', parsed.caption);
               ice.load('exampleCode', parsed.body);
            });
         });

         // tests
         ice.into('tests', doc._custom_tests, (tests, ice) =>
         {
            ice.loop('test', tests, (i, test, ice) =>
            {
               const testDoc = PublishUtil._docDB.find({ longname: test })[0];

               ice.load('test', PublishUtil.getDocHTMLFileLink(testDoc, testDoc.testFullDescription));
            });
         });

         // 'see' list
         if (doc.see)
         {
            const seeData = PublishUtil.getDocsBareLinks(doc.see);

            ice.loop('see', seeData, (i, seeEntry, ice) =>
            {
               ice.load('seeEntry', seeEntry);
            });
         }
         else
         {
            ice.drop('seeWrapper');
         }

         // 'to do' list
         if (doc.todo)
         {
            const todoData = PublishUtil.getDocsBareLinks(doc.todo);

            ice.loop('todo', todoData, (i, todoEntry, ice) =>
            {
               ice.load('todoEntry', todoEntry);
            });
         }
         else
         {
            ice.drop('todoWrapper');
         }
      });

      return ice;
   }

   /**
    * Build properties output.
    *
    * @param {ParsedParam[]}  [properties=[]] - Properties in doc object.
    * @param {string}         title - Output title.
    *
    * @return {IceCap} Built properties output.
    */
   static getIceCapProperties(properties = [], title = 'Properties:')
   {
      const ice = PublishUtil.getIceCapTemplate({ dirName: __dirname, filePath: 'html/properties.html' });

      ice.text('title', title);

      ice.loop('property', properties, (i, prop, ice) =>
      {
         ice.autoDrop = false;
         ice.attr('property', 'data-depth', prop.name.split('.').length - 1);
         ice.text('name', prop.name);
         ice.attr('name', 'data-depth', prop.name.split('.').length - 1);

         if (prop.descriptionHTML)
         {
            ice.load('description', prop.descriptionHTML);
         }
         else
         {
            ice.drop('descriptionWrapper');
         }

         const typeNames = [];

         for (const typeName of prop.types)
         {
            typeNames.push(PublishUtil.getDocHTMLLinkType(typeName));
         }

         ice.load('type', typeNames.join(' | '));

         // attributes
         const attributes = [];

         if (prop.optional)
         {
            attributes.push('<li>optional</li>');
         }

         if ('defaultValue' in prop)
         {
            attributes.push(`<li>default: ${prop.defaultValue}</li>`);
         }

         if (typeof prop.nullable === 'boolean')
         {
            attributes.push(`<li>nullable: ${prop.nullable}</li>`);
         }

         if (attributes.length)
         {
            ice.load('attributes', `<ul>${attributes.join('\n')}</ul>`);
         }
         else
         {
            ice.drop('attributesWrapper');
         }

         // Potentially add element style `border: none;` to `type` or `attributes` if there is no description.
         if (!prop.descriptionHTML)
         {
            if (attributes.length)
            {
               ice.attr('attributesWrapper', 'style', 'border: none;');
            }
            else
            {
               ice.attr('typeWrapper', 'style', 'border: none;');
            }
         }
      });

      if (!properties || properties.length === 0)
      {
         ice.drop('properties');
      }

      return ice;
   }
}
