import PublishUtil   from './PublishUtil.js';

/**
 * Resolve various publisher related properties in DocDB / TaffyDB data.
 *
 * New properties are added for markdown conversion to HTML for doc object `description` which is stored as
 * `descriptionHTML`.
 *
 * `@link` doc tags in `descriptionHTML` are then converted to actual HTML links.
 */
export default class PublishDocResolver
{
   /**
    * Wires up CoreDocResolver.
    *
    * @param {PluginEvent}    ev - An event proxy for the main this._eventbus.
    */
   onPluginLoad(ev)
   {
      /**
       * Stores the plugin eventbus proxy.
       * @type {EventProxy}
       */
      this._eventbus = ev.eventbus;

      // Add event binding adding resolution provided by PublishDocResolver
      this._eventbus.on('tjsdoc:system:resolver:docdb:resolve', this.resolve, this);
   }

   /**
    * Stores the target project TJSDocConfig and main DocDB so that eventbus queries are reduced.
    *
    * @param {PluginEvent}    ev - An event proxy for the main this._eventbus.
    */
   onRuntimePreGenerateAsync(ev)
   {
      this._mainDocDB = ev.data.docDB;
   }

   /**
    * Resolve various properties.
    */
   resolve({ docDB = this._mainDocDB, filePath = void 0, silent = false } = {})
   {
      if (!silent)
      {
         this._eventbus.trigger('log:info:raw', 'tjsdoc-doc-resolver-publish: resolve markdown in description');
      }

      this._resolveMarkdown(docDB, filePath);

      if (!silent) { this._eventbus.trigger('log:info:raw', 'tjsdoc-doc-resolver-publish: resolve link'); }

      this._resolveLink(docDB, filePath);
   }

   /**
    * Resolve description as markdown.
    *
    * @param {EventProxy}  eventbus - An event proxy for the main eventbus.
    *
    * @private
    */
   _resolveMarkdown(docDB, filePath)
   {
      const convert = (doc) =>
      {
         for (const key of Object.keys(doc))
         {
            const value = doc[key];

            if (key === 'description' && typeof value === 'string')
            {
               doc[`${key}HTML`] = this._eventbus.triggerSync('typhonjs:util:markdown:html:convert',
                { markdown: value, breaks: false });
            }
            else if (typeof value === 'object' && value)
            {
               convert(value);
            }
         }
      };

      for (const doc of docDB.find(filePath ? { filePath } : void 0))
      {
         convert(doc);
      }
   }

   /**
    * Resolve @link tags as HTML links.
    *
    * Note: A small hack is in place here to temporarily replace PublishUtil._docDB with the given DocDB to resolve.
    * Usually just the main DocDB is being resolved, but this handles resolution for any DocDB.
    *
    * @private
    * @todo Resolve all ``description`` property.
    */
   _resolveLink(docDB, filePath)
   {
      const link = (str) =>
      {
         if (!str) { return str; }

         return str.replace(/\{@link ([\w#_\-.:~\/$]+)}/g, (str, longname) =>
         {
            return PublishUtil.getDocHTMLLink(longname, longname);
         });
      };

      const query = docDB.query(filePath ? { filePath } : void 0);

      const oldDocDB = PublishUtil._docDB;

      // A bit of a hack here insofar as replacing tracked DocDB in PublishUtil with the given resolution DocDB.
      if (query.count() > 0) { PublishUtil._docDB = docDB; }

      query.each((v) =>
      {
         v.descriptionHTML = link(v.descriptionHTML);

         if (v.params)
         {
            for (const param of v.params)
            {
               param.descriptionHTML = link(param.descriptionHTML);
            }
         }

         if (v.properties)
         {
            for (const property of v.properties)
            {
               property.descriptionHTML = link(property.descriptionHTML);
            }
         }

         if (v.return)
         {
            v.return.descriptionHTML = link(v.return.descriptionHTML);
         }

         if (v.throws)
         {
            for (const _throw of v.throws)
            {
               _throw.descriptionHTML = link(_throw.descriptionHTML);
            }
         }

         if (v.see)
         {
            for (let i = 0; i < v.see.length; i++)
            {
               if (v.see[i].startsWith('{@link'))
               {
                  v.see[i] = link(v.see[i]);
               }
               else if (v.see[i].startsWith('<a href'))
               {
                  // ignore
               }
               else
               {
                  v.see[i] = `<a href="${v.see[i]}">${v.see[i]}</a>`;
               }
            }
         }
      });

      if (query.count() > 0) { PublishUtil._docDB = oldDocDB; }
   }
}
