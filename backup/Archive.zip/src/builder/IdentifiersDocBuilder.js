/**
 * Identifier output builder.
 */
export default class IdentifiersDocBuilder
{
   /**
    * Executes writing identifiers / reference page.
    *
    * @param {EventProxy}  eventbus - An event proxy for the main eventbus.
    */
   static exec(eventbus)
   {
      const ice = eventbus.triggerSync('tjsdoc:system:publisher:ice:cap:layout:get');
      const title = eventbus.triggerSync('tjsdoc:system:publisher:title:get', 'Index');

      ice.load('content', IdentifiersDocBuilder._buildIdentifierDoc(eventbus));
      ice.text('title', title, 'write');

      eventbus.trigger('tjsdoc:system:file:write', ice.html, 'identifiers.html');

      // Create an event binding to retrieve the HTML identifiers (used in ManualDocBuilder).
      eventbus.on('tjsdoc:publisher:get:html:identifiers', () => { return ice.html; });
   }

   /**
    * Build identifier output.
    *
    * @param {EventProxy}  eventbus - An event proxy for the main eventbus.
    *
    * @return {IceCap} built output.
    * @private
    */
   static _buildIdentifierDoc(eventbus)
   {
      const ice = eventbus.triggerSync('tjsdoc:system:publisher:ice:cap:template:get', 'identifiers.html');

      // Get access docs for identifier summary.

      // All classes.
      let accessDocs = eventbus.triggerSync('tjsdoc:data:docdb:find:access:docs',
       { 'kind': 'ModuleClass', 'interface': false });

      ice.load('classSummary', eventbus.triggerSync('tjsdoc:system:publisher:doc:html:summary:get', 'Class Summary',
       accessDocs));

      // All interfaces.
      accessDocs = eventbus.triggerSync('tjsdoc:data:docdb:find:access:docs',
       { 'kind': 'ModuleClass', 'interface': true });

      ice.load('interfaceSummary', eventbus.triggerSync('tjsdoc:system:publisher:doc:html:summary:get',
       'Interface Summary', accessDocs), 'append');


      // All module functions.
      accessDocs = eventbus.triggerSync('tjsdoc:data:docdb:find:access:docs', { kind: 'ModuleFunction' });

      ice.load('functionSummary', eventbus.triggerSync('tjsdoc:system:publisher:doc:html:summary:get',
       'Function Summary', accessDocs), 'append');


      // All module variables.
      accessDocs = eventbus.triggerSync('tjsdoc:data:docdb:find:access:docs', { category: 'ModuleVariable' });

      ice.load('variableSummary', eventbus.triggerSync('tjsdoc:system:publisher:doc:html:summary:get',
       'Variable Summary', accessDocs), 'append');


      // All virtual typedefs.
      accessDocs = eventbus.triggerSync('tjsdoc:data:docdb:find:access:docs', { kind: 'VirtualTypedef' });

      ice.load('typedefSummary', eventbus.triggerSync('tjsdoc:system:publisher:doc:html:summary:get', 'Typedef Summary',
       accessDocs), 'append');


      // All virtual externals.
      accessDocs = eventbus.triggerSync('tjsdoc:data:docdb:find:access:docs', { kind: 'VirtualExternal' });

      ice.load('externalSummary', eventbus.triggerSync('tjsdoc:system:publisher:doc:html:summary:get',
       'External Summary', accessDocs), 'append');

      return ice;
   }
}
