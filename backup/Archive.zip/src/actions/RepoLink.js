/**
 * Handles adding main toolbar icon link if repository type is defined as `bitbucket`, `git`, `github` or `gitlab`
 * otherwise an overflow item is added. The repository URL must also be defined.
 *
 * If a repository homepage link is defined a main toolbar icon is added for it as well.
 *
 * @param {PluginEvent} ev - The plugin event.
 */
export function onRuntimePreGenerateAsync(ev)
{
   if (typeof ev.data.packageInfo === 'object')
   {
      if (ev.data.packageInfo.repository.url)
      {
         const menuEntry = { href: ev.data.packageInfo.repository.url, target: '_blank' };

         switch (ev.data.packageInfo.repository.type)
         {
            // Font awesome supports bitbucket, git, github and gitlab icons.
            case 'bitbucket':
            case 'git':
            case 'github':
            case 'gitlab':
               menuEntry.cssClass = `fa-icons fa-${ev.data.packageInfo.repository.type}`;
               ev.data.pubConfig._mainToolbarItems.push(menuEntry);
               break;

            // No SCM type matched, so add the repository link to the overflow menu.
            default:
               menuEntry.label = 'Repository';
               ev.data.pubConfig._mainToolbarOverflowItems.push(menuEntry);
               ev.data.pubConfig._mainToolbarOverflowItems.push({ separator: true });
               break;
         }
      }

      // Add repository homepage toolbar icon / link if defined
      if (ev.data.packageInfo.homepage)
      {
         const menuEntry = { href: ev.data.packageInfo.homepage, target: '_blank' };

         menuEntry.cssClass = 'fa-icons fa-external-link-square';
         ev.data.pubConfig._mainToolbarItems.push(menuEntry);
      }
   }
}
