const s_LOG_PREPEND = 'tjsdoc-publisher-static-html-package - ';

/**
 * Executes writing target project `package.json`.
 */
export function onHandlePublishAsync(ev)
{
   if (!ev.data.incremental) { PackageCopy.exec(ev.data); }
}

/**
 * Package JSON Output Builder.
 *
 * The target project `package.json` is output to `package.json`.
 */
class PackageCopy
{
   /**
    * Executes writing target project `package.json`.
    */
   static exec({ eventbus, mainConfig, packageObj, silent } = {})
   {
      // Copy package.json if it is defined and `copyPackage` TJSDoc config parameter is true.
      if (packageObj && mainConfig.copyPackage)
      {
         eventbus.trigger('tjsdoc:system:file:write', {
            fileData: JSON.stringify(packageObj, null, 2),
            filePath: 'package.json',
            logPrepend: s_LOG_PREPEND,
            silent
         });
      }
   }
}
