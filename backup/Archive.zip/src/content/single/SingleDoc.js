import PublishUtil from '../../PublishUtil.js';

/**
 * Executes writing each applicable single output file.
 */
export function onHandlePublish(ev)
{
   if (ev.data.incremental)
   {
      if (ev.data.fileType === 'source' && !ev.data.minimal) { SingleDoc.exec(ev.data); }
   }
   else
   {
      SingleDoc.exec(ev.data);
   }
}

/**
 * Single page builder.
 *
 * "single" means function, variable, typedef, external, etc...
 */
class SingleDoc
{
   /**
    * Executes writing each applicable single output file.
    *
    * @param {EventProxy}  eventbus - An event proxy for the plugin eventbus.
    */
   static exec({ docDB, eventbus, silent } = {})
   {
      const ice = PublishUtil.getIceCapLayout();

      ice.autoClose = false;

      const queries =
      [
         { title: 'Functions', query: { kind: 'ModuleFunction' } },
         { title: 'Variables', query: { category: 'ModuleVariable' } },
         { title: 'Typedefs', query: { kind: 'VirtualTypedef' } }
      ];

      for (const query of queries)
      {
         const docs = docDB.find(query.query);

         if (!docs.length) { continue; }

         const fileName = PublishUtil.getDocFileName(docs[0]);
         const baseUrl = PublishUtil.getFileURLBase(fileName);

         const title = PublishUtil.getTitle(query.title);

         ice.load('content', SingleDoc._buildSingleDoc(docDB, title, query, eventbus), 'write');
         ice.attr('baseUrl', 'href', baseUrl, 'write');
         ice.text('title', title, 'write');

         eventbus.trigger('tjsdoc:system:file:write', ice.html, fileName, silent);
      }
   }

   /**
    * Build single output.
    *
    * @param {string}      title - target kind property.
    *
    * @returns {string} HTML of single output.
    * @private
    */
   static _buildSingleDoc(docDB, title, query, eventbus)
   {
      const ice = PublishUtil.getIceCapTemplate({ dirName: __dirname, filePath: 'html/single.html' });

      ice.text('title', title);

      // All docs of given kind.
      const accessDocs = docDB.findAccessDocs(query.query);

      // Get shared access docs between summary and detail output.

      ice.load('summaries',
       eventbus.triggerSync('tjsdoc:system:publisher:doc:html:summary:get', accessDocs, 'Summary'), 'append');

      ice.load('details', eventbus.triggerSync('tjsdoc:system:publisher:doc:html:detail:get', accessDocs));

      return ice.html;
   }
}
