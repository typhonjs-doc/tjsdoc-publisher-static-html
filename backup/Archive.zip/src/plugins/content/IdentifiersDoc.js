import PublishUtil from '../../PublishUtil.js';

/**
 * Handles adding main menu link.
 *
 * @param {PluginEvent} ev - The plugin event.
 */
export function onHandleConfig(ev)
{
   ev.data.pubConfig._mainMenuLinks.push({ label: 'Reference', href: 'identifiers.html' });
}

/**
 * Executes writing badge.svg and documentation coverage data.
 */
export function onHandlePublish(ev)
{
   if (ev.data.incremental)
   {
      if (ev.data.fileType === 'source' && !ev.data.minimal) { IdentifiersDoc.exec(ev.data); }
   }
   else
   {
      IdentifiersDoc.exec(ev.data);
   }
}

/**
 * Identifier output builder.
 */
class IdentifiersDoc
{
   /**
    * Executes writing identifiers / reference page.
    *
    * @param {EventProxy}  eventbus - An event proxy for the main eventbus.
    */
   static exec({ docDB, eventbus, silent = false } = {})
   {
      const ice = PublishUtil.getIceCapLayout();
      const title = PublishUtil.getTitle('Index');

      ice.load('content', this._buildIdentifierDoc(docDB));
      ice.text('title', title, 'write');

      eventbus.trigger('tjsdoc:system:file:write', ice.html, 'identifiers.html', silent);
   }

   /**
    * Build identifier output.
    *
    * @param {EventProxy}  eventbus - An event proxy for the main eventbus.
    *
    * @return {IceCap} built output.
    * @private
    */
   static _buildIdentifierDoc(docDB)
   {
      const ice = PublishUtil.getIceCapTemplate({ filePath: 'html/identifiers.html' });

      // Get access docs for identifier summary.

      // All classes.
      let accessDocs = docDB.findAccessDocs({ 'kind': 'ModuleClass', 'interface': false });

      ice.load('classSummary', PublishUtil.getDocHTMLSummary(accessDocs, 'Class Summary'));

      // All interfaces.
      accessDocs = docDB.findAccessDocs(
       { 'kind': 'ModuleClass', 'interface': true });

      ice.load('interfaceSummary', PublishUtil.getDocHTMLSummary(accessDocs, 'Interface Summary'), 'append');


      // All module functions.
      accessDocs = docDB.findAccessDocs({ kind: 'ModuleFunction' });

      ice.load('functionSummary', PublishUtil.getDocHTMLSummary(accessDocs, 'Function Summary'), 'append');


      // All module variables.
      accessDocs = docDB.findAccessDocs({ category: 'ModuleVariable' });

      ice.load('variableSummary', PublishUtil.getDocHTMLSummary(accessDocs, 'Variable Summary'), 'append');


      // All virtual typedefs.
      accessDocs = docDB.findAccessDocs({ kind: 'VirtualTypedef' });

      ice.load('typedefSummary', PublishUtil.getDocHTMLSummary(accessDocs, 'Typedef Summary'), 'append');


      // All virtual externals.
      accessDocs = docDB.findAccessDocs({ kind: 'VirtualExternal' });

      ice.load('externalSummary', PublishUtil.getDocHTMLSummary(accessDocs, 'External Summary'), 'append');

      return ice;
   }
}
