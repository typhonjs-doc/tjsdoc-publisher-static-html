/**
 * AST Output Builder.
 *
 * The parsed AST for the project is output to `config.destination`/ast
 */
export default class ASTDocBuilder
{
   /**
    * Executes writing AST output.
    *
    * @param {EventProxy}  eventbus - An event proxy for the main eventbus.
    */
   static exec(eventbus)
   {
      const config = eventbus.triggerSync('tjsdoc:data:config:get');

      // Note the compression format extension will automatically be added.
      if (config.compressData) { eventbus.trigger('tjsdoc:system:file:archive:create', 'ast'); }

      for (const ast of eventbus.triggerSync('tjsdoc:data:ast:get'))
      {
         const astJSON = config.compactData ? JSON.stringify(ast.ast) : JSON.stringify(ast.ast, null, 3);
         const filePath = `ast/${ast.filePath}.json`;

         eventbus.trigger('tjsdoc:system:file:write', astJSON, filePath);
      }

      if (config.compressData) { eventbus.trigger('typhonjs:util:file:archive:finalize'); }
   }
}
