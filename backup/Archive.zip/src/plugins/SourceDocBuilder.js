import fs            from 'fs';
import path          from 'path';

import dateForUTC    from '../utils/dateForUTC.js';
import PublishUtil   from '../PublishUtil.js';

/**
 * Executes writing source index.
 */
export function onHandlePublish(ev)
{
   if (ev.data.incremental)
   {
      if (ev.data.fileType === 'source' && !ev.data.minimal) { SourceDocBuilder.exec(ev.data); }
   }
   else
   {
      SourceDocBuilder.exec(ev.data);
   }
}

/**
 * Source output builder.
 */
class SourceDocBuilder
{
   /**
    * Executes writing source index.
    *
    * @param {EventProxy}  eventbus - An event proxy for the main eventbus.
    */
   static exec({ docDB, eventbus, mainConfig, silent = false, sourceCoverage } = {})
   {
      const ice = PublishUtil.getIceCapLayout();
      const fileName = 'source.html';
      const baseUrl = PublishUtil.getFileURLBase(fileName);
      const title = PublishUtil.getTitle('Source');

      ice.attr('baseUrl', 'href', baseUrl);
      ice.load('content', SourceDocBuilder._buildSourceHTML(mainConfig, docDB, sourceCoverage));
      ice.text('title', title, 'write');

      eventbus.trigger('tjsdoc:system:file:write', ice.html, fileName, silent);
   }

   /**
    * Build source list output HTML.
    *
    * @param {EventProxy}  eventbus - An event proxy for the main eventbus.
    *
    * @returns {string} HTML of source list.
    * @private
    */
   static _buildSourceHTML(config, docDB, sourceCoverage)
   {
      const ice = PublishUtil.getIceCapTemplate('source.html');
      const docs = docDB.find({ kind: 'ModuleFile' });

      const useCoverage = config.docCoverage;

      let coverageFiles;

      if (useCoverage) { coverageFiles = sourceCoverage.files; }

      ice.drop('coverageBadge', !useCoverage);
      ice.attr('files', 'data-use-coverage', !!useCoverage);

      if (useCoverage)
      {
         const actual = sourceCoverage.actualCount;
         const expected = sourceCoverage.expectedCount;
         const coverageCount = `${actual}/${expected}`;

         ice.text('totalCoverageCount', coverageCount);
      }

      ice.loop('file', docs, (i, doc, ice) =>
      {
         const absFilePath = path.resolve(config._dirPath, doc.filePath);
         const content = fs.readFileSync(absFilePath).toString();
         const lines = content.split('\n').length - 1;
         const stat = fs.statSync(absFilePath);
         const date = dateForUTC(stat.ctime);

         let coverageRatio;
         let coverageCount;
         let undocumentedLines;

         if (useCoverage && coverageFiles[doc.longname])
         {
            const actual = coverageFiles[doc.longname].actualCount;
            const expected = coverageFiles[doc.longname].expectedCount;

            coverageRatio = coverageFiles[doc.longname].text;
            coverageCount = `${actual}/${expected}`;

            undocumentedLines = coverageFiles[doc.longname].undocumentedLines.join(',');
         }
         else
         {
            coverageRatio = '-';
         }

         const identifierDocs = docDB.find(
         {
            longname: { left: `${doc.longname}~` },
            kind: ['ModuleAssignment', 'ModuleClass', 'ModuleFunction', 'ModuleVariable']
         });

         const identifiers = identifierDocs.map((doc) => PublishUtil.getDocHTMLLink(doc.longname));

         if (undocumentedLines)
         {
            const url = PublishUtil.getDocURL(doc);

            const link = PublishUtil.getDocHTMLFileLink(doc).replace(
             /href=".*\.html"/, `href="${url}#errorLines=${undocumentedLines}"`);

            ice.load('filePath', link);
         }
         else
         {
            ice.load('filePath', PublishUtil.getDocHTMLFileLink(doc));
         }

         ice.text('coverage', coverageRatio);
         ice.text('coverageCount', coverageCount);
         ice.text('lines', lines);
         ice.text('updated', date);
         ice.text('size', `${stat.size} byte`);
         ice.load('identifier', identifiers.join('\n') || '-');
      });

      return ice.html;
   }
}
