import fs            from 'fs';
import path          from 'path';

import markdown      from '../utils/markdown.js';
import PublishUtil   from '../PublishUtil.js';

/**
 * Executes writing `index.html`.
 */
export function onHandlePublish(ev)
{
   if (ev.data.incremental)
   {
      if (ev.data.fileType === 'index') { IndexDocBuilder.exec(ev.data); }
   }
   else
   {
      IndexDocBuilder.exec(ev.data);
   }
}

/**
 * Index output builder.
 *
 * Outputs the main `index.html` file for generated documentation including any README.md or other file specified by
 * `config.index`.
 */
class IndexDocBuilder
{
   /**
    * Executes writing `index.html`.
    *
    * @param {EventProxy}  eventbus - An event proxy for the main eventbus.
    */
   static exec({ eventbus, mainConfig, silent } = {})
   {
      const ice = PublishUtil.getIceCapLayout();
      const title = PublishUtil.getTitle();

      ice.load('content', this._buildIndexDoc(mainConfig));
      ice.text('title', title, 'write');

      eventbus.trigger('tjsdoc:system:file:write', ice.html, 'index.html', silent);
   }

   /**
    * Build index output including converting `config.index` to HTML from markdown.
    *
    * @returns {string} html of index output.
    * @private
    */
   static _buildIndexDoc(config)
   {
      if (!config.index) { return 'Please create README.md'; }

      let indexContent;

      try
      {
         indexContent = fs.readFileSync(config.index, { encode: 'utf8' }).toString();
      }
      catch (err)
      {
         return 'Please create README.md';
      }

      const ice = PublishUtil.getIceCapTemplate('index.html');
      const ext = path.extname(config.index);

      switch (ext)
      {
         case '.markdown':
         case '.md':
         case '.MD':
            ice.load('index', markdown(indexContent));
            break;

         default:
            ice.load('index', indexContent);
            break;
      }

      return ice.html;
   }
}
