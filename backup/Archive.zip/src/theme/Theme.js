import fs   from 'fs';
import path from 'path';

const s_LOG_PREPEND = 'typhonjs-util-theme-engine-theme - ';

/**
 *
 */
export default class Theme
{
   constructor()
   {
      this._resources = { append: [], copy: [], prepend: [] };
      this._themeDirNames = [];
   }

   /**
    * @param {PluginEvent} ev - The plugin event.
    */
   onPluginLoad(ev)
   {
      this._eventbus = ev.eventbus;

      this._eventbus.on('typhonjs:util:theme:css:get', this.getThemeCSS, this);
      this._eventbus.on('typhonjs:util:theme:resources:get', this.getThemeResources, this);
   }

   addThemeDirName(dirName)
   {
      if (typeof dirName !== 'string') { throw new Error(`'dirName' is not a 'string'.`); }
      if (!fs.existsSync(dirName)) { throw new Error(`Could not resolve theme directory: ${dirName}.`); }

      this._themeDirNames.push(dirName);
   }

   addThemeResource(action, dirName, filePath, name = 'styles.css')
   {
      if (typeof action !== 'string') { throw new Error(`'action' is not a 'string'.`); }
      if (typeof dirName !== 'string') { throw new Error(`'dirName' is not a 'string'.`); }
      if (typeof filePath !== 'string') { throw new Error(`'localPath' is not a 'string'.`); }
      if (typeof name !== 'string') { throw new Error(`'name' is not a 'string'.`); }

      const fullPath =  path.resolve(dirName, filePath);

      if (!fs.existsSync(fullPath)) { throw new Error(`Could not resolve theme resource file path: ${fullPath}.`); }

      switch (action)
      {
         case 'append':
            this._resources.append.push({ name, dirName, filePath, fullPath });
            break;

         case 'copy':
            this._resources.copy.push({ name, dirName, filePath, fullPath });
            break;

         case 'prepend':
            this._resources.prepend.push({ name, dirName, filePath, fullPath });
            break;

         default:
            throw new Error(`Unknown 'action' type: '${action}'`);
      }
   }

   /**
    * Attempts to resolve a theme CSS matching a structural CSS addition.
    *
    * @param name
    * @param filePath
    * @returns {{name: *, dirName: *, filePath: *}}
    */
   async getThemeCSS({ name = void 0, filePath = void 0 } = {})
   {
console.error('!!! Theme - getThemeCSS - name: ' + name +'; filePath: ' + filePath);

      const themeCSS = [];

      for (const dirName of this._themeDirNames)
      {
         const fullPath = path.resolve(dirName, filePath);

         if (fs.existsSync(fullPath))
         {
            themeCSS.push({ name, dirName, filePath, fullPath });
         }
      }

      return themeCSS;

      // return fs.existsSync(path.resolve(this.themeDirName, filePath)) ?
      //  { name, dirName: this.themeDirName, filePath } : void 0;
   }

   /**
    * Attempts to resolve a theme CSS matching a structural CSS addition.
    */
   async getThemeResources()
   {
      return this._resources;
      // return fs.existsSync(path.resolve(this.themeDirName, filePath)) ?
      //    { name, dirName: this.themeDirName, filePath } : void 0;
   }
}
