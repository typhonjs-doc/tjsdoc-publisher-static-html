import parseExample  from '../utils/parseExample.js';

/**
 * Class Output Builder.
 *
 * The static HTML is output to `config.destination`/class
 */
export default class ClassDocBuilder
{
   /**
    * Executes writing class HTML output.
    *
    * @param {EventProxy}  eventbus - An event proxy for the main eventbus.
    */
   static exec(eventbus)
   {
      const ice = eventbus.triggerSync('tjsdoc:system:publisher:ice:cap:layout:get');
      const docs = eventbus.triggerSync('tjsdoc:data:docdb:find', { kind: 'ModuleClass' });

      ice.autoDrop = false;

      for (const doc of docs)
      {
         const fileName = eventbus.triggerSync('tjsdoc:system:publisher:doc:file:name:get', doc);
         const baseUrl = eventbus.triggerSync('tjsdoc:system:publisher:file:url:base:get', fileName);
         const title = eventbus.triggerSync('tjsdoc:system:publisher:title:get', doc);

         ice.load('content', ClassDocBuilder._buildClassDoc(eventbus, doc), 'write');
         ice.attr('baseUrl', 'href', baseUrl, 'write');
         ice.text('title', title, 'write');

         eventbus.trigger('tjsdoc:system:file:write', ice.html, fileName);
      }
   }

   /**
    * Build class output.
    *
    * @param {EventProxy}  eventbus - An event proxy for the main eventbus.
    * @param {DocObject}   doc - class doc object.
    *
    * @returns {IceCap} built output.
    * @private
    */
   static _buildClassDoc(eventbus, doc)
   {
      const expressionExtends = ClassDocBuilder._buildExpressionExtendsHTML(eventbus, doc);
      const mixinClasses = ClassDocBuilder._buildMixinClassesHTML(eventbus, doc);
      const extendsChain = ClassDocBuilder._buildExtendsChainHTML(eventbus, doc);
      const directSubclass = ClassDocBuilder._buildDirectSubclassHTML(eventbus, doc);
      const indirectSubclass = ClassDocBuilder._buildIndirectSubclassHTML(eventbus, doc);

      const instanceDocs = eventbus.triggerSync('tjsdoc:data:docdb:find', { category: 'ModuleVariable' }).filter((v) =>
      {
         return v.type && v.type.types.includes(doc.longname);
      });

      const ice = eventbus.triggerSync('tjsdoc:system:publisher:ice:cap:template:get', 'class.html');

      // header
      if (doc.export && doc.importPath && doc.importStyle)
      {
         const link = eventbus.triggerSync('tjsdoc:system:publisher:doc:html:file:link:get', doc, doc.importPath);

         ice.into('importPath', `import ${doc.importStyle} from '${link}'`, (code, ice) =>
         {
            ice.load('importPathCode', code);
         });
      }

      ice.text('access', doc.access);
      ice.text('kind', doc.interface ? 'interface' : 'class');
      ice.load('source', eventbus.triggerSync('tjsdoc:system:publisher:doc:html:file:link:get', doc, 'source'),
       'append');
      ice.text('since', doc.since, 'append');
      ice.text('version', doc.version, 'append');

      ice.into('expressionExtends', expressionExtends,
       (expressionExtends, ice) => ice.load('expressionExtendsCode', expressionExtends));

      ice.load('mixinExtends', mixinClasses, 'append');
      ice.load('extendsChain', extendsChain, 'append');
      ice.load('directSubclass', directSubclass, 'append');
      ice.load('indirectSubclass', indirectSubclass, 'append');

      ice.load('implements', eventbus.triggerSync('tjsdoc:system:publisher:docs:html:link:get',
       doc.implements, null, false, ', '), 'append');

      ice.load('indirectImplements', eventbus.triggerSync('tjsdoc:system:publisher:docs:html:link:get',
       doc._custom_indirect_implements, null, false, ', '), 'append');

      ice.load('directImplemented', eventbus.triggerSync('tjsdoc:system:publisher:docs:html:link:get',
       doc._custom_direct_implemented, null, false, ', '), 'append');

      ice.load('indirectImplemented', eventbus.triggerSync('tjsdoc:system:publisher:docs:html:link:get',
       doc._custom_indirect_implemented, null, false, ', '), 'append');

      // self
      ice.text('name', doc.name);
      ice.load('description', doc.descriptionHTML);

      ice.load('deprecated', eventbus.triggerSync('tjsdoc:system:publisher:doc:html:deprecated:get', doc));
      ice.load('experimental', eventbus.triggerSync('tjsdoc:system:publisher:doc:html:experimental:get', doc));
      ice.load('see', eventbus.triggerSync('tjsdoc:system:publisher:docs:html:link:get', doc.see), 'append');
      ice.load('todo', eventbus.triggerSync('tjsdoc:system:publisher:docs:html:link:get', doc.todo), 'append');
      ice.load('decorator', eventbus.triggerSync('tjsdoc:system:publisher:doc:html:decorator:get', doc), 'append');

      ice.into('instanceDocs', instanceDocs, (instanceDocs, ice) =>
      {
         ice.loop('instanceDoc', instanceDocs, (i, instanceDoc, ice) =>
         {
            ice.load('instanceDoc', eventbus.triggerSync('tjsdoc:system:publisher:doc:html:link:get',
             instanceDoc.longname));
         });
      });

      ice.into('exampleDocs', doc.examples, (examples, ice) =>
      {
         ice.loop('exampleDoc', examples, (i, example, ice) =>
         {
            const parsed = parseExample(example);

            ice.text('exampleCode', parsed.body);
            ice.text('exampleCaption', parsed.caption);
         });
      });

      ice.into('tests', doc._custom_tests, (tests, ice) =>
      {
         ice.loop('test', tests, (i, test, ice) =>
         {
            const testDoc = eventbus.triggerSync('tjsdoc:data:docdb:find', { longname: test })[0];

            ice.load('test', eventbus.triggerSync('tjsdoc:system:publisher:doc:html:file:link:get', testDoc,
             testDoc.testFullDescription));
         });
      });


      // Store `memberof` query value with `doc.longname`.
      const memberof = doc.longname;

      // Get shared access docs between summary and detail output.

      // Static class members (category)
      let accessDocs = eventbus.triggerSync('tjsdoc:data:docdb:find:access:docs',
       { 'category': 'ClassMember', 'static': true, memberof });

      ice.load('staticMemberSummary', eventbus.triggerSync('tjsdoc:system:publisher:doc:html:summary:get', 'Members',
       accessDocs));

      ice.load('staticMemberDetails', eventbus.triggerSync('tjsdoc:system:publisher:doc:html:detail:get', 'Members',
       accessDocs));


      // Static class methods (only direct methods; no constructors or accessors)
      accessDocs = eventbus.triggerSync('tjsdoc:data:docdb:find:access:docs',
       { 'kind': 'ClassMethod', 'qualifier': 'method', 'static': true, memberof });

      ice.load('staticMethodSummary', eventbus.triggerSync('tjsdoc:system:publisher:doc:html:summary:get', 'Methods',
       accessDocs));

      ice.load('staticMethodDetails', eventbus.triggerSync('tjsdoc:system:publisher:doc:html:detail:get', 'Methods',
       accessDocs));

      // Only class constructors
      accessDocs = eventbus.triggerSync('tjsdoc:data:docdb:find:access:docs',
       { kind: 'ClassMethod', qualifier: 'constructor', memberof });

      ice.load('constructorSummary', eventbus.triggerSync('tjsdoc:system:publisher:doc:html:summary:get', 'Constructor',
       accessDocs));

      ice.load('constructorDetails', eventbus.triggerSync('tjsdoc:system:publisher:doc:html:detail:get', 'Constructors',
       accessDocs));


      // Only class members (category)
      accessDocs = eventbus.triggerSync('tjsdoc:data:docdb:find:access:docs',
       { 'category': 'ClassMember', 'static': false, memberof });

      ice.load('memberSummary', eventbus.triggerSync('tjsdoc:system:publisher:doc:html:summary:get', 'Members',
       accessDocs));

      ice.load('memberDetails', eventbus.triggerSync('tjsdoc:system:publisher:doc:html:detail:get', 'Members',
       accessDocs));

      // Class methods (only direct methods; no constructors or accessors)
      accessDocs = eventbus.triggerSync('tjsdoc:data:docdb:find:access:docs',
       { 'kind': 'ClassMethod', 'qualifier': 'method', 'static': false, memberof });

      ice.load('methodSummary', eventbus.triggerSync('tjsdoc:system:publisher:doc:html:summary:get', 'Methods',
       accessDocs));

      ice.load('methodDetails', eventbus.triggerSync('tjsdoc:system:publisher:doc:html:detail:get', 'Methods',
       accessDocs));

      ice.load('inheritedSummary', ClassDocBuilder._buildInheritedSummaryHTML(eventbus, doc), 'append');

      return ice;
   }

   /**
    * Build mixin extends HTML.
    *
    * @param {EventProxy}  eventbus - An event proxy for the main eventbus.
    * @param {DocObject}   doc - target class doc.
    *
    * @return {string} mixin extends HTML.
    * @private
    */
   static _buildMixinClassesHTML(eventbus, doc)
   {
      if (!doc.extends) { return ''; }
      if (doc.extends.length <= 1) { return ''; }

      const links = [];

      for (const longname of doc.extends)
      {
         links.push(eventbus.triggerSync('tjsdoc:system:publisher:doc:html:link:get', longname));
      }

      return `<div>${links.join(', ')}</div>`;
   }

   /**
    * Build expression extends HTML.
    *
    * @param {EventProxy}  eventbus - An event proxy for the main eventbus.
    * @param {DocObject}   doc - target class doc.
    *
    * @return {string} expression extends HTML.
    * @private
    */
   static _buildExpressionExtendsHTML(eventbus, doc)
   {
      if (!doc.expressionExtends) { return ''; }

      const html = doc.expressionExtends.replace(/[A-Z_$][a-zA-Z0-9_$]*/g, (v) =>
      {
         return eventbus.triggerSync('tjsdoc:system:publisher:doc:html:link:get', v);
      });

      return `class ${doc.name} extends ${html}`;
   }

   /**
    * Build class ancestor extends chain.
    *
    * @param {EventProxy}  eventbus - An event proxy for the main eventbus.
    * @param {DocObject}   doc - target class doc.
    *
    * @returns {string} extends chain links HTML.
    * @private
    */
   static _buildExtendsChainHTML(eventbus, doc)
   {
      if (!doc._custom_extends_chains) { return ''; }
      if (doc.extends.length > 1) { return ''; }

      const links = [];

      for (const longname of doc._custom_extends_chains)
      {
         links.push(eventbus.triggerSync('tjsdoc:system:publisher:doc:html:link:get', longname));
      }

      links.push(doc.name);

      return `<div>${links.join(' → ')}</div>`;
   }

   /**
    * Build in-direct subclass list.
    *
    * @param {EventProxy}  eventbus - An event proxy for the main eventbus.
    * @param {DocObject}   doc - target class doc.
    *
    * @returns {string} HTML of in-direct subclass links.
    * @private
    */
   static _buildIndirectSubclassHTML(eventbus, doc)
   {
      if (!doc._custom_indirect_subclasses) { return ''; }

      const links = [];

      for (const longname of doc._custom_indirect_subclasses)
      {
         links.push(eventbus.triggerSync('tjsdoc:system:publisher:doc:html:link:get', longname));
      }

      return `<div>${links.join(', ')}</div>`;
   }

   /**
    * Build direct subclass list.
    *
    * @param {EventProxy}  eventbus - An event proxy for the main eventbus.
    * @param {DocObject}   doc - target class doc.
    *
    * @returns {string} HTML of direct subclass links.
    * @private
    */
   static _buildDirectSubclassHTML(eventbus, doc)
   {
      if (!doc._custom_direct_subclasses) { return ''; }

      const links = [];

      for (const longname of doc._custom_direct_subclasses)
      {
         links.push(eventbus.triggerSync('tjsdoc:system:publisher:doc:html:link:get', longname));
      }

      return `<div>${links.join(', ')}</div>`;
   }

   /**
    * Build inherited method / member summary.
    *
    * @param {EventProxy}  eventbus - An event proxy for the main eventbus.
    * @param {DocObject}   doc - target class doc.
    *
    * @returns {string} HTML of inherited method/member from ancestor classes.
    * @private
    */
   static _buildInheritedSummaryHTML(eventbus, doc)
   {
      let docName;

      switch (doc.kind)
      {
         case 'ModuleClass':
            docName = 'class';
            break;

         case 'interface':       //TODO INTERFACE
            docName = 'interface';
            break;

         default:
            return '';
      }

      const longnames = [...doc._custom_extends_chains || []];

      const html = [];

      for (const longname of longnames)
      {
         const superDoc = eventbus.triggerSync('tjsdoc:data:docdb:find', { longname })[0];

         if (!superDoc) { continue; }

         // All class members and just class methods that aren't accessors or the constructor.
         const targetDocs = eventbus.triggerSync('tjsdoc:data:docdb:find',
          [{ memberof: longname, category: 'ClassMember' },
           { memberof: longname, kind: 'ClassMethod', qualifier: 'method' }]);

         const orderAccess = { 'public': 0, 'protected': 1, 'private': 2 };
         const orderKind = { get: 0, set: 0, member: 1, method: 2 };
         const orderKindFinal = { get: 0, set: 1, member: 2 };

         targetDocs.sort((a, b) =>
         {
            if (a.static !== b.static) { return -(a.static - b.static); }

            const aKind = a.kind === 'ClassMethod' ? a.qualifier : a.kind;
            const bKind = b.kind === 'ClassMethod' ? b.qualifier : b.kind;

            if (orderKind[aKind] !== orderKind[bKind]) { return orderKind[aKind] - orderKind[bKind]; }

            if (a.access !== b.access) { return orderAccess[a.access] - orderAccess[b.access]; }

            if (a.name !== b.name) { return a.name < b.name ? -1 : 1; }

            return orderKindFinal[aKind] - orderKindFinal[bKind];
         });

         const title = `<span class="toggle closed"></span> From ${docName} ${
          eventbus.triggerSync('tjsdoc:system:publisher:doc:html:link:get', longname, superDoc.name)}`;

         const result = eventbus.triggerSync('tjsdoc:system:publisher:docs:ice:cap:summary:get', targetDocs,
          '----------', false, superDoc.kind);

         if (result)
         {
            result.load('title', title, 'write');
            html.push(result.html);
         }
      }

      return html.join('\n');
   }
}
