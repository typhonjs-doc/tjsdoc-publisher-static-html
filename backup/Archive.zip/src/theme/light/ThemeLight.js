import Theme from '../Theme.js';

/**
 *
 */
export class ThemeLight extends Theme
{
   constructor()
   {
      super();

      this.addThemeDirName(__dirname);

      this.addThemeResource('copy', __dirname, './images');
      this.addThemeResource('prepend', __dirname, 'css/components/layout/fonts.css');
   }
}

export default new ThemeLight();
