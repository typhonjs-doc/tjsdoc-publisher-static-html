/**
 * Provides special handling for the TJSDoc MCW search text field. Below are overrides to the standard MCW
 * MDCTextfield component. In particular new input handlers are swapped out such that events can be handled locally.
 * The keydown handler will control the search results or if `ESC` is pressed cancel any current search. The blur
 * handler is deferred such that search results are not cleared immediately as the user may click in the results
 * panel with an input device (mouse, etc.).
 */
(function()
{
   var searchIndex = window.tjsdocSearchIndex;
   var result = document.querySelector('.search-result');
   var selectedIndex = -1;

   var searchText = mdc.textfield.MDCTextfield.attachTo($('#search-textfield-style')[0]);
   var prevText;

   var origBlurHandler = searchText.foundation_.inputBlurHandler_;
   var origFocusHandler = searchText.foundation_.inputFocusHandler_;
   var origInputHandler = searchText.foundation_.inputInputHandler_;
   var origKeydownHandler = searchText.foundation_.inputKeydownHandler_;

   searchText.foundation_.adapter_.deregisterInputBlurHandler(searchText.foundation_.inputBlurHandler_);
   searchText.foundation_.adapter_.deregisterInputFocusHandler(searchText.foundation_.inputFocusHandler_);
   searchText.foundation_.adapter_.deregisterInputInputHandler(searchText.foundation_.inputInputHandler_);
   searchText.foundation_.adapter_.deregisterInputKeydownHandler(searchText.foundation_.inputKeydownHandler_);

   searchText.foundation_.inputBlurHandler_ = function()
   {
      setTimeout(function()
      {
         console.log('!! BLUR');
         searchText.input_.value = '';

         selectedIndex = -1;
         result.style.display = 'none';
         result.innerHTML = '';

         origBlurHandler();
      }, 500);
   }

   searchText.foundation_.inputFocusHandler_ = function()
   {
      console.log('!! FOCUS');
      origFocusHandler();
   }

   searchText.foundation_.inputInputHandler_ = function()
   {
      origInputHandler();
      console.log('!! INPUT: ' + searchText.input_.value);

      populateSearchResults();
   }

   searchText.foundation_.inputKeydownHandler_ = function(ev)
   {
      origKeydownHandler();
      console.log('!! Key: ' + ev.keyCode);
      onHandleKeydown(ev);
   }

   searchText.foundation_.adapter_.registerInputBlurHandler(searchText.foundation_.inputBlurHandler_);
   searchText.foundation_.adapter_.registerInputFocusHandler(searchText.foundation_.inputFocusHandler_);
   searchText.foundation_.adapter_.registerInputInputHandler(searchText.foundation_.inputInputHandler_);
   searchText.foundation_.adapter_.registerInputKeydownHandler(searchText.foundation_.inputKeydownHandler_);

   setTimeout(function() { $('#search-textfield-style').css('display', 'inline-flex'); }, 500)

   // select search result when search result is mouse over.
   result.addEventListener('mousemove', function (ev)
   {
      var current = result.children[selectedIndex];

      if (current) { current.classList.remove('selected'); }

      var li = ev.target;

      while (li)
      {
         if (li.nodeName === 'LI') { break; }

         li = li.parentElement;
      }

      if (li)
      {
         selectedIndex = Array.prototype.indexOf.call(result.children, li);
         li.classList.add('selected');
      }
   });

   function onHandleKeydown(ev)
   {
      var current, selected;

      if (ev.keyCode === 27)
      {
         // ESC pressed; cancel search, but searchText focus remains enabled.
         searchText.input_.value = '';

         selectedIndex = -1;
         result.style.display = 'none';
         result.innerHTML = '';
      }
      else if (ev.keyCode === 40)
      {
         // arrow down
         current = result.children[selectedIndex];
         selected = result.children[selectedIndex + 1];

         if (selected && selected.classList.contains('search-separator'))
         {
            selected = result.children[selectedIndex + 2];
            selectedIndex++;
         }

         if (selected)
         {
            if (current) { current.classList.remove('selected'); }

            selectedIndex++;
            selected.classList.add('selected');
         }
      }
      else if (ev.keyCode === 38)
      {
         // arrow up
         current = result.children[selectedIndex];
         selected = result.children[selectedIndex - 1];

         if (selected && selected.classList.contains('search-separator'))
         {
            selected = result.children[selectedIndex - 2];
            selectedIndex--;
         }

         if (selected)
         {
            if (current) { current.classList.remove('selected'); }

            selectedIndex--;
            selected.classList.add('selected');
         }
      }
      else if (ev.keyCode === 13)
      {
         // enter
         current = result.children[selectedIndex];

         if (current)
         {
            var link = current.querySelector('a');

            if (link) { location.href = link.href; }
         }
      }
      else
      {
         return;
      }

      ev.preventDefault();
   }

   function populateSearchResults()
   {
      var text = searchText.input_.value.toLowerCase();

      if (!text)
      {
         result.style.display = 'none';
         result.innerHTML = '';
         prevText = void 0;
         return;
      }

      if (text === prevText) { return; }

      prevText = text;

      var html = {
         ModuleClass: [],
         ClassMethod: [],
         ClassMember: [],
         ModuleFunction: [],
         ModuleVariable: [],
         VirtualTypedef: [],
         VirtualExternal: [],
         ModuleFile: [],
         Test: [],
         ModuleTestFile: []
      };

      var len = searchIndex.length;
      var kind;

      for (var i = 0; i < len; i++)
      {
         var pair = searchIndex[i];

         if (pair[0].indexOf(text) !== -1)
         {
            kind = pair[3];
            html[kind].push('<li><a href="' + pair[1] + '">' + pair[2] + '</a></li>');
         }
      }

      var innerHTML = '';

      for (kind in html)
      {
         var list = html[kind];

         if (!list.length) { continue; }

         innerHTML += '<li class="search-separator">' + kind + '</li>\n' + list.join('\n');
      }

      if (innerHTML === '')
      {
         innerHTML += '<li class="search-separator">No results</li>\n';
      }

      result.innerHTML = innerHTML;

      if (innerHTML) { result.style.display = 'block'; }

      selectedIndex = -1;
   }
})();
