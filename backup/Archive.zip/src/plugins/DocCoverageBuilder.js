import PublishUtil from '../PublishUtil.js';

/**
 * Executes writing AST output.
 */
export function onHandlePublish(ev)
{
   if (ev.data.incremental)
   {
      if (ev.data.fileType === 'source' && !ev.data.minimal) { DocCoverageBuilder.exec(ev.data); }
   }
   else
   {
      DocCoverageBuilder.exec(ev.data);
   }
}

/**
 * Documentation coverage output builder.
 *
 * Creates badge.svg and writes coverage data.
 */
class DocCoverageBuilder
{
   /**
    * Executes writing badge.svg and documentation coverage data.
    *
    * @param {EventProxy}  eventbus - An event proxy for the plugin eventbus.
    *
    * @param {object}      sourceCoverage - The DocDB source coverage data.
    */
   static exec({ eventbus, mainConfig, silent, sourceCoverage } = {})
   {
      if (mainConfig.docCoverage && sourceCoverage)
      {
         eventbus.trigger('tjsdoc:system:file:write', JSON.stringify(sourceCoverage, null, 2), 'coverage.json', silent);

         // create badge
         let badge = PublishUtil.getTemplate('image/badge.svg');

         badge = badge.replace(/@ratio@/g, sourceCoverage.text);
         badge = badge.replace(/@color@/g, sourceCoverage.htmlColor);

         eventbus.trigger('tjsdoc:system:file:write', badge, 'badge.svg', silent);
      }
   }
}

