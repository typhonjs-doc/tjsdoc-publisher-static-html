/**
 * Documentation coverage output builder.
 *
 * Creates badge.svg and coverage data adding it to the event binding: 'tjsdoc:publisher:get:doc:coverage'.
 */
export default class CoverageBuilder
{
   /**
    * Executes writing badge.svg and building documentation coverage data.
    *
    * @param {EventProxy}  eventbus - An event proxy for the main eventbus.
    */
   static exec(eventbus)
   {
      const docs = eventbus.triggerSync('tjsdoc:data:docdb:find',
      {
         kind:
         [
            'ClassMember',
            'ClassMethod',
            'ClassProperty',
            'ModuleAssignment',
            'ModuleClass',
            'ModuleFunction',
            'ModuleVariable'
         ]
      });

      let actualCount = 0;
      const expectCount = docs.length;
      const files = {};

      for (const doc of docs)
      {
         const filePath = doc.longname.split('~')[0];

         if (!files[filePath]) { files[filePath] = { expectCount: 0, actualCount: 0, undocumentLines: [] }; }

         files[filePath].expectCount++;

         if (doc.undocument)
         {
            files[filePath].undocumentLines.push(doc.lineNumber);
         }
         else
         {
            actualCount++;
            files[filePath].actualCount++;
         }
      }

      const coveragePercent = (expectCount === 0 ? 0 : Math.floor(10000 * actualCount / expectCount) / 100);

      let ansiColor = '[32m'; // green

      if (coveragePercent < 90) { ansiColor = '[33m'; } // yellow
      if (coveragePercent < 50) { ansiColor = '[31m'; } // red
      if (coveragePercent < 25) { ansiColor = '[1;31m'; } // light red

      const coverage =
      {
         coverage: `${coveragePercent}%`,
         coveragePercent,
         ansiColor,
         expectCount,
         actualCount,
         files
      };

      eventbus.on('tjsdoc:publisher:get:doc:coverage', () => { return coverage; });

      eventbus.trigger('tjsdoc:system:file:write', JSON.stringify(coverage, null, 2), 'coverage.json');

      // create badge
      const ratio = Math.floor(100 * actualCount / expectCount);
      let color;

      if (ratio < 50)
      {
         color = '#db654f';
      }
      else if (ratio < 90)
      {
         color = '#dab226';
      }
      else
      {
         color = '#4fc921';
      }

      let badge = eventbus.triggerSync('tjsdoc:system:publisher:template:get', 'image/badge.svg');

      badge = badge.replace(/@ratio@/g, `${ratio}%`);
      badge = badge.replace(/@color@/g, color);

      eventbus.trigger('tjsdoc:system:file:write', badge, 'badge.svg');
   }
}
