/**
 * Handles adding main menu link for any repository.
 *
 * @param {PluginEvent} ev - The plugin event.
 */
export function onPreGenerate(ev)
{
   if (typeof ev.data.packageInfo === 'object' && ev.data.packageInfo.repository.url)
   {
      const menuEntry = { label: 'Repository', href: 'this._packageInfo.repository.url' };

      // Add CSS class for github repo url
      if (ev.data.packageInfo.repository.url.match(new RegExp('^https?://github.com/')))
      {
         menuEntry.cssClass = 'repo-url-github';
      }

      ev.data.pubConfig._mainMenuLinks.push(menuEntry);
   }
}
