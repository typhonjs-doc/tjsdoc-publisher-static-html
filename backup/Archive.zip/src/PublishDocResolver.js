import markdown from './utils/markdown.js';

/**
 * Resolve various publisher related properties in DocDB / TaffyDB data.
 */
export default class PublishDocResolver
{
   /**
    * Resolve various properties.
    *
    * @param {EventProxy}  eventbus - An event proxy for the main eventbus.
    */
   static resolve(eventbus)
   {
      eventbus.trigger('log:info:raw', 'publish resolve: markdown in description');
      PublishDocResolver._resolveMarkdown(eventbus);

      eventbus.trigger('log:info:raw', 'publish resolve: link');
      PublishDocResolver._resolveLink(eventbus);

      eventbus.trigger('log:info:raw', 'publish resolve: test relation');
      PublishDocResolver._resolveTestRelation(eventbus);
   }

   /**
    * Resolve description as markdown.
    *
    * @param {EventProxy}  eventbus - An event proxy for the main eventbus.
    *
    * @private
    */
   static _resolveMarkdown(eventbus)
   {
      const convert = (doc) =>
      {
         for (const key of Object.keys(doc))
         {
            const value = doc[key];

            if (key === 'description' && typeof value === 'string')
            {
               doc[`${key}HTML`] = markdown(value, false);
            }
            else if (typeof value === 'object' && value)
            {
               convert(value);
            }
         }
      };

      for (const doc of eventbus.triggerSync('tjsdoc:data:docdb:find')) { convert(doc); }
   }

   /**
    * Resolve @link tags as HTML links.
    *
    * @param {EventProxy}  eventbus - An event proxy for the main eventbus.
    *
    * @private
    * @todo Resolve all ``description`` property.
    */
   static _resolveLink(eventbus)
   {
      const link = (str) =>
      {
         if (!str) { return str; }

         return str.replace(/\{@link ([\w#_\-.:~\/$]+)}/g, (str, longname) =>
         {
            return eventbus.triggerSync('tjsdoc:system:publisher:doc:html:link:get', longname, longname);
         });
      };

      eventbus.triggerSync('tjsdoc:data:docdb:query').each((v) =>
      {
         v.descriptionHTML = link(v.descriptionHTML);

         if (v.params)
         {
            for (const param of v.params)
            {
               param.descriptionHTML = link(param.descriptionHTML);
            }
         }

         if (v.properties)
         {
            for (const property of v.properties)
            {
               property.descriptionHTML = link(property.descriptionHTML);
            }
         }

         if (v.return)
         {
            v.return.descriptionHTML = link(v.return.descriptionHTML);
         }

         if (v.throws)
         {
            for (const _throw of v.throws)
            {
               _throw.descriptionHTML = link(_throw.descriptionHTML);
            }
         }

         if (v.see)
         {
            for (let i = 0; i < v.see.length; i++)
            {
               if (v.see[i].startsWith('{@link'))
               {
                  v.see[i] = link(v.see[i]);
               }
               else if (v.see[i].startsWith('<a href'))
               {
                  // ignore
               }
               else
               {
                  v.see[i] = `<a href="${v.see[i]}">${v.see[i]}</a>`;
               }
            }
         }
      });
   }

   /**
    * Resolve tests and identifier relationships adding the following special properties:
    * - ``_custom_tests``: longnames of test doc.
    * - ``_custom_test_targets``: longnames of identifier.
    *
    * @param {EventProxy}  eventbus - An event proxy for the main eventbus.
    *
    * @private
    */
   static _resolveTestRelation(eventbus)
   {
      /**
       * Tracks which docs need to initialize `_custom_<X>` lists.
       * @type {{}}
       */
      const seenData = {};

      /**
       * Stores data in `seenData` by doc.longname -> `_custom_<X>` list name tracking which docs need to initialize
       * `_custom_<X>` lists. This is necessary to reinitialize as resolving can occur multiple times across the
       * same data.
       *
       * @param {DocObject}   doc - DocObject to test.
       *
       * @param {string}      type - `_custom_<X>` list name.
       *
       * @returns {boolean} Result if whether the custom list name for the given doc object has already been seen.
       */
      const seen = (doc, type) =>
      {
         if (typeof seenData[doc.longname] !== 'object') { seenData[doc.longname] = {}; }

         const docData = seenData[doc.longname];

         const typeSeen = docData[type] || false;

         docData[type] = true;

         return typeSeen;
      };

      const testDocs = eventbus.triggerSync('tjsdoc:data:docdb:find', { kind: 'Test' });

      for (const testDoc of testDocs)
      {
         const testTargets = testDoc.testTargets;

         if (!testTargets) { continue; }

         for (const testTarget of testTargets)
         {
            const doc = eventbus.triggerSync('tjsdoc:data:docdb:find:by:name', testTarget)[0];

            if (doc)
            {
               if (!seen(doc, '_custom_tests')) { doc._custom_tests = []; }

               doc._custom_tests.push(testDoc.longname);

               if (!seen(testDoc, '_custom_test_targets')) { testDoc._custom_test_targets = []; }

               testDoc._custom_test_targets.push([doc.longname, testTarget]);
            }
            else
            {
               if (!seen(testDoc, '_custom_test_targets')) { testDoc._custom_test_targets = []; }

               testDoc._custom_test_targets.push([testTarget, testTarget]);
            }
         }
      }

      // test full description
      for (const testDoc of testDocs)
      {
         const desc = [];
         const parents = (testDoc.memberof.split('~')[1] || '').split('.');

         for (const parent of parents)
         {
            const doc = eventbus.triggerSync('tjsdoc:data:docdb:find', { kind: 'Test', name: parent })[0];

            if (!doc) { continue; }

            desc.push(doc.description);
         }

         desc.push(testDoc.description);
         testDoc.testFullDescription = desc.join(' ');
      }
   }
}
