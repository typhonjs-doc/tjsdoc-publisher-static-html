import path from 'path';

const s_LOG_PREPEND = 'tjsdoc-publisher-static-html-resources - ';

/**
 * Copies all static resources from template.
 */
export function onHandlePublishAsync(ev)
{
   if (!ev.data.incremental) { StaticFileCopy.exec(ev.data); }
}

/**
 * Static file output builder.
 */
class StaticFileCopy
{
   /**
    * Copies all static resources from template.
    *
    * @param {EventProxy}  eventbus - An event proxy for the main eventbus.
    */
   static exec({ eventbus, pubConfig, silent } = {})
   {
      eventbus.trigger('typhonjs:util:file:copy', {
         srcPath: path.resolve(__dirname, '../../template/css'),
         destPath: './css',
         logPrepend: s_LOG_PREPEND,
         silent
      });

      eventbus.trigger('typhonjs:util:file:copy', {
         srcPath: path.resolve(__dirname, '../../template/scripts'),
         destPath: './scripts',
         logPrepend: s_LOG_PREPEND,
         silent
      });

      eventbus.trigger('typhonjs:util:file:copy', {
         srcPath: path.resolve(__dirname, '../../template/images'),
         destPath: './images',
         logPrepend: s_LOG_PREPEND,
         silent
      });

      eventbus.trigger('typhonjs:util:file:copy', {
         srcPath: path.resolve(__dirname, '../../node_modules/material-components-web/dist/material-components-web.css'),
         destPath: './css/material-components-web.css',
         logPrepend: s_LOG_PREPEND,
         silent
      });

      eventbus.trigger('typhonjs:util:file:copy', {
         srcPath: path.resolve(__dirname, '../../node_modules/material-components-web/dist/material-components-web.js'),
         destPath: './scripts/material-components-web.js',
         logPrepend: s_LOG_PREPEND,
         silent
      });

      eventbus.trigger('typhonjs:util:file:copy', {
         srcPath: path.resolve(__dirname, '../../node_modules/velocity-animate/velocity.js'),
         destPath: './scripts/velocity.js',
         logPrepend: s_LOG_PREPEND,
         silent
      });

      eventbus.trigger('typhonjs:util:file:copy', {
         srcPath: path.resolve(__dirname, '../../node_modules/zepto/dist/zepto.js'),
         destPath: './scripts/zepto.js',
         logPrepend: s_LOG_PREPEND,
         silent
      });

      // see DocBuilder#_buildLayoutDoc
      const scripts = pubConfig.scripts || [];

      for (let i = 0; i < scripts.length; i++)
      {
         const userScript = scripts[i];
         const name = `./user/scripts/${i}-${path.basename(userScript)}`;

         eventbus.trigger('typhonjs:util:file:copy', {
            srcPath: userScript,
            destPath: name,
            logPrepend: s_LOG_PREPEND,
            silent
         });
      }

      const styles = pubConfig.styles || [];

      for (let i = 0; i < styles.length; i++)
      {
         const userStyle = styles[i];
         const name = `./user/css/${i}-${path.basename(userStyle)}`;

         eventbus.trigger('typhonjs:util:file:copy', {
            srcPath: userStyle,
            destPath: name,
            logPrepend: s_LOG_PREPEND,
            silent
         });
      }
   }
}
