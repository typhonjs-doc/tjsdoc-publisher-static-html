/**
 * Test file output HTML builder.
 */
export default class TestFileDocBuilder
{
   /**
    * Executes building output HTML.
    *
    * @param {EventProxy}  eventbus - An event proxy for the main eventbus.
    */
   static exec(eventbus)
   {
      const ice = eventbus.triggerSync('tjsdoc:system:publisher:ice:cap:layout:get');

      const docs = eventbus.triggerSync('tjsdoc:data:docdb:find', { kind: 'testFile' });

      for (const doc of docs)
      {
         const fileName = eventbus.triggerSync('tjsdoc:system:publisher:doc:file:name:get', doc);
         const baseUrl = eventbus.triggerSync('tjsdoc:system:publisher:file:url:base:get', fileName);
         const title = eventbus.triggerSync('tjsdoc:system:publisher:title:get', doc);

         ice.load('content', TestFileDocBuilder._buildFileDoc(eventbus, doc), 'write');
         ice.attr('baseUrl', 'href', baseUrl, 'write');
         ice.text('title', title, 'write');

         eventbus.trigger('tjsdoc:system:file:write', ice.html, fileName);
      }
   }

   /**
    * Build test file output HTML.
    *
    * @param {EventProxy}  eventbus - An event proxy for the main eventbus.
    *
    * @param {DocObject} doc - target file doc object.
    *
    * @returns {string} HTML of file output.
    * @private
    */
   static _buildFileDoc(eventbus, doc)
   {
      const ice = eventbus.triggerSync('tjsdoc:system:publisher:ice:cap:template:get', 'file.html');

      ice.text('title', doc.longname);
      ice.text('content', doc.content);
      ice.drop('emptySourceCode', !!doc.content);

      return ice.html;
   }
}
