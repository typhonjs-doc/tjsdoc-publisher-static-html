/**
 * Provides special handling for the TJSDoc overflow menu. The menu items added should have `data-href` defined and
 * optionally `data-target`.
 */
(function()
{
   var menuEl = document.querySelector('#tjsdoc-toolbar-menu-overflow');
   var menu = new mdc.menu.MDCSimpleMenu(menuEl);
   var toggle = document.querySelector('.tjsdoc-toolbar-button-overflow');

   toggle.addEventListener('click', function()
   {
      // Set menu position based on the left position of `toggle` button.
      menu.foundation_.adapter_.setPosition({ left: toggle.offsetLeft + 'px' });

      menu.open = !menu.open;
   });

   // When the browser window is resized close the menu.
   $(window).resize(function() { menu.open = false; });

   // Navigate to a new location or try to open a new window if `data-target` is defined.
   menuEl.addEventListener('MDCSimpleMenu:selected', function(evt)
   {
      var detail = evt.detail;

      var href = detail.item.getAttribute('data-href');
      var target = detail.item.getAttribute('data-target');

      if (typeof href === 'string')
      {
         try
         {
            if (typeof target === 'string' && target !== '')
            {
               window.open(href, target);
            }
            else
            {
               window.location.assign(href)
            }
         }
         catch (err)
         {
            window.location.assign(href)
         }
      }
   });
})();


/**
 * Provides special handling for the TJSDoc MCW search text field. Below are overrides to the standard MCW
 * MDCTextfield component. In particular new input handlers are swapped out such that events can be handled locally.
 * The keydown handler will control the search results or if `ESC` is pressed cancel any current search. The blur
 * handler is deferred such that search results are not cleared immediately as the user may click in the results
 * panel with an input device (mouse, etc.).
 */
(function()
{
   var searchIndex = window.tjsdocSearchIndex;
   var searchResult = document.querySelector('.search-result');
   var selectedIndex = -1;

   var searchText = mdc.textfield.MDCTextfield.attachTo($('#search-textfield')[0]);
   var prevText;

   /**
    * Cancels any existing search.
    */
   function cancelSearch()
   {
      prevText = void 0;

      searchText.input_.value = '';

      selectedIndex = -1;

      searchResult.innerHTML = '';
      searchResult.scrollTop = 0;
      searchResult.scrollLeft = 0;
      searchResult.style.display = 'none';
   }

   // Removes any entered text when browser is refreshed or goes back / forward.
   $(window).on('beforeunload', cancelSearch);

   var origBlurHandler = searchText.foundation_.inputBlurHandler_;
   var origFocusHandler = searchText.foundation_.inputFocusHandler_;
   var origInputHandler = searchText.foundation_.inputInputHandler_;
   var origKeydownHandler = searchText.foundation_.inputKeydownHandler_;

   searchText.foundation_.adapter_.deregisterInputBlurHandler(searchText.foundation_.inputBlurHandler_);
   searchText.foundation_.adapter_.deregisterInputFocusHandler(searchText.foundation_.inputFocusHandler_);
   searchText.foundation_.adapter_.deregisterInputInputHandler(searchText.foundation_.inputInputHandler_);
   searchText.foundation_.adapter_.deregisterInputKeydownHandler(searchText.foundation_.inputKeydownHandler_);

   searchText.foundation_.inputBlurHandler_ = function()
   {
      setTimeout(function()
      {
         cancelSearch();

         origBlurHandler();
      }, 500);
   }

   searchText.foundation_.inputFocusHandler_ = function()
   {
      origFocusHandler();
   }

   searchText.foundation_.inputInputHandler_ = function()
   {
      origInputHandler();

      populateSearchResults();
   }

   searchText.foundation_.inputKeydownHandler_ = function(ev)
   {
      origKeydownHandler();

      onHandleKeydown(ev);
   }

   searchText.foundation_.adapter_.registerInputBlurHandler(searchText.foundation_.inputBlurHandler_);
   searchText.foundation_.adapter_.registerInputFocusHandler(searchText.foundation_.inputFocusHandler_);
   searchText.foundation_.adapter_.registerInputInputHandler(searchText.foundation_.inputInputHandler_);
   searchText.foundation_.adapter_.registerInputKeydownHandler(searchText.foundation_.inputKeydownHandler_);

   setTimeout(function() { $('.tjsdoc-toolbar__search').css('display', 'inline-flex'); }, 500)

   // select search result when search result is mouse over.
   searchResult.addEventListener('mousemove', function (ev)
   {
      var current = searchResult.children[selectedIndex];

      if (current) { current.classList.remove('selected'); }

      var li = ev.target;

      while (li)
      {
         if (li.nodeName === 'LI') { break; }

         li = li.parentElement;
      }

      if (li)
      {
         selectedIndex = Array.prototype.indexOf.call(searchResult.children, li);
         li.classList.add('selected');
      }
   });

   function onHandleKeydown(ev)
   {
      var current, selected;

      if (ev.keyCode === 27)
      {
         // ESC pressed; cancel search, but searchText focus remains enabled.
         cancelSearch();
      }
      else if (ev.keyCode === 40)
      {
         // arrow down
         current = searchResult.children[selectedIndex];
         selected = searchResult.children[selectedIndex + 1];

         if (selected && selected.classList.contains('search-separator'))
         {
            selected = searchResult.children[selectedIndex + 2];
            selectedIndex++;
         }

         if (selected)
         {
            if (current) { current.classList.remove('selected'); }

            selectedIndex++;
            selected.classList.add('selected');
         }
      }
      else if (ev.keyCode === 38)
      {
         // arrow up
         current = searchResult.children[selectedIndex];
         selected = searchResult.children[selectedIndex - 1];

         if (selected && selected.classList.contains('search-separator'))
         {
            selected = searchResult.children[selectedIndex - 2];
            selectedIndex--;
         }

         if (selected)
         {
            if (current) { current.classList.remove('selected'); }

            selectedIndex--;
            selected.classList.add('selected');
         }
      }
      else if (ev.keyCode === 13)
      {
         // enter
         current = searchResult.children[selectedIndex];

         if (current)
         {
            var link = current.querySelector('a');

            if (link) { location.href = link.href; }
         }
      }
      else
      {
         return;
      }

      ev.preventDefault();
   }

   function populateSearchResults()
   {
      var text = searchText.input_.value.toLowerCase();

      if (!text)
      {
         cancelSearch();
         return;
      }

      if (text === prevText) { return; }

      prevText = text;

      var html = {
         ModuleClass: [],
         ClassMethod: [],
         ClassMember: [],
         ModuleFunction: [],
         ModuleVariable: [],
         VirtualTypedef: [],
         // VirtualExternal: [],  // Excluded from search results.
         ModuleFile: [],
         Test: [],
         ModuleTestFile: []
      };

      var len = searchIndex.length;
      var kind;

      for (var i = 0; i < len; i++)
      {
         var pair = searchIndex[i];

         if (pair[0].indexOf(text) !== -1)
         {
            kind = pair[3];

            if (typeof html[kind] !== 'undefined')
            {
               html[kind].push('<li><div><a href="' + pair[1] + '">' + pair[2] + '</a></div></li>');
            }
         }
      }

      var innerHTML = '';

      for (kind in html)
      {
         var list = html[kind];

         if (!list.length) { continue; }

         innerHTML += '<li class="search-separator"><div>' + kind + '</div></li>\n' + list.join('\n');
      }

      if (innerHTML === '')
      {
         innerHTML += '<li class="search-separator"><div class="no-results">No results</div></li>\n';
      }

      searchResult.innerHTML = innerHTML;

      if (innerHTML)
      {
         searchResult.style.display = 'block';
      }

      selectedIndex = -1;
   }
})();
