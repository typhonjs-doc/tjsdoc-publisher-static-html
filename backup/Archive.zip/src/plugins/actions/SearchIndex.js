import PublishUtil from '../../PublishUtil.js';

/**
 * Executes writing search index.
 */
export function onHandlePublish(ev)
{
   if (ev.data.incremental)
   {
      if (!ev.data.minimal && (ev.data.fileType === 'source' || ev.data.fileType === 'test'))
      {
         SearchIndex.exec(ev.data);
      }
   }
   else
   {
      SearchIndex.exec(ev.data);
   }
}

/**
 * Search index builder for identifiers.
 */
export class SearchIndex
{
   /**
    * Executes writing search index.
    *
    * @param {EventProxy}  eventbus - An event proxy for the main eventbus.
    */
   static exec({ docDB, eventbus, silent } = {})
   {
      const searchIndex = [];
      const docs = docDB.find();

      for (const doc of docs)
      {
         let indexText;
         let url;
         let displayText;

         if (doc.importPath)
         {
            displayText = `<span>${doc.name}</span> <span class="search-result-import-path">${doc.importPath}</span>`;
            indexText = `${doc.importPath}~${doc.name}`.toLowerCase();

            url = PublishUtil.getDocURL(doc);
         }
         else
         {
            switch (doc.kind)
            {
               // Skip processing any memory docs.
               case 'ModuleMemory':
                  continue;

               case 'VirtualExternal':
                  displayText = doc.name;
                  indexText = displayText.toLowerCase();

                  url = doc.externalLink;
                  break;

               case 'Test':
               {
                  displayText = doc.testFullDescription;
                  indexText = [...(doc.testTargets || []), ...(doc._custom_test_targets || [])].join(' ').toLowerCase();

                  const filePath = doc.longname.split('~')[0];

                  const fileDoc = docDB.find({ kind: 'ModuleTestFile', longname: filePath })[0];

                  url = `${PublishUtil.getDocURL(fileDoc)}#lineNumber${doc.lineNumber}`;

                  break;
               }

               case 'ClassMember':
               case 'ClassMethod':
               case 'ClassProperty':
               {
                  const filePath = doc.longname.split('~')[0];
                  const memberName = doc.longname.split('~')[1];

                  displayText = `<span>${memberName}</span> <span class="search-result-import-path">${filePath}</span>`;
                  indexText = memberName.toLowerCase();

                  url = PublishUtil.getDocURL(doc);
                  break;
               }

               case 'VirtualTypedef':
                  displayText = doc.name;
                  indexText = displayText.toLowerCase();

                  url = PublishUtil.getDocURL(doc);
                  break;

               default:
                  displayText = doc.longname;
                  indexText = displayText.toLowerCase();

                  url = PublishUtil.getDocURL(doc);
                  break;
            }
         }

         searchIndex.push([indexText, url, displayText, doc.category]);
      }

      searchIndex.sort((a, b) => a[2] === b[2] ? 0 : a[2] < b[2] ? -1 : 1);

      // Allow any plugins to modify the search index JSON before serializing.
      eventbus.triggerSync('plugins:invoke:sync:event', 'onHandleSearchIndex', void 0, { searchIndex });

      const javascript = `window.tjsdocSearchIndex = ${JSON.stringify(searchIndex, null, 2)}`;

      eventbus.trigger('tjsdoc:system:file:write', javascript, 'script/search_index.js', silent);
   }
}
