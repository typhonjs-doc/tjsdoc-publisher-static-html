import PublishDocResolver  from './PublishDocResolver.js';
import PublishUtil         from './PublishUtil.js';
import ConfigData          from './ConfigData.js';

export default class Publisher
{
   /**
    * Adds all common runtime plugins.
    *
    * @param {PluginEvent} ev - The plugin event.
    */
   static onPluginLoad(ev)
   {
      const eventbus = ev.eventbus;

      eventbus.on('tjsdoc:data:config:publisher:resolver:get', () => ConfigData.createResolverData());

      // Add the IceCap plugin for DOM / template generation.
      eventbus.trigger('plugins:add:all', [
         { name: 'typhonjs-ice-cap', instance: require('typhonjs-ice-cap') },
         { name: 'tjsdoc-publisher-static-html-util', instance: PublishUtil },

         // These plugins create main menu links so order matters.
         { name: 'tjsdoc-publisher-static-html-index', instance: require('./content/index/IndexDoc') },
         { name: 'tjsdoc-publisher-static-html-manual', instance: require('./content/manual/ManualDoc') },
         { name: 'tjsdoc-publisher-static-html-reference', instance: require('./content/reference/ReferenceDoc') },
         { name: 'tjsdoc-publisher-static-html-source', instance: require('./content/source/SourceDoc') },
         { name: 'tjsdoc-publisher-static-html-test', instance: require('./content/test/TestDoc') },
         { name: 'tjsdoc-publisher-static-html-repo-link', instance: require('./actions/RepoLink') },

         { name: 'tjsdoc-publisher-static-html-ast', instance: require('./actions/ASTData') },
         { name: 'tjsdoc-publisher-static-html-doccoverage', instance: require('./actions/DocCoverage') },
         { name: 'tjsdoc-publisher-static-html-docdata', instance: require('./actions/DocData') },
         { name: 'tjsdoc-publisher-static-html-package', instance: require('./actions/PackageCopy') },
         { name: 'tjsdoc-publisher-static-html-search', instance: require('./actions/SearchIndex') },
         { name: 'tjsdoc-publisher-static-html-resources', instance: require('./actions/StaticFileCopy') },

         { name: 'tjsdoc-publisher-static-html-details', instance: require('./components/details/Details') },
         { name: 'tjsdoc-publisher-static-html-nav', instance: require('./components/navigation/old/OldNav') },
         { name: 'tjsdoc-publisher-static-html-summary', instance: require('./components/summary/Summary') },

         { name: 'tjsdoc-publisher-static-html-class', instance: require('./content/class/ClassDoc') },
         { name: 'tjsdoc-publisher-static-html-file', instance: require('./content/file/FileDoc') },
         { name: 'tjsdoc-publisher-static-html-single', instance: require('./content/single/SingleDoc') },
         { name: 'tjsdoc-publisher-static-html-test-file', instance: require('./content/test/TestFileDoc') }
      ]);

      // Instances are being loaded into the plugin manager so auto log filtering needs an explicit filter.
      eventbus.trigger('log:filter:add',
      {
         type: 'inclusive',
         name: 'tjsdoc-publisher-static-html',
         filterString: '(tjsdoc-publisher-static-html\/dist|tjsdoc-publisher-static-html\/src)'
      });
   }

   static onPreGenerate(ev)
   {
      // Add PublishDocResolver in onPreGenerate so that it executes after CoreDocResolver with the shared
      // event binding.
      ev.eventbus.trigger('plugins:add', { name: 'tjsdoc-doc-resolver-publish', instance: new PublishDocResolver() });

      // Set IceCap debug mode if `this._pubConfig.debug` is true. Helps find any errors in template generation.
      ev.eventbus.trigger('typhonjs:ice:cap:debug:set', ev.data.pubConfig.debug);
   }

   static onHandlePrePublish(ev)
   {
      // Handle special cases for incremental publishing
      if (ev.data.incremental)
      {
         // Incremental publishing is not available when output is compressed.
         if (ev.data.mainConfig.compressOutput)
         {
            throw new Error(
             `tjsdoc-publisher-static-html - can not incrementally publish as config option 'compressOutput' is enabled.`);
         }

         // If non-minimal incremental publishing then add source coverage.
         if (!ev.data.minimal)
         {
            ev.data.sourceCoverage = ev.data.docDB.getSourceCoverage({ includeFiles: true });
         }
      }
      else
      {
         // Handle publish all / complete; always add source coverage.
         ev.data.sourceCoverage = ev.data.docDB.getSourceCoverage({ includeFiles: true });
      }

      // Registers current DocDB association.
      PublishUtil.reset(ev.data);

      // Note the compression format extension will automatically be added.
      if (!ev.data.incremental && ev.data.mainConfig.compressOutput)
      {
         ev.eventbus.trigger('tjsdoc:system:file:archive:create', 'docs');
      }
   }

   static onHandlePostPublish(ev)
   {
      if (!ev.data.incremental && ev.data.mainConfig.compressOutput)
      {
         ev.eventbus.trigger('typhonjs:util:file:archive:finalize');
      }

      // Resets DocDB to main DocDB.
      PublishUtil.reset();
   }
}
