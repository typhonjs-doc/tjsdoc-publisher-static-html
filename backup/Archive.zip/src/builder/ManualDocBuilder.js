import cheerio    from 'cheerio';
import fs         from 'fs';
import path       from 'path';

import markdown   from '../utils/markdown.js';

/**
 * Manual output builder.
 */
export default class ManualDocBuilder
{
   /**
    * Executes writing manual based on `publisherOptions.manual`.
    *
    * @param {EventProxy}  eventbus - An event proxy for the main eventbus.
    */
   static exec(eventbus)
   {
      // Remove cached left-hand navigation.
      cachedHTMLNav = void 0;

      const pubConfig = eventbus.triggerSync('tjsdoc:data:publisher:config:get');

      if (!pubConfig.manual) { return; }

      const manualConfig = ManualDocBuilder._getManualConfig(eventbus);
      const ice = eventbus.triggerSync('tjsdoc:system:publisher:ice:cap:layout:get');

      const identifiers = eventbus.triggerSync('tjsdoc:data:docdb:find:all:identifiers:kind:grouping');

      ice.autoDrop = false;

      ice.attr('rootContainer', 'class', ' manual-root');

      {
         const fileName = 'manual/index.html';
         const baseUrl = eventbus.triggerSync('tjsdoc:system:publisher:file:url:base:get', fileName);

         ManualDocBuilder._buildManualIndex(eventbus, manualConfig, identifiers);

         ice.load('content', ManualDocBuilder._buildManualCardIndex(eventbus, manualConfig, identifiers), 'write');
         ice.load('nav', ManualDocBuilder._buildManualNav(eventbus, manualConfig, identifiers), 'write');
         ice.text('title', 'Manual', 'write');
         ice.attr('baseUrl', 'href', baseUrl, 'write');
         ice.attr('rootContainer', 'class', ' manual-index');

         eventbus.trigger('tjsdoc:system:file:write', ice.html, fileName);

         if (pubConfig.manual.globalIndex)
         {
            ice.attr('baseUrl', 'href', './', 'write');

            eventbus.trigger('tjsdoc:system:file:write', ice.html, 'index.html');
         }

         ice.attr('rootContainer', 'class', ' manual-index', 'remove');
      }

      for (const item of manualConfig)
      {
         if (!item.paths) { continue; }

         for (const filePath of item.paths)
         {
            const fileName = ManualDocBuilder._getManualOutputFileName(item, filePath);
            const baseUrl = eventbus.triggerSync('tjsdoc:system:publisher:file:url:base:get', fileName);

            ice.load('content', ManualDocBuilder._buildManual(eventbus, item, filePath), 'write');
            ice.load('nav', ManualDocBuilder._buildManualNav(eventbus, manualConfig, identifiers), 'write');
            ice.text('title', item.label, 'write');
            ice.attr('baseUrl', 'href', baseUrl, 'write');

            eventbus.trigger('tjsdoc:system:file:write', ice.html, fileName);
         }
      }

      if (pubConfig.manual.asset)
      {
         eventbus.trigger('typhonjs:util:file:copy', pubConfig.manual.asset, 'manual/asset');
      }

      // badge
      {
         const ratio = Math.floor(100 * (manualConfig.length - 1) / 10);

         let color;

         if (ratio < 50)
         {
            color = '#db654f';
         }
         else if (ratio < 90)
         {
            color = '#dab226';
         }
         else
         {
            color = '#4fc921';
         }

         let badge = eventbus.triggerSync('tjsdoc:system:publisher:template:get', 'image/manual-badge.svg');

         badge = badge.replace(/@value@/g, `${ratio}%`);
         badge = badge.replace(/@color@/g, color);

         eventbus.trigger('tjsdoc:system:file:write', badge, 'manual-badge.svg');
      }
   }

   /**
    * Get manual config based on `publisherOptions.manual`.
    *
    * @param {EventProxy}  eventbus - An event proxy for the main eventbus.
    *
    * @returns {ManualConfigItem[]} built manual from publisher options.
    * @private
    */
   static _getManualConfig(eventbus)
   {
      const pubConfig = eventbus.triggerSync('tjsdoc:data:publisher:config:get');

      const m = pubConfig.manual;
      const manualConfig = [];

      if (m.overview) { manualConfig.push({ label: 'Overview', paths: m.overview }); }
      if (m.design) { manualConfig.push({ label: 'Design', paths: m.design }); }
      if (m.installation) { manualConfig.push({ label: 'Installation', paths: m.installation }); }
      if (m.tutorial) { manualConfig.push({ label: 'Tutorial', paths: m.tutorial }); }
      if (m.usage) { manualConfig.push({ label: 'Usage', paths: m.usage }); }
      if (m.configuration) { manualConfig.push({ label: 'Configuration', paths: m.configuration }); }
      if (m.advanced) { manualConfig.push({ label: 'Advanced', paths: m.advanced }); }
      if (m.example) { manualConfig.push({ label: 'Example', paths: m.example }); }

      manualConfig.push({ label: 'Reference', fileName: 'identifiers.html', references: true });

      if (m.faq) { manualConfig.push({ label: 'FAQ', paths: m.faq }); }
      if (m.changelog) { manualConfig.push({ label: 'Changelog', paths: m.changelog }); }

      return manualConfig;
   }

   /**
    * Build manual navigation.
    *
    * @param {EventProxy}           eventbus - An event proxy for the main eventbus.
    *
    * @param {ManualConfigItem[]}   manualConfig - target manual config.
    *
    * @return {IceCap} built navigation
    * @private
    */
   static _buildManualNav(eventbus, manualConfig, identifiers)
   {
      // Return a cached version of the left-hand navigation.
      if (cachedHTMLNav) { return cachedHTMLNav; }

      // Otherwise build left-hand navigation and cache it.

      const ice = ManualDocBuilder._buildManualIndex(eventbus, manualConfig, identifiers);
      const $root = cheerio.load(ice.html).root();

      $root.find('.github-markdown').removeClass('github-markdown');

      cachedHTMLNav = $root.html();

      return cachedHTMLNav;
   }

   /**
    * Build manual.
    *
    * @param {EventProxy}        eventbus - An event proxy for the main eventbus.
    *
    * @param {ManualConfigItem}  item - target manual config item.
    *
    * @param {string}            filePath - target manual file path.
    *
    * @return {IceCap} built manual.
    * @private
    */
   static _buildManual(eventbus, item, filePath)
   {
      const html = ManualDocBuilder._convertMDToHTML(filePath);
      const ice = eventbus.triggerSync('tjsdoc:system:publisher:ice:cap:template:get', 'manual.html');

      ice.text('title', item.label);
      ice.load('content', html);

      // convert relative src to base url relative src.
      const $root = cheerio.load(ice.html).root();

      $root.find('img').each((i, el) =>
      {
         const $el = cheerio(el);
         const src = $el.attr('src');

         if (!src) { return; }
         if (src.match(/^http[s]?:/)) { return; }
         if (src.charAt(0) === '/') { return; }

         $el.attr('src', `./manual/${src}`);
      });

      $root.find('a').each((i, el) =>
      {
         const $el = cheerio(el);
         const href = $el.attr('href');

         if (!href) { return; }
         if (href.match(/^http[s]?:/)) { return; }
         if (href.charAt(0) === '/') { return; }
         if (href.charAt(0) === '#') { return; }

         $el.attr('href', `./manual/${href}`);
      });

      return $root.html();
   }

   /**
    * Build manual card style index.
    *
    * @param {EventProxy}           eventbus - An event proxy for the main eventbus.
    *
    * @param {ManualConfigItem[]}   manualConfig - target manual config.
    *
    * @return {IceCap} built index.
    * @private
    */
   static _buildManualCardIndex(eventbus, manualConfig, identifiers)
   {
      const pubConfig = eventbus.triggerSync('tjsdoc:data:publisher:config:get');

      const cards = [];

      for (const manualItem of manualConfig)
      {
         if (manualItem.references)
         {
            // Retrieve `identifiers.html` by a temporary event binding set in IdentifiersDocBuilder.
            const html = eventbus.triggerSync('tjsdoc:publisher:get:html:identifiers');

            const $ = cheerio.load(html);
            const card = $('.content').html();

            //TODO: are variables missing?
            const sectionCount = identifiers.ModuleClass.length + identifiers.ModuleInterface.length +
             identifiers.ModuleFunction.length + identifiers.VirtualTypedef.length + identifiers.VirtualExternal.length;

            cards.push(
            {
               label: 'References',
               link: 'identifiers.html',
               card,
               type: 'reference',
               sectionCount
            });

            continue;
         }

         for (const filePath of manualItem.paths)
         {
            const type = manualItem.label.toLowerCase();
            const fileName = ManualDocBuilder._getManualOutputFileName(manualItem, filePath);
            const html = ManualDocBuilder._buildManual(eventbus, manualItem, filePath);
            const $root = cheerio.load(html).root();
            const h1Count = $root.find('h1').length;
            const sectionCount = $root.find('h1,h2,h3,h4,h5').length;

            $root.find('h1').each((i, el) =>
            {
               const $el = cheerio(el);
               const label = $el.text();
               const link = h1Count === 1 ? fileName : `${fileName}#${$el.attr('id')}`;

               let card = `<h1>${label}</h1>`;

               const nextAll = $el.nextAll();

               for (let cntr = 0; cntr < nextAll.length; cntr++)
               {
                  const next = nextAll.get(cntr);
                  const tagName = next.tagName.toLowerCase();

                  if (tagName === 'h1') { return; }

                  const $next = cheerio(next);

                  card += `<${tagName}>${$next.html()}</${tagName}>`;
               }

               cards.push({ label, link, card, type, sectionCount });
            });
         }
      }

      const ice = eventbus.triggerSync('tjsdoc:system:publisher:ice:cap:template:get', 'manualCardIndex.html');

      ice.loop('cards', cards, (i, card, ice) =>
      {
         ice.text('label-inner', card.label);
         ice.attr('label', 'class', `manual-color manual-color-${card.type}`);

         const sectionCount = Math.min((card.sectionCount / 5) + 1, 5);

         ice.attr('label', 'data-section-count', '■'.repeat(sectionCount));

         ice.attr('link', 'href', card.link);
         ice.load('card', card.card);
      });

      if (pubConfig.manual.index)
      {
         const userIndex = ManualDocBuilder._convertMDToHTML(pubConfig.manual.index);

         ice.load('manualUserIndex', userIndex);
      }
      else
      {
         ice.drop('manualUserIndex', true);
      }

      ice.drop('manualBadge', !pubConfig.manual.coverage);

      return ice;
   }

   /**
    * Build manual index.
    *
    * @param {EventProxy}           eventbus - An event proxy for the main eventbus.
    *
    * @param {ManualConfigItem[]}   manualConfig - target manual config.
    *
    * @return {IceCap} built index.
    * @private
    */
   static _buildManualIndex(eventbus, manualConfig, identifiers)
   {
      const ice = eventbus.triggerSync('tjsdoc:system:publisher:ice:cap:template:get', 'manualIndex.html');
      const _manualConfig = manualConfig.filter((item) => (item.paths && item.paths.length) || item.references);

      ice.loop('manual', _manualConfig, (i, item, ice) =>
      {
         const toc = [];

         if (item.references)
         {
            toc.push({ label: 'Reference', link: 'identifiers.html', indent: 'indent-h1' });

            if (identifiers.ModuleClass.length)
            {
               toc.push(
               {
                  label: 'Class',
                  link: 'identifiers.html#class',
                  indent: 'indent-h2'
               });
            }

            if (identifiers.ModuleInterface.length)
            {
               toc.push(
               {
                  label: 'Interface',
                  link: 'identifiers.html#interface',
                  indent: 'indent-h2'
               });
            }

            if (identifiers.ModuleFunction.length)
            {
               toc.push(
               {
                  label: 'Function',
                  link: 'identifiers.html#function',
                  indent: 'indent-h2'
               });
            }

            if (identifiers.ModuleVariable.length)
            {
               toc.push(
               {
                  label: 'Variable',
                  link: 'identifiers.html#variable',
                  indent: 'indent-h2'
               });
            }

            if (identifiers.VirtualTypedef.length)
            {
               toc.push(
               {
                  label: 'Typedef',
                  link: 'identifiers.html#typedef',
                  indent: 'indent-h2'
               });
            }

            if (identifiers.VirtualExternal.length)
            {
               toc.push(
               {
                  label: 'External',
                  link: 'identifiers.html#external',
                  indent: 'indent-h2'
               });
            }

            //TODO: are variables left out?
            toc[0].sectionCount = identifiers.ModuleClass.length + identifiers.ModuleInterface.length +
             identifiers.ModuleFunction.length + identifiers.VirtualTypedef.length + identifiers.VirtualExternal.length;
         }
         else
         {
            for (const filePath of item.paths)
            {
               const fileName = ManualDocBuilder._getManualOutputFileName(item, filePath);
               const html = ManualDocBuilder._convertMDToHTML(filePath);
               const $root = cheerio.load(html).root();
               const h1Count = $root.find('h1').length;
               const sectionCount = $root.find('h1,h2,h3,h4,h5').length;

               $root.find('h1,h2,h3,h4,h5').each((i, el) =>
               {
                  const $el = cheerio(el);
                  const label = $el.text();
                  const indent = `indent-${el.tagName.toLowerCase()}`;

                  let link = `${fileName}#${$el.attr('id')}`;

                  if (el.tagName.toLowerCase() === 'h1' && h1Count === 1) { link = fileName; }

                  toc.push({ label, link, indent, sectionCount });
               });
            }
         }

         ice.attr('manual', 'data-toc-name', item.label.toLowerCase());

         ice.loop('manualNav', toc, (i, tocItem, ice) =>
         {
            if (tocItem.indent === 'indent-h1')
            {
               ice.attr('manualNav', 'class',
                `${tocItem.indent} manual-color manual-color-${item.label.toLowerCase()}`);

               const sectionCount = Math.min((tocItem.sectionCount / 5) + 1, 5);

               ice.attr('manualNav', 'data-section-count', '■'.repeat(sectionCount));
            }
            else
            {
               ice.attr('manualNav', 'class', tocItem.indent);
            }

            ice.attr('manualNav', 'data-link', tocItem.link.split('#')[0]);
            ice.text('link', tocItem.label);
            ice.attr('link', 'href', tocItem.link);
         });
      });

      return ice;
   }

   /**
    * Get manual file name.
    *
    * @param {ManualConfigItem}  item - target manual config item.
    *
    * @param {string}            filePath - target manual markdown file path.
    *
    * @returns {string} file name.
    * @private
    */
   static _getManualOutputFileName(item, filePath)
   {
      if (item.fileName) { return item.fileName; }

      const fileName = path.parse(filePath).name;

      return `manual/${item.label.toLowerCase()}/${fileName}.html`;
   }

   /**
    * Convert markdown to html. If markdown has only one `h1` and its text is `item.label`, remove the `h1`.
    * because duplication of `h1` in output HTML.
    *
    * @param {string} filePath - target.
    *
    * @returns {string} converted html.
    * @private
    */
   static _convertMDToHTML(filePath)
   {
      const content = fs.readFileSync(filePath).toString();
      const html = markdown(content);
      const $root = cheerio.load(html).root();

      return $root.html();
   }
}

// Module private ---------------------------------------------------------------------------------------------------

/**
 * Stores the cached left-hand navigation.
 * @ignore
 */
let cachedHTMLNav;
