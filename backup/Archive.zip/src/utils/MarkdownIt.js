import hljs             from 'highlight.js';
import path             from 'path';
import Markdown         from 'markdown-it';
import sanitizeHtml     from 'sanitize-html';

/**
 * Provides a TyphonJS plugin support for `markdown-it`.
 */
export default class MarkdownIt
{
   constructor()
   {
      this._md = new Markdown({ breaks: false, linkify: true, highlight: this.highlight.bind(this) });
      this._sanitizeOptions = {};
      this._sanitizeOptionsLocked = false;
      this._lineNumbers = void 0;
   }

   /**
    * Adds all common runtime plugins.
    *
    * @param {PluginEvent} ev - The plugin event.
    */
   onPluginLoad(ev)
   {
      ev.eventbus.on('typhonjs:util:highlight:code', this.highlight, this);
      ev.eventbus.on('typhonjs:util:markdown:plugin:add', this.addPlugin, this);
      ev.eventbus.on('typhonjs:util:markdown:plugins:add:all', this.addAllPlugins, this);
      ev.eventbus.on('typhonjs:util:markdown:render', this.render, this);
      ev.eventbus.on('typhonjs:util:markdown:render:inline', this.renderInline, this);
      ev.eventbus.on('typhonjs:util:markdown:render:rule:add', this.addRenderRule, this);
      ev.eventbus.on('typhonjs:util:markdown:sanitize:options:get', this.getSanitizeOptions, this);
      ev.eventbus.on('typhonjs:util:markdown:sanitize:options:set', this.setSanitizeOptions, this);
   }

   /**
    * Adds a plugin by the given configuration parameters. A plugin `name` is always required. If no other options
    * are provided then the `name` doubles as the NPM module / local file to load. The loading first checks for an
    * existing `instance` to use as the plugin. Then the `target` is chosen as the NPM module / local file to load.
    * By passing in `options` this will be stored and accessible to the plugin during all callbacks.
    *
    * @param {PluginConfig}   pluginConfig - Defines the plugin to load.
    *
    * TODO: hook up plugin options for required modules.
    */
   addPlugin(pluginConfig)
   {
      if (typeof pluginConfig !== 'object') { throw new TypeError(`'pluginConfig' is not an 'object'.`); }

      if (typeof pluginConfig.name !== 'undefined' && typeof pluginConfig.name !== 'string')
      {
         throw new TypeError(`'pluginConfig.name' is not a 'string' for entry: ${JSON.stringify(pluginConfig)}.`);
      }

      if (typeof pluginConfig.options !== 'undefined' && typeof pluginConfig.options !== 'object')
      {
         throw new TypeError(`'pluginConfig.options' is not an 'object' for entry: ${JSON.stringify(pluginConfig)}.`);
      }

      let instance;

      // Use an existing instance of a plugin; a static class is assumed when instance is a function.
      if (typeof pluginConfig.instance === 'object' || typeof pluginConfig.instance === 'function')
      {
         instance = pluginConfig.instance;
      }
      else
      {
         // If a target is defined use it instead of the name.
         const target = pluginConfig.name;

         if (target.match(/^[.\/\\]/))
         {
            instance = require(path.resolve(target)); // eslint-disable global-require
         }
         else
         {
            instance = require(target);               // eslint-disable global-require
         }
      }

      this._md.use(instance);
   }

   addAllPlugins()
   {

   }

   addRenderRule({ name, rule } = {})
   {
      if (typeof name !== 'string') { throw new TypeError(`'name' is not a 'string'.`); }
      if (typeof rule !== 'function') { throw new TypeError(`'rule' is not a 'function'.`); }

      this._md.renderer.rules[name] = rule;
   }

   getSanitizeOptions()
   {
      return JSON.stringify(JSON.parse(this._sanitizeOptions));
   }

   highlight(code, language, lineNumbers = void 0)
   {
      const lineType = lineNumbers || this._lineNumbers;

      const includeLines = lineType === 'list' || lineType === 'table';

      const extraPreClasses = [];

      if (language && hljs.getLanguage(language))
      {
         try
         {
            let highlightedCode = hljs.highlight(language, code, true).value;

            if (includeLines)
            {
               extraPreClasses.push('line-number');
               highlightedCode = this.lineNumbers(highlightedCode, lineType);
            }

            return `<pre class="hljs${extraPreClasses.length ? 
             ` ${extraPreClasses.join(' ')}` : ''}"><code class="language-${language}">${highlightedCode}</code></pre>`;
         }
         catch (__) { /* nop */ }
      }

      let escapedCode = this._md.utils.escapeHtml(code);

      if (includeLines)
      {
         escapedCode = this.lineNumbers(escapedCode, lineType);
         extraPreClasses.push('line-number');
      }

      return `<pre class="hljs"><code>${escapedCode}</code></pre>`;
   }

   lineNumbers(code, lineType)
   {
      if (typeof code !== 'string') { throw new TypeError(`'code' is not a 'string'.`); }
      if (typeof lineType !== 'string') { throw new TypeError(`'lineType' is not a 'string'.`); }

      const lines = code.split(/\r\n|\r|\n/g);

      let result = '';

      switch (lineType)
      {
         case 'list':
            result = '<ol class="linenums">\n';

            for (let cntr = 0; cntr < lines.length; cntr++)
            {
               result += `<li class="L0" id="lineNumber${cntr + 1}">${lines[cntr]}</li>\n`;
            }

            result += '</ol>';
            break;

         case 'table':
            result = '<table class="linenums">\n';

            for (let cntr = 0; cntr < lines.length; cntr++)
            {
               result += `<tr><td class="hljs-ln-numbers"><div class="hljs-ln-line {2}" {3}="{5}"></div></td><td class="{4}"><div class="{1}">${lines[cntr].length > 0 ? lines[cntr] : ' '}</div></td></tr>`;

                  // .format(
                  // 0 NUMBERS_BLOCK_NAME,
                  // 1 LINE_NAME,
                  // 2 NUMBER_LINE_NAME,
                  // 3 DATA_ATTR_NAME,
                  // 4 CODE_BLOCK_NAME,
                  // 5 i + 1,
                  // 6 lines[i].length > 0 ? lines[i] : ' ');
            }
            break;

/*
 var TABLE_NAME = 'hljs-ln',
 LINE_NAME = 'hljs-ln-line',
 CODE_BLOCK_NAME = 'hljs-ln-code',
 NUMBERS_BLOCK_NAME = 'hljs-ln-numbers',
 NUMBER_LINE_NAME = 'hljs-ln-n',
 DATA_ATTR_NAME = 'data-line-number';
 */
      }

      return result;
   }

   /**
    * Convert markdown text to html.
    *
    * @param {string} markdown - markdown text.
    *
    * @param {boolean} [breaks=false] If true, break line. FYI gfm has no breaks.
    *
    * @param {boolean} [sanitize=true] If true, sanitize HTML output.
    *
    * @param {boolean} [lineNumbers=undefined] If 'list' or 'table' all highlighted code will include line numbers via
    *                                          an enclosed in an ordered list or table.
    *
    * @return {string} HTML.
    */
   render({ markdown = '', breaks = false, sanitize = true, lineNumbers = void 0 } = {})
   {
      this._md.set({ breaks });
      this._lineNumbers = lineNumbers;

      const html = this._md.render(markdown);

      const result = sanitize ? sanitizeHtml(html, this._sanitizeOptions) : html;

      this._lineNumbers = void 0;

      return result;
   }

   /**
    * Convert markdown text to html.
    *
    * @param {string} markdown - markdown text.
    *
    * @param {boolean} [breaks=false] If true, break line. FYI gfm has no breaks.
    *
    * @param {boolean} [sanitize=true] If true, sanitize HTML output.
    *
    * @param {boolean} [lineNumbers=undefined] If 'list' or 'table' all highlighted code will include line numbers via
    *                                          an enclosed in an ordered list or table.
    *
    * @return {string} HTML.
    */
   renderInline({ markdown = '', breaks = false, sanitize = true, lineNumbers = void 0 } = {})
   {
      this._md.set({ breaks });
      this._lineNumbers = lineNumbers;

      const html = this._md.renderInline(markdown);

      const result = sanitize ? sanitizeHtml(html, this._sanitizeOptions) : html;

      this._lineNumbers = void 0;

      return result;
   }

   setSanitizeOptions(options, lockOptions = false)
   {
      if (this._sanitizeOptionsLocked) { return; }

      if (typeof options !== 'object') { throw new TypeError(`'options' is not an 'object'`); }
      if (typeof lockOptions !== 'boolean') { throw new TypeError(`'lockOptions' is not a 'boolean'`); }

      this._sanitizeOptions = options;
      this._sanitizeOptionsLocked = lockOptions;
   }
}
