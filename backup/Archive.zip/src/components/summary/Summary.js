import PublishUtil   from '../../PublishUtil.js';

import shorten       from '../../utils/shorten.js';

/**
 * @param {PluginEvent} ev - The plugin event.
 */
export function onPluginLoad(ev)
{
   ev.eventbus.on('tjsdoc:system:publisher:doc:html:summary:get', Summary.getDocHTMLSummary, Summary);
   ev.eventbus.on('tjsdoc:system:publisher:docs:ice:cap:summary:get', Summary.getDocsIceCapSummary, Summary);
}

/**
 *
 */
class Summary
{
   /**
    * Builds summary output HTML from parent doc.
    *
    * @param {AccessDocs}  accessDocs - An object from DocDB with the following access keys `Public`, `Private`,
    *                                   `Protected` indexing an associated DocObject[].
    *
    * @param {string}      [title] - Summary title.
    *
    * @returns {string} HTML of summary.
    */
   static getDocHTMLSummary(accessDocs, title = '')
   {
      let html = '';

      for (const accessType in accessDocs)
      {
         const docs = accessDocs[accessType];

         if (!docs.length) { continue; }

         let prefix = '';

         if (docs[0].static) { prefix = 'Static '; }

         const _title = `${prefix}${accessType} ${title}`;
         const result = this.getDocsIceCapSummary(docs, _title);

         if (result) { html += result.html; }
      }

      return html;
   }

   /**
    * Builds summary output HTML from multiple docs.
    *
    * @param {DocObject[]} docs - Target docs.
    *
    * @param {string}      title - Summary title.
    *
    * @param {boolean}     [innerLink=false] - If true, link in summary is inner link.
    *
    * @return {IceCap} Summary output.
    */
   static getDocsIceCapSummary(docs, title, innerLink = false)
   {
      if (docs.length === 0) { return null; }

      const ice = PublishUtil.getIceCapTemplate({ dirName: __dirname, filePath: 'html/summary.html' });

      ice.text('title', title);

      ice.loop('target', docs, (i, doc, ice) =>
      {
         ice.text('generator', doc.generator ? '*' : '');
         ice.text('async', doc.async ? 'async' : '');
         ice.text('abstract', doc.abstract ? 'abstract' : '');
         ice.text('access', doc.access);
         ice.load('signature', PublishUtil.getDocHTMLSignature(doc));
         ice.load('description', shorten(doc, true));
         ice.load('name', PublishUtil.getDocHTMLLink(doc.longname, null, innerLink, doc.kind, doc.qualifier));

         switch (doc.kind)
         {
            case 'ClassMethod':
               if (doc.accessor)
               {
                  ice.text('kind', doc.qualifier);
               }
               else
               {
                  ice.drop('kind');
               }
               break;

            default:
               ice.drop('kind');
               break;
         }

         switch (doc.kind)
         {
            case 'ClassProperty':
            case 'ClassMember':
            case 'ClassMethod':
               ice.text('static', doc.static ? 'static' : '');
               break;

            default:
               ice.drop('static');
               break;
         }

         ice.text('since', doc.since);
         ice.load('deprecated', PublishUtil.getDocHTMLDeprecated(doc));
         ice.load('experimental', PublishUtil.getDocHTMLExperimental(doc));
         ice.text('version', doc.version);
      });

      return ice;
   }
}
