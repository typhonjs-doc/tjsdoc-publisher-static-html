import fs from 'fs';

/**
 * File output builder.
 *
 * Outputs source code for each file.
 */
export default class FileDocBuilder
{
   /**
    * Executes writing source code for each file.
    *
    * @param {EventProxy}  eventbus - An event proxy for the main eventbus.
    */
   static exec(eventbus)
   {
      const config = eventbus.triggerSync('tjsdoc:data:config:get');
      const ice = eventbus.triggerSync('tjsdoc:system:publisher:ice:cap:layout:get');
      const docs = eventbus.triggerSync('tjsdoc:data:docdb:find', { kind: 'ModuleFile' });

      for (const doc of docs)
      {
         const fileName = eventbus.triggerSync('tjsdoc:system:publisher:doc:file:name:get', doc);
         const baseUrl = eventbus.triggerSync('tjsdoc:system:publisher:file:url:base:get', fileName);
         const title = eventbus.triggerSync('tjsdoc:system:publisher:title:get', doc);

         ice.load('content', FileDocBuilder._buildFileDoc(config, doc, eventbus), 'write');
         ice.attr('baseUrl', 'href', baseUrl, 'write');
         ice.text('title', title, 'write');

         eventbus.trigger('tjsdoc:system:file:write', ice.html, fileName);
      }
   }

   /**
    * Build file output HTML.
    *
    * @param {TJSDocConfig}   config - The target project TJSDocConfig instance.
    *
    * @param {DocObject}      doc - target file doc object.
    *
    * @param {EventProxy}     eventbus - An event proxy for the main eventbus.
    *
    * @returns {string} HTML of file page.
    * @private
    */
   static _buildFileDoc(config, doc, eventbus)
   {
      let fileContent;

      if (config.includeSource) { fileContent = fs.readFileSync(doc.filePath, { encode: 'utf8' }).toString(); }

      const ice = eventbus.triggerSync('tjsdoc:system:publisher:ice:cap:template:get', 'file.html');

      ice.text('title', doc.longname);
      ice.text('content', fileContent);
      ice.drop('emptySourceCode', !!fileContent);

      return ice.html;
   }
}
