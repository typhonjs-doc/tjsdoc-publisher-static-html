import path          from 'path';

import PublishUtil   from '../../../../PublishUtil.js';

/**
 * Handles adding main menu link for any repository.
 *
 * @param {PluginEvent} ev - The plugin event.
 */
export function onPluginLoad(ev)
{
   ev.eventbus.on('tjsdoc:system:publisher:ice:cap:nav:get', OldNav.getIceCapNav, OldNav);
}

/**
 * Resets any cached version of the navigation.
 */
export function onHandlePostPublish()
{
   OldNav.cachedIceNav = void 0;
}

/**
 *
 */
class OldNav
{
   static cachedIceNav = void 0;

   /**
    * Builds common navigation output.
    *
    * @return {IceCap} Navigation output.
    */
   static getIceCapNav()
   {
      // Return a cached version of the left-hand navigation if available.
      if (this.cachedIceNav) { return this.cachedIceNav; }

      // Otherwise build the cached left-hand navigation.

      const ice = PublishUtil.getIceCapTemplate({ dirName: __dirname, filePath: 'nav.html' });

      const kind =
      [
         'ModuleAssignment',
         'ModuleClass',
         'ModuleFunction',
         'ModuleVariable',
         'VirtualExternal',
         'VirtualTypedef'
      ];

      const allDocs = PublishUtil.getActiveDocDB().find({ kind }).filter((v) => !v.builtinVirtual);

      const sortData =
      {
         ModuleClass: { order: 0, text: 'C' },
         ModuleInterface: { order: 1, text: 'I' },
         ModuleFunction: { order: 2, text: 'F' },
         ModuleAssignment: { order: 3, text: 'V' },
         ModuleVariable: { order: 3, text: 'V' },
         VirtualTypedef: { order: 4, text: 'T' },
         VirtualExternal: { order: 5, text: 'E' }
      };

      allDocs.sort((a, b) =>
      {
         const filePathA = a.longname.split('~')[0];
         const filePathB = b.longname.split('~')[0];
         const dirPathA = path.dirname(filePathA);
         const dirPathB = path.dirname(filePathB);
         const kindA = a.interface ? 'ModuleInterface' : a.kind;
         const kindB = b.interface ? 'ModuleInterface' : b.kind;

         if (dirPathA === dirPathB)
         {
            const kindAOrder = sortData[kindA].order;
            const kindBOrder = sortData[kindB].order;

            if (kindAOrder === kindBOrder)
            {
               return a.longname > b.longname ? 1 : -1;
            }
            else
            {
               // return kindOrder[kindA] > kindOrder[kindB] ? 1 : -1;
               return kindAOrder > kindBOrder ? 1 : -1;
            }
         }
         else
         {
            return dirPathA > dirPathB ? 1 : -1;
         }
      });

      let lastDirPath = '.';

      ice.loop('doc', allDocs, (i, doc, ice) =>
      {
         const filePath = doc.longname.split('~')[0];
         const dirPath = path.dirname(filePath);
         const kind = doc.interface ? 'ModuleInterface' : doc.kind;
         const kindText = sortData[kind].text;
         const kindClass = `kind-${kind}`;

         ice.load('name', PublishUtil.getDocHTMLLink(doc.longname));
         ice.load('kind', kindText);
         ice.attr('kind', 'class', kindClass);
         ice.text('dirPath', dirPath);
         ice.drop('dirPath', lastDirPath === dirPath);

         lastDirPath = dirPath;
      });

      // Save to cached version.
      this.cachedIceNav = ice;

      return ice;
   }
}
