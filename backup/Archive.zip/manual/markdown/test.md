# Github Markdown Test :fa-flag:

The following attempts to capture most Github Markdown functionality.

| Left-aligned | Center-aligned | Right-aligned | Extra #1 | Extra #2 | Extra #3 | Extra #4 |
| :---         |     :---:      |          ---: | :---         | :---         | :---         | :---         |
| git status   | `git status`     | **git status**    | some data | some data | some data | some data |
| git diff     | `git diff`       | **git diff**      | some data | some data | some data | some data |

```
function test() {
  const value = 1;
  console.log("notice the blank line before this function?");
}
```

```javascript
function test() {
  console.log("notice the blank line before this function?");
}
```

```javascript
function length_120_characters() {
ssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssss
}
```

# The largest heading
## The second largest heading which is extra long
### The third largest heading
#### The fourth largest heading
##### The fifth largest heading
###### The smallest heading


**This is bold text**

*This text is italicized*

~~This was mistaken text~~

**This text is _extremely_ important**

> Quoting text

Quoting code: Use `git status` to list all new or modified files.

Link: This site was built using [GitHub Pages](https://pages.github.com/).

Visit https://github.com

List:
- George Washington
- John Adams
- Thomas Jefferson

Numbered List:
1. George Washington
2. John Adams
3. Thomas Jefferson

Mixed List:
1. Make my changes
    1. Fix bug
    2. Improve formatting
        - Make the headings bigger
2. Push my commits to GitHub
3. Open a pull request
    * Describe my changes
    * Mention all the members of my team
        * Ask for feedback

Task List:
- [x] Finish my changes
- [ ] Push my commits to GitHub
- [ ] Open a pull request
