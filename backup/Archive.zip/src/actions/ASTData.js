/**
 * Executes writing AST output.
 */
export function onHandlePublish(ev)
{
   if (ev.data.incremental)
   {
      if (ev.data.fileType === 'source') { ASTDoc.exec(ev.data); }
   }
   else
   {
      ASTDoc.exec(ev.data);
   }
}

class ASTDoc
{
   /**
    * Executes writing AST output.
    */
   static exec({ docDB, eventbus, filePath, mainConfig, silent } = {})
   {
      if (mainConfig.outputASTData)
      {
         // Note the compression format extension will automatically be added.
         if (mainConfig.compressData) { eventbus.trigger('tjsdoc:system:file:archive:create', 'ast', true, silent); }

         // Write doc data as JSON to 'docData.json'
         const fileDocs = docDB.findSorted('__docId__ asec', filePath ? { kind: 'ModuleFile', filePath } :
          { kind: 'ModuleFile' });

         for (const doc of fileDocs)
         {
            const astJSON = mainConfig.compactData ? JSON.stringify(doc.node) : JSON.stringify(doc.node, null, 3);
            const filePath = `ast/${doc.filePath}.json`;

            eventbus.trigger('tjsdoc:system:file:write', astJSON, filePath, silent);
         }

         if (mainConfig.compressData) { eventbus.trigger('typhonjs:util:file:archive:finalize'); }
      }
   }
}
