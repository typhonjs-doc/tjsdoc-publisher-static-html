import ConfigResolver      from 'typhonjs-config-resolver';

import * as Builder        from './builder/';
import ConfigData          from './ConfigData.js';
import PublishDocResolver  from './PublishDocResolver.js';
import PublisherEvents     from './PublisherEvents.js';

export class Publisher
{
   onPluginLoad(ev)
   {
      const eventbus = ev.eventbus;

      this._pluginEventProxy = eventbus;

      const config = new ConfigResolver(ConfigData.createResolverData()).resolve(ev.pluginOptions, 'publisherOptions');

      // Deep freeze the publisher config.
      eventbus.trigger('typhonjs:object:util:deep:freeze', config);

      eventbus.on('tjsdoc:data:publisher:config:get', () => config);

      eventbus.on('tjsdoc:system:publisher:publish', this.publish, this);

      // Add the IceCap plugin for DOM / template generation.
      eventbus.trigger('plugins:add', { name: 'typhonjs-ice-cap', instance: require('typhonjs-ice-cap') });

      // Set IceCap debug mode if `config.debug` is true. Helps find any errors in template generation.
      eventbus.trigger('typhonjs:ice:cap:debug:set', config.debug);

      // Instances are being loaded into the plugin manager so auto log filtering needs an explicit filter.
      eventbus.trigger('log:filter:add',
      {
         type: 'inclusive',
         name: 'tjsdoc-publisher-static-html',
         filterString: '(tjsdoc-publisher-static-html\/dist|tjsdoc-publisher-static-html\/src)'
      });
   }

   /**
    * Publish documentation as static HTML + resources.
    *
    * An eventbus proxy must be passed in so that the default publish action can be overridden for instance when running
    * tests. This publisher registers several event bindings on the eventbus; please see {@link PublisherEvents}.
    */
   publish()
   {
      // Create an event proxy for local event bindings created which need to be removed at the end of publishing.
      const eventProxy = this._pluginEventProxy.createEventProxy();

      try
      {
         /**
          * @type TJSDocConfig
          */
         const config = eventProxy.triggerSync('tjsdoc:data:config:get');

         // Note the compression format extension will automatically be added.
         if (config.compressOutput) { eventProxy.trigger('tjsdoc:system:file:archive:create', 'docs'); }

         // Optionally output raw document / tag data.
         if (config.outputDocData)
         {
            // Write doc data as JSON to 'docData.json'
            const docData = eventProxy.triggerSync('tjsdoc:data:docdb:find:sorted', '__docId__ asec');

            // Filter out AST node and TaffyDB private data.
            const filterNode = (key, value) => key === 'node' || key === '___id' || key === '___s' ? void 0 : value;

            const docDataJSON = config.compactData ? JSON.stringify(docData, filterNode) :
             JSON.stringify(docData, filterNode, 3);

            // Note the compression format extension will automatically be added.
            if (config.compressData) { eventProxy.trigger('tjsdoc:system:file:archive:create', 'docData'); }

            eventProxy.trigger('tjsdoc:system:file:write', docDataJSON, 'docData.json');

            if (config.compressData) { eventProxy.trigger('typhonjs:util:file:archive:finalize'); }
         }

         // Registers several publishing related event bindings for outputting and structuring static HTML
         // documentation.
         PublisherEvents.register(eventProxy);

         // Processes and resolves any publisher specific DocDB data.
         PublishDocResolver.resolve(eventProxy);

         // Optional output.
         if (config.docCoverage) { Builder.DocCoverage.exec(eventProxy); }
         if (config.outputASTData) { Builder.ASTDoc.exec(eventProxy); }

         Builder.ClassDoc.exec(eventProxy);
         Builder.FileDoc.exec(eventProxy);
         Builder.IdentifiersDoc.exec(eventProxy);
         Builder.IndexDoc.exec(eventProxy);
         Builder.ManualDoc.exec(eventProxy);
         Builder.SearchIndex.exec(eventProxy);
         Builder.SingleDoc.exec(eventProxy);
         Builder.SourceDoc.exec(eventProxy);
         Builder.StaticFile.exec(eventProxy);

         const packageObj = eventProxy.triggerSync('tjsdoc:data:package:object:get');

         // Copy package.json if it is defined and `copyPackage` TJSDoc config parameter is true.
         if (packageObj && config.copyPackage)
         {
            eventProxy.trigger('tjsdoc:system:file:write', JSON.stringify(packageObj, null, 2), 'package.json');
         }

         // If test source is defined then build / output test coverage.
         if (config.test)
         {
            Builder.TestDoc.exec(eventProxy);
            Builder.TestFileDoc.exec(eventProxy);
         }

         if (config.compressOutput) { eventProxy.trigger('typhonjs:util:file:archive:finalize'); }

         // If documentation coverage is enabled then output a text description of results.
         if (config.docCoverage)
         {
            const coverage = eventProxy.triggerSync('tjsdoc:publisher:get:doc:coverage');

            eventProxy.trigger('log:info:raw', '================================================');
            eventProxy.trigger('log:info:raw', `${coverage.ansiColor}Documentation coverage: ${coverage.coverage} (${
             coverage.actualCount}/${coverage.expectCount})[0m`);
            eventProxy.trigger('log:info:raw', '================================================');
         }
      }
      finally
      {
         // // Remove the IceCap plugin for DOM / template generation.
         // eventProxy.trigger('plugins:remove', 'typhonjs-ice-cap');

         eventProxy.destroy();
      }
   }
}


/**
 * Wires up publisher to plugin eventbus.
 *
 * @param {PluginEvent} ev - The plugin event.
 *
 * @ignore
 */
export function onPluginLoad(ev)
{
   new Publisher().onPluginLoad(ev);
}
