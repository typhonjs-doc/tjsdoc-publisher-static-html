import escape        from 'escape-html';
import fs            from 'fs';
import path          from 'path';

import parseExample  from './utils/parseExample.js';
import shorten       from './utils/shorten.js';

/**
 * Defines several event bindings which aid in the publishing process.
 *
 * 'tjsdoc:system:publisher:doc:file:name:get' -
 * 'tjsdoc:system:publisher:doc:html:decorator:get' -
 * 'tjsdoc:system:publisher:doc:html:deprecated:get' -
 * 'tjsdoc:system:publisher:doc:html:detail:get' -
 * 'tjsdoc:system:publisher:doc:html:experimental:get' -
 * 'tjsdoc:system:publisher:doc:html:file:link:get' -
 * 'tjsdoc:system:publisher:doc:html:link:get' -
 * 'tjsdoc:system:publisher:doc:html:link:type:get' -
 * 'tjsdoc:system:publisher:doc:html:signature:get' -
 * 'tjsdoc:system:publisher:doc:html:summary:get' -
 * 'tjsdoc:system:publisher:doc:override:method:get' -
 * 'tjsdoc:system:publisher:doc:override:method:description:get' -
 * 'tjsdoc:system:publisher:doc:url:get' -
 * 'tjsdoc:system:publisher:docs:html:link:get' -
 * 'tjsdoc:system:publisher:docs:ice:cap:detail:get' -
 * 'tjsdoc:system:publisher:docs:ice:cap:summary:get' -
 * 'tjsdoc:system:publisher:file:url:base:get' -
 * 'tjsdoc:system:publisher:ice:cap:layout:get' -
 * 'tjsdoc:system:publisher:ice:cap:nav:get' -
 * 'tjsdoc:system:publisher:ice:cap:properties:get' -
 * 'tjsdoc:system:publisher:ice:cap:template:get' - Loads a template file into an ice-cap instance.
 * 'tjsdoc:system:publisher:reset' -
 * 'tjsdoc:system:publisher:template:get' - Loads a template file.
 * 'tjsdoc:system:publisher:title:get' -
 */
export default class PublisherUtil
{
   /**
    * Registers all event bindings.
    *
    * @param {PluginEvent} ev - The plugin event.
    */
   static onPluginLoad(ev)
   {
      this._eventbus = ev.eventbus;

      // Register all events on the eventbus.
      this._eventbus.on('tjsdoc:data:publisher:docdb:get', this.getActiveDocDB, this);

      this._eventbus.on('tjsdoc:system:publisher:doc:file:name:get', this.getDocFileName, this);
      this._eventbus.on('tjsdoc:system:publisher:doc:html:decorator:get', this.getDocHTMLDecorator, this);
      this._eventbus.on('tjsdoc:system:publisher:doc:html:deprecated:get', this.getDocHTMLDeprecated, this);
      this._eventbus.on('tjsdoc:system:publisher:doc:html:detail:get', this.getDocHTMLDetail, this);
      this._eventbus.on('tjsdoc:system:publisher:doc:html:experimental:get', this.getDocHTMLExperimental, this);
      this._eventbus.on('tjsdoc:system:publisher:doc:html:file:link:get', this.getDocHTMLFileLink, this);
      this._eventbus.on('tjsdoc:system:publisher:doc:html:link:get', this.getDocHTMLLink, this);
      this._eventbus.on('tjsdoc:system:publisher:doc:html:link:type:get', this.getDocHTMLLinkType, this);
      this._eventbus.on('tjsdoc:system:publisher:doc:html:signature:get', this.getDocHTMLSignature, this);
      this._eventbus.on('tjsdoc:system:publisher:doc:html:summary:get', this.getDocHTMLSummary, this);
      this._eventbus.on('tjsdoc:system:publisher:doc:override:method:get', this.getDocOverrideMethod, this);
      this._eventbus.on('tjsdoc:system:publisher:doc:override:method:description:get',
       this.getDocOverrideMethodDescription, this);
      this._eventbus.on('tjsdoc:system:publisher:doc:url:get', this.getDocURL, this);
      this._eventbus.on('tjsdoc:system:publisher:docs:html:link:get', this.getDocsHTMLLink, this);
      this._eventbus.on('tjsdoc:system:publisher:docs:ice:cap:detail:get', this.getDocsIceCapDetail, this);
      this._eventbus.on('tjsdoc:system:publisher:docs:ice:cap:summary:get', this.getDocsIceCapSummary, this);
      this._eventbus.on('tjsdoc:system:publisher:file:url:base:get', this.getFileURLBase, this);
      this._eventbus.on('tjsdoc:system:publisher:ice:cap:layout:get', this.getIceCapLayout, this);
      this._eventbus.on('tjsdoc:system:publisher:ice:cap:properties:get', this.getIceCapProperties, this);
      this._eventbus.on('tjsdoc:system:publisher:ice:cap:template:get', this.getIceCapTemplate, this);
      this._eventbus.on('tjsdoc:system:publisher:reset', this.reset, this);
      this._eventbus.on('tjsdoc:system:publisher:template:get', this.getTemplate, this);
      this._eventbus.on('tjsdoc:system:publisher:title:get', this.getTitle, this);
   }

   /**
    * Stores the main TJSDoc config, main DocDB, and package data.
    *
    * @param {PluginEvent} ev - The plugin event.
    */
   static onPreGenerate(ev)
   {
      /**
       * The main DocDB.
       * @type {DocDB}
       * @private
       */
      this._mainDocDB = this._docDB = ev.data.docDB;

      /**
       * The TJSDoc config.
       * @type {TJSDocConfig}
       * @private
       */
      this._mainConfig = ev.data.mainConfig;

      /**
       * The formatted target project `package.json` object.
       */
      this._packageInfo = ev.data.packageInfo;

      /**
       * The target project `package.json` object.
       */
      this._packageObj = ev.data.packageObj;

      /**
       * The publisher config.
       */
      this._pubConfig = ev.data.pubConfig;
   }

   /**
    * Returns the actively associated DocDB being published. By default this should always be the main DocDB.
    *
    * @returns {DocDB}
    */
   static getActiveDocDB()
   {
      return this._docDB;
   }

   /**
    * Get file name for output HTML page from a doc object.
    *
    * @param {DocObject} doc - Target doc object.
    *
    * @returns {string} file name.
    */
   static getDocFileName(doc)
   {
      let longname = doc.longname;

      // Replace any leading relative path `.` with `,` so that the generated doc files are not placed outside of
      // the `config.destination` path, but retain a general indication of where the source files are located.
      if (longname)
      {
         // TODO: Verify on Windows
         longname = longname.replace(/^(?:\.\.\/)+/, (match) => match.replace(/(\.\.)+/g, ',,'));
      }

      switch (doc.kind)
      {
         case 'ModuleAssignment':
         case 'ModuleVariable':
            return 'variable/index.html';

         case 'ModuleFunction':
            return 'function/index.html';

         case 'ClassMember':
         case 'ClassMethod':
         case 'ClassProperty':
         {
            const parentDoc = this._docDB.find({ longname: doc.memberof })[0];

            return this.getDocFileName(parentDoc);
         }

         case 'VirtualExternal':
            return 'external/index.html';

         case 'VirtualTypedef':
            return 'typedef/index.html';

         case 'ModuleClass':
            return `class/${longname}.html`;

         case 'ModuleFile':
            return `file/${longname}.html`;

         case 'ModuleTestFile':
            return `test-file/${longname}.html`;

         case 'Test':
            return 'test.html';

         default:
            throw new Error('DocBuilder: can not resolve file name.');
      }
   }

   /**
    * Builds decorator description.
    *
    * @param {DocObject} doc - Target doc object.
    *
    * @returns {string} description. if doc does not override ancestor method, returns empty.
    */
   static getDocHTMLDecorator(doc)
   {
      if (!doc.decorators) { return ''; }

      const links = [];

      for (const decorator of doc.decorators)
      {
         const link = this.getDocHTMLLink(decorator.name, decorator.name);

         links.push(decorator.arguments ? `<li>${link}${decorator.arguments}</li>` : `<li>${link}</li>`);
      }

      if (!links.length) { return ''; }

      return `<ul>${links.join('\n')}</ul>`;
   }

   /**
    * Builds deprecated HTML.
    *
    * @param {DocObject} doc - Target doc object.
    *
    * @returns {string} If doc is not deprecated, returns empty.
    */
   static getDocHTMLDeprecated(doc)
   {
      if (doc.deprecated)
      {
         let deprecated = 'Deprecated';

         if (typeof doc.deprecated === 'string') { deprecated += `: ${doc.deprecated}`; }

         return deprecated;
      }
      else
      {
         return '';
      }
   }

   /**
    * Builds detail output HTML by parent doc.
    *
    * @param {AccessDocs}  accessDocs - An object from DocDB with the following access keys `Public`, `Private`,
    *                                   `Protected` indexing an associated DocObject[].
    *
    * @param {string}      [title] - Detail title.
    *
    * @returns {string} HTML of detail.
    */
   static getDocHTMLDetail(accessDocs, title = '')
   {
      let html = '';

      for (const accessType in accessDocs)
      {
         const docs = accessDocs[accessType];

         if (!docs.length) { continue; }

         let prefix = '';

         if (docs[0].static) { prefix = 'Static '; }

         const _title = `${prefix}${accessType} ${title}`;
         const result = this.getDocsIceCapDetail(docs, _title);

         if (result) { html += result.html; }
      }

      return html;
   }

   /**
    * Builds experimental HTML.
    *
    * @param {DocObject} doc - Target doc object.
    *
    * @returns {string} If doc object is not experimental, returns empty.
    */
   static getDocHTMLExperimental(doc)
   {
      if (doc.experimental)
      {
         let experimental = 'Experimental';

         if (typeof doc.experimental === 'string') { experimental += `: ${doc.experimental}`; }

         return experimental;
      }
      else
      {
         return '';
      }
   }

   /**
    * Builds HTML link to file page.
    *
    * @param {DocObject}   doc - target doc object.
    *
    * @param {string|null} [text] - link text.
    *
    * @returns {string} HTML of link.
    */
   static getDocHTMLFileLink(doc, text)
   {
      if (!doc) { return ''; }

      let fileDoc;

      if (doc.kind === 'ModuleFile' || doc.kind === 'ModuleTestFile')
      {
         fileDoc = doc;
      }
      else
      {
         const filePath = doc.longname.split('~')[0];

         fileDoc = this._docDB.find({ kind: ['ModuleFile', 'ModuleTestFile'], longname: filePath })[0];
      }

      if (!fileDoc) { return ''; }

      if (!text) { text = fileDoc.name; }

      if (doc.kind === 'ModuleFile' || doc.kind === 'ModuleTestFile')
      {
         return `<span><a href="${this.getDocURL(fileDoc)}">${text}</a></span>`;
      }
      else
      {
         return `<span><a href="${this.getDocURL(fileDoc)}#lineNumber${doc.lineNumber}">${text}</a></span>`;
      }
   }

   /**
    * build HTML link to identifier.
    *
    * @param {string}   longname - link to
    *
    * @param {string}   [text] - link text. default is name property of doc object.
    *
    * @param {boolean}  [inner=false] - if true, use inner link.
    *
    * @param {string}   [kind] - specify target kind property.
    *
    * @param {string}   [qualifier] - specify target qualifier property.
    *
    * @returns {string} HTML of link.
    */
   static getDocHTMLLink(longname, text = void 0, inner = false, kind = void 0, qualifier = void 0)
   {
      if (!longname) { return ''; }

      if (typeof longname !== 'string') { throw new Error(JSON.stringify(longname)); }

      const doc = this._docDB.findByName(longname, kind, qualifier)[0];

      if (!doc)
      {
         // If longname is HTML tag do not escape.
         return longname.startsWith('<') ? `<span>${longname}</span>` : `<span>${escape(text || longname)}</span>`;
      }

      if (doc.kind === 'VirtualExternal')
      {
         text = doc.name;

         return `<span><a href="${doc.externalLink}">${text}</a></span>`;
      }
      else
      {
         text = escape(text || doc.name);

         const url = this.getDocURL(doc, inner);

         return url ? `<span><a href="${url}">${text}</a></span>` : `<span>${text}</span>`;
      }
   }

   /**
    * Get HTML link of type.
    *
    * @param {string} typeName - type name(e.g. ``number[]``, ``Map<number, string>``)
    *
    * @returns {string} HTML of link.
    * @todo re-implement with parser combinator.
    */
   static getDocHTMLLinkType(typeName)
   {
      // e.g. number[]
      let matched = typeName.match(/^(.*?)\[\]$/);

      if (matched)
      {
         typeName = matched[1];

         return `<span>${this.getDocHTMLLink(typeName, typeName)}<span>[]</span></span>`;
      }

      // e.g. function(a: number, b: string): boolean
      matched = typeName.match(/function *\((.*?)\)(.*)/);

      if (matched)
      {
         const functionLink = this.getDocHTMLLink('function');

         if (!matched[1] && !matched[2]) { return `<span>${functionLink}<span>()</span></span>`; }

         let innerTypes = [];

         if (matched[1])
         {
            // bad hack: Map.<string, boolean> => Map.<string\Z boolean>
            // bad hack: {a: string, b: boolean} => {a\Y string\Z b\Y boolean}
            const inner = matched[1]
             .replace(/<.*?>/g, (a) => a.replace(/,/g, '\\Z'))
              .replace(/{.*?}/g, (a) => a.replace(/,/g, '\\Z').replace(/:/g, '\\Y'));

            innerTypes = inner.split(',').map((v) =>
            {
               const tmp = v.split(':').map((v) => v.trim());

               if (tmp.length !== 2)
               {
                  throw new SyntaxError(`Invalid function type annotation: \`${matched[0]}\``);
               }

               const paramName = tmp[0];
               const typeName = tmp[1].replace(/\\Z/g, ',').replace(/\\Y/g, ':');

               return `${paramName}: ${this.getDocHTMLLinkType(typeName)}`;
            });
         }

         let returnType = '';

         if (matched[2])
         {
            const type = matched[2].split(':')[1];

            if (type) { returnType = `: ${this.getDocHTMLLinkType(type.trim())}`; }
         }

         return `<span>${functionLink}<span>(${innerTypes.join(', ')})</span>${returnType}</span>`;
      }

      // e.g. {a: number, b: string}
      matched = typeName.match(/^\{(.*?)\}$/);

      if (matched)
      {
         if (!matched[1]) { return '{}'; }

         // bad hack: Map.<string, boolean> => Map.<string\Z boolean>
         // bad hack: {a: string, b: boolean} => {a\Y string\Z b\Y boolean}
         const inner = matched[1]
          .replace(/<.*?>/g, (a) => a.replace(/,/g, '\\Z'))
           .replace(/{.*?}/g, (a) => a.replace(/,/g, '\\Z').replace(/:/g, '\\Y'));

         const innerTypes = inner.split(',').map((v) =>
         {
            const tmp = v.split(':').map((v) => v.trim());
            const paramName = tmp[0];

            let typeName = tmp[1].replace(/\\Z/g, ',').replace(/\\Y/g, ':');

            if (typeName.includes('|'))
            {
               typeName = typeName.replace(/^\(/, '').replace(/\)$/, '');

               const typeNames = typeName.split('|').map((v) => v.trim());
               const html = [];

               for (const unionType of typeNames)
               {
                  html.push(this.getDocHTMLLinkType(unionType));
               }

               return `${paramName}: ${html.join('|')}`;
            }
            else
            {
               return `${paramName}: ${this.getDocHTMLLinkType(typeName)}`;
            }
         });

         return `{${innerTypes.join(', ')}}`;
      }

      // e.g. Map<number, string>
      matched = typeName.match(/^(.*?)\.?<(.*?)>$/);

      if (matched)
      {
         const mainType = matched[1];

         // bad hack: Map.<string, boolean> => Map.<string\Z boolean>
         // bad hack: {a: string, b: boolean} => {a\Y string\Z b\Y boolean}
         const inner = matched[2]
          .replace(/<.*?>/g, (a) => a.replace(/,/g, '\\Z'))
           .replace(/{.*?}/g, (a) => a.replace(/,/g, '\\Z').replace(/:/g, '\\Y'));

         const innerTypes = inner.split(',').map((v) =>
         {
            return v.split('|').map((vv) =>
            {
               vv = vv.trim().replace(/\\Z/g, ',').replace(/\\Y/g, ':');

               return this.getDocHTMLLinkType(vv);
            }).join('|');
         });

         // html
         return `${this.getDocHTMLLink(mainType, mainType)}<${innerTypes.join(', ')}>`;
      }

      if (typeName.startsWith('...'))
      {
         typeName = typeName.replace('...', '');

         if (typeName.includes('|'))
         {
            const typeNames = typeName.replace('(', '').replace(')', '').split('|');
            const typeLinks = typeNames.map((v) => this.getDocHTMLLink(v));

            return `...(${typeLinks.join('|')})`;
         }
         else
         {
            return `...${this.getDocHTMLLink(typeName)}`;
         }
      }
      else if (typeName.startsWith('?'))
      {
         typeName = typeName.replace('?', '');

         return `?${this.getDocHTMLLink(typeName)}`;
      }
      else
      {
         return this.getDocHTMLLink(typeName);
      }
   }

   /**
    * Builds identifier signature HTML.
    *
    * @param {DocObject} doc - Target doc object.
    *
    * @returns {string} Signature HTML.
    */
   static getDocHTMLSignature(doc)
   {
      // call signature
      const callSignatures = [];

      if (doc.params)
      {
         for (const param of doc.params)
         {
            const paramName = param.name;

            if (paramName.includes('.')) { continue; } // for object property
            if (paramName.includes('[')) { continue; } // for array property

            const types = [];

            for (const typeName of param.types)
            {
               types.push(this.getDocHTMLLinkType(typeName));
            }

            callSignatures.push(`${paramName}: ${types.join(' | ')}`);
         }
      }

      // return signature
      const returnSignatures = [];

      if (doc.return)
      {
         for (const typeName of doc.return.types)
         {
            returnSignatures.push(this.getDocHTMLLinkType(typeName));
         }
      }

      // type signature
      let typeSignatures = [];

      if (doc.type)
      {
         for (const typeName of doc.type.types)
         {
            typeSignatures.push(this.getDocHTMLLinkType(typeName));
         }
      }

      // callback is not need type. because type is always function.
      if (doc.kind === 'ModuleFunction')
      {
         typeSignatures = [];
      }

      let html = '';

      if (callSignatures.length)
      {
         html = `(${callSignatures.join(', ')})`;
      }
      else
      {
         switch (doc.kind)
         {
            case 'ClassMethod':
            case 'ModuleFunction':
               html = !doc.accessor ? '()' : '';
               break;
         }
      }

      if (returnSignatures.length) { html = `${html}: ${returnSignatures.join(' | ')}`; }
      if (typeSignatures.length) { html = `${html}: ${typeSignatures.join(' | ')}`; }

      return html;
   }

   /**
    * Builds summary output HTML from parent doc.
    *
    * @param {AccessDocs}  accessDocs - An object from DocDB with the following access keys `Public`, `Private`,
    *                                   `Protected` indexing an associated DocObject[].
    *
    * @param {string}      [title] - Summary title.
    *
    * @returns {string} HTML of summary.
    */
   static getDocHTMLSummary(accessDocs, title = '')
   {
      let html = '';

      for (const accessType in accessDocs)
      {
         const docs = accessDocs[accessType];

         if (!docs.length) { continue; }

         let prefix = '';

         if (docs[0].static) { prefix = 'Static '; }

         const _title = `${prefix}${accessType} ${title}`;
         const result = this.getDocsIceCapSummary(docs, _title);

         if (result) { html += result.html; }
      }

      return html;
   }

   /**
    * Builds method of ancestor class link HTML.
    *
    * @param {DocObject} doc - Target doc object.
    *
    * @returns {string} HTML link. If doc does not override ancestor method, returns empty.
    */
   static getDocOverrideMethod(doc)
   {
      const parentDoc = this._docDB.findByName(doc.memberof)[0];

      if (!parentDoc) { return ''; }
      if (!parentDoc._custom_extends_chains) { return ''; }

      const chains = [...parentDoc._custom_extends_chains].reverse();

      for (const longname of chains)
      {
         const superClassDoc = this._docDB.findByName(longname)[0];

         if (!superClassDoc) { continue; }

         const superMethodDoc = this._docDB.find({ name: doc.name, memberof: superClassDoc.longname })[0];

         if (!superMethodDoc) { continue; }

         return this.getDocHTMLLink(superMethodDoc.longname, `${superClassDoc.name}#${superMethodDoc.name}`, true);
      }

      return '';
   }

   /**
    * Builds method of ancestor class description.
    *
    * @param {DocObject} doc - Target doc object.
    *
    * @returns {string} Description. If doc does not override ancestor method, returns empty.
    */
   static getDocOverrideMethodDescription(doc)
   {
      const parentDoc = this._docDB.findByName(doc.memberof)[0];

      if (!parentDoc) { return ''; }
      if (!parentDoc._custom_extends_chains) { return ''; }

      const chains = [...parentDoc._custom_extends_chains].reverse();

      for (const longname of chains)
      {
         const superClassDoc = this._docDB.findByName(longname)[0];

         if (!superClassDoc) { continue; }

         const superMethodDoc = this._docDB.find({ name: doc.name, memberof: superClassDoc.longname })[0];

         if (!superMethodDoc) { continue; }

         if (superMethodDoc.descriptionHTML) { return superMethodDoc.descriptionHTML; }
      }

      return '';
   }

   /**
    * Get URL of output HTML page.
    *
    * @param {DocObject} doc - Target doc object.
    *
    * @returns {string} URL of output HTML. It is the relative path from output root dir.
    */
   static getDocURL(doc)
   {
      let inner = false;
      let qualifier = '';

      switch (doc.kind)
      {
         case 'ClassMethod':
            qualifier = doc.accessor ? `-${doc.qualifier}` : '';
            inner = true;
            break;

         case 'ClassMember':
         case 'ClassProperty':
         case 'ModuleAssignment':
         case 'ModuleFunction':
         case 'ModuleVariable':
         case 'VirtualTypedef':
            inner = true;
            break;
      }

      if (inner)
      {
         const scope = doc.static ? 'static' : 'instance';
         const fileName = this.getDocFileName(doc);

         return `${fileName}#${scope}-${doc.kind.toLowerCase()}${qualifier}-${doc.name}`;
      }
      else
      {
         return this.getDocFileName(doc);
      }
   }

   /**
    * Builds HTML links to identifiers.
    *
    * @param {string[]} longnames - link to these.
    *
    * @param {string}   [text] - link text. default is name property of doc object.
    *
    * @param {boolean}  [inner=false] - if true, use inner link.
    *
    * @param {string}   [separator='\n'] - used link separator.
    *
    * @returns {string} HTML links.
    */
   static getDocsHTMLLink(longnames, text = void 0, inner = false, separator = '\n')
   {
      if (!longnames) { return ''; }
      if (!longnames.length) { return ''; }

      const links = [];

      for (const longname of longnames)
      {
         if (!longname) { continue; }

         const link = this.getDocHTMLLink(longname, text, inner);

         links.push(`<li>${link}</li>`);
      }

      if (!links.length) { return ''; }

      return `<ul>${links.join(separator)}</ul>`;
   }

   /**
    * Builds detail output HTML from multiple docs.
    *
    * @param {DocObject[]} docs - Target docs.
    *
    * @param {string}      title - Detail title.
    *
    * @return {IceCap} Detail output.
    */
   static getDocsIceCapDetail(docs, title)
   {
      const ice = this.getIceCapTemplate({ filePath: 'html/details.html' });

      ice.text('title', title);
      ice.drop('title', !docs.length);

      ice.loop('detail', docs, (i, doc, ice) =>
      {
         const scope = doc.static ? 'static' : 'instance';
         const qualifier = doc.kind === 'ClassMethod' && doc.accessor ? `-${doc.qualifier}` : '';

         ice.attr('anchor', 'id', `${scope}-${doc.kind.toLowerCase()}${qualifier}-${doc.name}`);
         ice.text('generator', doc.generator ? '*' : '');
         ice.text('async', doc.async ? 'async' : '');
         ice.text('name', doc.name);
         ice.text('abstract', doc.abstract ? 'abstract' : '');
         ice.text('access', doc.access);
         ice.load('signature', this.getDocHTMLSignature(doc));
         ice.load('description', doc.descriptionHTML || this.getDocOverrideMethodDescription(doc));

         switch (doc.kind)
         {
            case 'ClassMethod':
               if (doc.accessor) { ice.text('kind', doc.qualifier); }
               else { ice.drop('kind'); }
               break;

            default:
               ice.drop('kind');
               break;
         }

         if (doc.export && doc.importPath && doc.importStyle)
         {
            const link = this.getDocHTMLFileLink(doc, doc.importPath);

            ice.into('importPath', `import ${doc.importStyle} from '${link}'`, (code, ice) =>
            {
               ice.load('importPathCode', code);
            });
         }
         else
         {
            ice.drop('importPath');
         }

         switch (doc.kind)
         {
            case 'ClassProperty':
            case 'ClassMember':
            case 'ClassMethod':
               ice.text('static', doc.static ? 'static' : '');
               break;

            default:
               ice.drop('static');
               break;
         }

         ice.load('source', this.getDocHTMLFileLink(doc, 'source'));
         ice.text('since', doc.since, 'append');
         ice.load('deprecated', this.getDocHTMLDeprecated(doc));
         ice.load('experimental', this.getDocHTMLExperimental(doc));
         ice.text('version', doc.version, 'append');
         ice.load('see', this.getDocsHTMLLink(doc.see), 'append');
         ice.load('todo', this.getDocsHTMLLink(doc.todo), 'append');
         ice.load('override', this.getDocOverrideMethod(doc));
         ice.load('decorator', this.getDocHTMLDecorator(doc), 'append');

         let isFunction = false;

         switch (doc.kind)
         {
            case 'ClassMethod':
               isFunction = !doc.accessor;
               break;

            case 'ModuleFunction':
               isFunction = true;
               break;
         }

         if (doc.kind === 'VirtualTypedef' && doc.params && doc.type.types[0] === 'function') { isFunction = true; }

         if (isFunction)
         {
            ice.load('properties', this.getIceCapProperties(doc.params, 'Params:'));
         }
         else
         {
            ice.load('properties', this.getIceCapProperties(doc.properties, 'Properties:'));
         }

         // return
         if (doc.return)
         {
            ice.load('returnDescription', doc.return.descriptionHTML);

            const typeNames = [];

            for (const typeName of doc.return.types)
            {
               typeNames.push(this.getDocHTMLLinkType(typeName));
            }

            if (typeof doc.return.nullable === 'boolean')
            {
               const nullable = doc.return.nullable;

               ice.load('returnType', `${typeNames.join(' | ')} (nullable: ${nullable})`);
            }
            else
            {
               ice.load('returnType', typeNames.join(' | '));
            }

            ice.load('returnProperties', this.getIceCapProperties(doc.properties, 'Return Properties:'));
         }
         else
         {
            ice.drop('returnParams');
         }

         // throws
         if (doc.throws)
         {
            ice.loop('throw', doc.throws, (i, exceptionDoc, ice) =>
            {
               ice.load('throwName', this.getDocHTMLLink(exceptionDoc.types[0]));
               ice.load('throwDesc', exceptionDoc.descriptionHTML);
            });
         }
         else
         {
            ice.drop('throwWrap');
         }

         // fires
         if (doc.emits)
         {
            ice.loop('emit', doc.emits, (i, emitDoc, ice) =>
            {
               ice.load('emitName', this.getDocHTMLLink(emitDoc.types[0]));
               ice.load('emitDesc', emitDoc.descriptionHTML);
            });
         }
         else
         {
            ice.drop('emitWrap');
         }

         // listens
         if (doc.listens)
         {
            ice.loop('listen', doc.listens, (i, listenDoc, ice) =>
            {
               ice.load('listenName', this.getDocHTMLLink(listenDoc.types[0]));
               ice.load('listenDesc', listenDoc.descriptionHTML);
            });
         }
         else
         {
            ice.drop('listenWrap');
         }

         // example
         ice.into('example', doc.examples, (examples, ice) =>
         {
            ice.loop('exampleDoc', examples, (i, exampleDoc, ice) =>
            {
               const parsed = parseExample(exampleDoc);

               ice.text('exampleCode', parsed.body);
               ice.text('exampleCaption', parsed.caption);
            });
         });

         // tests
         ice.into('tests', doc._custom_tests, (tests, ice) =>
         {
            ice.loop('test', tests, (i, test, ice) =>
            {
               const testDoc = this._docDB.find({ longname: test })[0];

               ice.load('test', this.getDocHTMLFileLink(testDoc, testDoc.testFullDescription));
            });
         });
      });

      return ice;
   }

   /**
    * Builds summary output HTML from multiple docs.
    *
    * @param {DocObject[]} docs - Target docs.
    *
    * @param {string}      title - Summary title.
    *
    * @param {boolean}     [innerLink=false] - If true, link in summary is inner link.
    *
    * @return {IceCap} Summary output.
    */
   static getDocsIceCapSummary(docs, title, innerLink = false)
   {
      if (docs.length === 0) { return null; }

      const ice = this.getIceCapTemplate({ filePath: 'html/summary.html' });

      ice.text('title', title);

      ice.loop('target', docs, (i, doc, ice) =>
      {
         ice.text('generator', doc.generator ? '*' : '');
         ice.text('async', doc.async ? 'async' : '');
         ice.text('abstract', doc.abstract ? 'abstract' : '');
         ice.text('access', doc.access);
         ice.load('signature', this.getDocHTMLSignature(doc));
         ice.load('description', shorten(doc, true));
         ice.load('name', this.getDocHTMLLink(doc.longname, null, innerLink, doc.kind, doc.qualifier));

         switch (doc.kind)
         {
            case 'ClassMethod':
               if (doc.accessor)
               {
                  ice.text('kind', doc.qualifier);
               }
               else
               {
                  ice.drop('kind');
               }
               break;

            default:
               ice.drop('kind');
               break;
         }

         switch (doc.kind)
         {
            case 'ClassProperty':
            case 'ClassMember':
            case 'ClassMethod':
               ice.text('static', doc.static ? 'static' : '');
               break;

            default:
               ice.drop('static');
               break;
         }

         ice.text('since', doc.since);
         ice.load('deprecated', this.getDocHTMLDeprecated(doc));
         ice.load('experimental', this.getDocHTMLExperimental(doc));
         ice.text('version', doc.version);
      });

      return ice;
   }

   /**
    * Gets base URL HTML page.
    *
    * @param {string} fileName - Output file path.
    *
    * @returns {string} Base URL.
    */
   static getFileURLBase(fileName)
   {
      return '../'.repeat(fileName.split('/').length - 1);
   }

   /**
    * Gets the common HTML layout including the left-hand navigation. The default left-hand navigation is loaded by
    * triggering 'tjsdoc:system:publisher:ice:cap:nav:get' which invokes `getIceCapNav`. To provide a new left-hand
    * navigation register a new event binding to return the IceCap / HTML instance and pass in this event path to
    * load it.
    *
    * @param {string}   [navEvent='tjsdoc:system:publisher:ice:cap:nav:get'] - Optional event to trigger sync to receive
    *                                                                          the left-hand navigation HTML.
    *
    * @param {string}   [navData] - Optional data passed to event binding building the left-hand navigation.
    *
    * @return {IceCap} layout output.
    */
   static getIceCapLayout(navEvent = 'tjsdoc:system:publisher:ice:cap:nav:get', navData = void 0)
   {
      const ice = this.getIceCapTemplate({ filePath: 'html/layout.html', options: { autoClose: false } });

      if (typeof global.$$tjsdoc_version === 'string')
      {
         ice.text('tjsdocVersion', `(${global.$$tjsdoc_version})`);
      }
      else
      {
         ice.drop('tjsdocVersion');
      }

      if (this._pubConfig._mainMenuLinks.length)
      {
         ice.loop('mainMenuLink', this._pubConfig._mainMenuLinks, (i, entry, ice) =>
         {
            if (entry.label) { ice.text('mainMenuLink', entry.label); }
            if (entry.href) { ice.attr('mainMenuLink', 'href', entry.href); }

            if (entry.cssClass) { ice.attr('mainMenuLink', 'class', entry.cssClass); }
            if (entry.cssID) { ice.attr('mainMenuLink', 'id', entry.cssID); }
         });
      }

      // see StaticFileBuilder#exec
      ice.loop('userScript', this._pubConfig.scripts, (i, userScript, ice) =>
      {
         const name = `user/script/${i}-${path.basename(userScript)}`;

         ice.attr('userScript', 'src', name);
      });

      ice.loop('userStyle', this._pubConfig.styles, (i, userStyle, ice) =>
      {
         const name = `user/css/${i}-${path.basename(userStyle)}`;

         ice.attr('userStyle', 'href', name);
      });

      ice.load('nav', this._eventbus.triggerSync(navEvent, navData));

      return ice;
   }

   /**
    * Build properties output.
    *
    * @param {ParsedParam[]}  [properties=[]] - Properties in doc object.
    * @param {string}         title - Output title.
    *
    * @return {IceCap} Built properties output.
    */
   static getIceCapProperties(properties = [], title = 'Properties:')
   {
      const ice = this.getIceCapTemplate({ filePath: 'html/properties.html' });

      ice.text('title', title);

      ice.loop('property', properties, (i, prop, ice) =>
      {
         ice.autoDrop = false;
         ice.attr('property', 'data-depth', prop.name.split('.').length - 1);
         ice.text('name', prop.name);
         ice.attr('name', 'data-depth', prop.name.split('.').length - 1);
         ice.load('description', prop.descriptionHTML);

         const typeNames = [];

         for (const typeName of prop.types)
         {
            typeNames.push(this.getDocHTMLLinkType(typeName));
         }

         ice.load('type', typeNames.join(' | '));

         // appendix
         const appendix = [];

         if (prop.optional)
         {
            appendix.push('<li>optional</li>');
         }

         if ('defaultValue' in prop)
         {
            appendix.push(`<li>default: ${prop.defaultValue}</li>`);
         }

         if (typeof prop.nullable === 'boolean')
         {
            appendix.push(`<li>nullable: ${prop.nullable}</li>`);
         }

         if (appendix.length)
         {
            ice.load('appendix', `<ul>${appendix.join('\n')}</ul>`);
         }
         else
         {
            ice.text('appendix', '');
         }
      });

      if (!properties || properties.length === 0)
      {
         ice.drop('properties');
      }

      return ice;
   }

   /**
    * Gets an HTML template loading it into and IceCap instance.
    *
    * @param {string}   filePath - template file path.
    *
    * @param {object}   [options] - IceCap options.
    *
    * @return {string} HTML of template.
    */
   static getIceCapTemplate({ dirName = __dirname, filePath, options = void 0 } = {})
   {
      const file = path.resolve(dirName, dirName !== __dirname ? filePath : `../template/${filePath}`);

      return this._eventbus.triggerSync('typhonjs:ice:cap:create', fs.readFileSync(file, { encoding: 'utf-8' }),
       options);
   }

   /**
    * Returns a file from `template` directory.
    *
    * @param {string} filePath - template file path.
    *
    * @return {string} HTML of template.
    */
   static getTemplate({ dirName = __dirname, filePath } = {})
   {
      const file = path.resolve(dirName, dirName !== __dirname ? filePath : `../template/${filePath}`);

      return fs.readFileSync(file, { encoding: 'utf-8' });
   }

   /**
    * Gets output HTML page title from DocObject or using `title` from {@link TJSDocConfig}.
    *
    * @param {DocObject|string} doc - Target doc object.
    *
    * @returns {string} HTML page title.
    */
   static getTitle(doc = '')
   {
      if (typeof doc !== 'object' && typeof doc !== 'string')
      {
         throw new TypeError(`'doc' is not an 'object' or 'string'.`);
      }

      const name = doc.name || doc.toString();

      if (!name)
      {
         return this._mainConfig.title ? `${this._mainConfig.title} API Document` : 'API Document';
      }

      return this._mainConfig.title ? `${name} | ${this._mainConfig.title} API Document` : `${name} | API Document`;
   }

   /**
    * Resets the tracked DocDB used for any queries. By default this is set to the main DocDB.
    */
   static reset({ docDB = this._mainDocDB } = {})
   {
      this._docDB = docDB;

      // Remove any old cached left-hand navigation.
      cachedIceNav = void 0;
   }
}

// Module private ---------------------------------------------------------------------------------------------------

let cachedIceNav;
