import fs                  from 'fs';
import path                from 'path';

import markdown            from '../utils/markdown.js';

/**
 * Index output builder.
 *
 * Outputs the main `index.html` file for generated documentation including any README.md or other file specified by
 * `config.index`.
 */
export default class IndexDocBuilder
{
   /**
    * Executes writing `index.html`.
    *
    * @param {EventProxy}  eventbus - An event proxy for the main eventbus.
    */
   static exec(eventbus)
   {
      const ice = eventbus.triggerSync('tjsdoc:system:publisher:ice:cap:layout:get');
      const title = eventbus.triggerSync('tjsdoc:system:publisher:title:get');

      ice.load('content', IndexDocBuilder._buildIndexDoc(eventbus));
      ice.text('title', title, 'write');

      eventbus.trigger('tjsdoc:system:file:write', ice.html, 'index.html');
   }

   /**
    * Build index output including converting `config.index` to HTML from markdown.
    *
    * @param {EventProxy}  eventbus - An event proxy for the main eventbus.
    *
    * @returns {string} html of index output.
    * @private
    */
   static _buildIndexDoc(eventbus)
   {
      const config = eventbus.triggerSync('tjsdoc:data:config:get');

      if (!config.index) { return 'Please create README.md'; }

      let indexContent;

      try
      {
         indexContent = fs.readFileSync(config.index, { encode: 'utf8' }).toString();
      }
      catch (err)
      {
         return 'Please create README.md';
      }

      const ice = eventbus.triggerSync('tjsdoc:system:publisher:ice:cap:template:get', 'index.html');
      const ext = path.extname(config.index);

      switch(ext)
      {
         case '.markdown':
         case '.md':
         case '.MD':
            ice.load('index', markdown(indexContent));
            break;

         default:
            ice.load('index', indexContent);
            break;
      }

      return ice.html;
   }
}
