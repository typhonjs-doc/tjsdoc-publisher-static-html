/**
 * Executes writing target project `package.json`.
 */
export function onHandlePublish(ev)
{
   if (!ev.data.incremental) { PackageCopy.exec(ev.data); }
}

/**
 * Package JSON Output Builder.
 *
 * The target project `package.json` is output to `package.json`.
 */
class PackageCopy
{
   /**
    * Executes writing target project `package.json`.
    */
   static exec({ eventbus, mainConfig, packageObj, silent } = {})
   {
      // Copy package.json if it is defined and `copyPackage` TJSDoc config parameter is true.
      if (packageObj && mainConfig.copyPackage)
      {
         eventbus.trigger('tjsdoc:system:file:write', JSON.stringify(packageObj, null, 2), 'package.json', silent);
      }
   }
}
