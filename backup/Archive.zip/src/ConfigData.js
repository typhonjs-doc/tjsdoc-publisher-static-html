import fs   from 'fs';

/**
 * Defines the data used by typhonjs-config-resolver to validate static HTML publisher / config.publisherOptions.
 */
export default class ConfigData
{
   /**
    * @returns {ConfigResolverData}
    */
   static createResolverData()
   {
      return {
         allowExtends: false,
         defaultValues: ConfigData.defaultValues(),
         postValidate: ConfigData.postValidate()
      };
   }

   /**
    * Generates the default values data structure set to a TJSDocConfig object after extended config files are resolved.
    * Any fields not already set will be set to the default values defined before.
    *
    * @returns {object}
    */
   static defaultValues()
   {
      return {
         'manual.coverage': true,

         'scripts': [],

         'styles': []
      };
   }

   /**
    * Generates the post-validation data structure for bulk checking a PubStaticHTMLConfig object. If a field is
    * present it will be validated otherwise no particular fields are checked.
    *
    * @returns {object}
    */
   static postValidate()
   {
      return {
         'manual': { required: false, test: 'entry', type: 'object' },

         'manual.coverage': { required: false, test: 'entry', type: 'boolean' },

         'manual.globalIndex': { required: false, test: 'entry', type: 'boolean' },

         'manual.asset': { required: false, test: 'entry', expected: (entry) => fs.existsSync(entry),
          message: `file does not exist` },

         'manual.index': { required: false, test: 'entry', expected: (entry) => fs.existsSync(entry),
          message: `file does not exist` },

         'manual.overview': { required: false, test: 'array', expected: (entry) => fs.existsSync(entry),
          message: `file does not exist` },

         'manual.design': { required: false, test: 'array', expected: (entry) => fs.existsSync(entry),
          message: `file does not exist` },

         'manual.installation': { required: false, test: 'array', expected: (entry) => fs.existsSync(entry),
          message: `file does not exist` },

         'manual.usage': { required: false, test: 'array', expected: (entry) => fs.existsSync(entry),
          message: `file does not exist` },

         'manual.tutorial': { required: false, test: 'array', expected: (entry) => fs.existsSync(entry),
          message: `file does not exist` },

         'manual.configuration': { required: false, test: 'array', expected: (entry) => fs.existsSync(entry),
          message: `file does not exist` },

         'manual.example': { required: false, test: 'array', expected: (entry) => fs.existsSync(entry),
          message: `file does not exist` },

         'manual.advanced': { required: false, test: 'array', expected: (entry) => fs.existsSync(entry),
          message: `file does not exist` },

         'manual.faq': { required: false, test: 'array', expected: (entry) => fs.existsSync(entry),
          message: `file does not exist` },

         'scripts': { required: false, test: 'array', expected: (entry) => fs.existsSync(entry),
          message: `file does not exist` },

         'styles': { required: false, test: 'array', expected: (entry) => fs.existsSync(entry),
          message: `file does not exist` }
      };
   }
}

