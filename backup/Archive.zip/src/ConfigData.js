import fs   from 'fs';

/**
 * Defines the data used by typhonjs-config-resolver to validate static HTML publisher / config.publisherOptions.
 */
export default class ConfigData
{
   /**
    * @returns {ConfigResolverData}
    */
   static createResolverData()
   {
      return {
         defaultValues: ConfigData.defaultValues(),
         postValidate: ConfigData.postValidate(),
         upgradeMergeList: ConfigData.upgradeMergeList()
      };
   }

   /**
    * Generates the default values data structure set to a TJSDocConfig object after extended config files are resolved.
    * Any fields not already set will be set to the default values defined before.
    *
    * @returns {object}
    */
   static defaultValues()
   {
      return {
         'publisherOptions.debug': false,

         'publisherOptions.scripts': [],

         'publisherOptions.styles': []
      };
   }

   /**
    * Generates the post-validation data structure for bulk checking a PubStaticHTMLConfig object. If a field is
    * present it will be validated otherwise no particular fields are checked.
    *
    * @returns {object}
    */
   static postValidate()
   {
      return {
         'publisherOptions.debug': { required: false, test: 'entry', type: 'boolean' },

         'publisherOptions.manual': { required: false, test: 'entry', type: 'object' },

         'publisherOptions.manual.coverage': { required: false, test: 'entry', type: 'boolean' },

         'publisherOptions.manual.globalIndex': { required: false, test: 'entry', type: 'boolean' },

         'publisherOptions.manual.asset': { required: false, test: 'entry', expected: (entry) => fs.existsSync(entry),
          message: `file does not exist` },

         'publisherOptions.manual.index': { required: false, test: 'entry', expected: (entry) => fs.existsSync(entry),
          message: `file does not exist` },

         'publisherOptions.manual.overview': { required: false, test: 'array', expected: (entry) => fs.existsSync(entry),
          message: `file does not exist` },

         'publisherOptions.manual.design': { required: false, test: 'array', expected: (entry) => fs.existsSync(entry),
          message: `file does not exist` },

         'publisherOptions.manual.installation': { required: false, test: 'array', expected: (entry) => fs.existsSync(entry),
          message: `file does not exist` },

         'publisherOptions.manual.usage': { required: false, test: 'array', expected: (entry) => fs.existsSync(entry),
          message: `file does not exist` },

         'publisherOptions.manual.tutorial': { required: false, test: 'array', expected: (entry) => fs.existsSync(entry),
          message: `file does not exist` },

         'publisherOptions.manual.configuration': { required: false, test: 'array', expected: (entry) => fs.existsSync(entry),
          message: `file does not exist` },

         'publisherOptions.manual.example': { required: false, test: 'array', expected: (entry) => fs.existsSync(entry),
          message: `file does not exist` },

         'publisherOptions.manual.advanced': { required: false, test: 'array', expected: (entry) => fs.existsSync(entry),
          message: `file does not exist` },

         'publisherOptions.manual.faq': { required: false, test: 'array', expected: (entry) => fs.existsSync(entry),
          message: `file does not exist` },

         'publisherOptions.scripts': { required: false, test: 'array', expected: (entry) => fs.existsSync(entry),
          message: `file does not exist` },

         'publisherOptions.styles': { required: false, test: 'array', expected: (entry) => fs.existsSync(entry),
          message: `file does not exist` }
      };
   }

   /**
    * Returns config keys that are a string and are upgraded to an array or are already an array to be merged.
    *
    * @returns {Array<string>}
    */
   static upgradeMergeList()
   {
      return [
         'scripts',
         'styles'
      ];
   }
}

