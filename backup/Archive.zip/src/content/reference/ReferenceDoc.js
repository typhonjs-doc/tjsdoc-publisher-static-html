import PublishUtil from '../../PublishUtil.js';

const s_LOG_PREPEND = 'tjsdoc-publisher-static-html-reference - ';

/**
 * Handles adding main menu link.
 *
 * @param {PluginEvent} ev - The plugin event.
 */
export function onHandleConfigAsync(ev)
{
   ev.data.pubConfig._mainMenuLinks.push({ label: 'Reference', href: 'identifiers.html' });
}

/**
 * Executes writing badge.svg and documentation coverage data.
 */
export function onHandlePublishAsync(ev)
{
   if (ev.data.incremental)
   {
      if (ev.data.fileType === 'source' && !ev.data.minimal) { ReferenceDoc.exec(ev.data); }
   }
   else
   {
      ReferenceDoc.exec(ev.data);
   }
}

/**
 * References output builder.
 */
class ReferenceDoc
{
   /**
    * Executes writing identifiers / reference page.
    *
    * @param {EventProxy}  eventbus - An event proxy for the main eventbus.
    */
   static exec({ docDB, eventbus, silent = false } = {})
   {
      const ice = eventbus.triggerSync('tjsdoc:system:publisher:ice:cap:layout:get');
      const title = PublishUtil.getTitle('Index');

      ice.load('content', this._buildIdentifierDoc(docDB, eventbus));
      ice.text('title', title, 'write');

      eventbus.trigger('tjsdoc:system:file:write', {
         fileData: ice.html,
         filePath: 'identifiers.html',
         logPrepend: s_LOG_PREPEND,
         silent
      });
   }

   /**
    * Build identifier output.
    *
    * @param {EventProxy}  eventbus - An event proxy for the main eventbus.
    *
    * @return {IceCap} built output.
    * @private
    */
   static _buildIdentifierDoc(docDB, eventbus)
   {
      const ice = PublishUtil.getIceCapTemplate({ dirName: __dirname, filePath: 'html/reference.html' });

      // Get access docs for identifier summary.

      // All classes.
      let accessDocs = docDB.findAccessDocs({ 'kind': 'ModuleClass', 'interface': false });

      ice.load('classSummary',
       eventbus.triggerSync('tjsdoc:system:publisher:doc:html:summary:get', accessDocs, 'Class Summary'));

      // All interfaces.
      accessDocs = docDB.findAccessDocs(
       { 'kind': 'ModuleClass', 'interface': true });

      ice.load('interfaceSummary',
       eventbus.triggerSync('tjsdoc:system:publisher:doc:html:summary:get', accessDocs, 'Interface Summary'), 'append');


      // All module functions.
      accessDocs = docDB.findAccessDocs({ kind: 'ModuleFunction' });

      ice.load('functionSummary',
       eventbus.triggerSync('tjsdoc:system:publisher:doc:html:summary:get', accessDocs, 'Function Summary'), 'append');


      // All module variables.
      accessDocs = docDB.findAccessDocs({ category: 'ModuleVariable' });

      ice.load('variableSummary',
       eventbus.triggerSync('tjsdoc:system:publisher:doc:html:summary:get', accessDocs, 'Variable Summary'), 'append');


      // All virtual typedefs.
      accessDocs = docDB.findAccessDocs({ kind: 'VirtualTypedef' });

      ice.load('typedefSummary',
       eventbus.triggerSync('tjsdoc:system:publisher:doc:html:summary:get', accessDocs, 'Typedef Summary'), 'append');


      // All virtual externals.
      accessDocs = docDB.findAccessDocs({ kind: 'VirtualExternal' });

      ice.load('externalSummary',
       eventbus.triggerSync('tjsdoc:system:publisher:doc:html:summary:get', accessDocs, 'External Summary'), 'append');

      return ice;
   }
}
